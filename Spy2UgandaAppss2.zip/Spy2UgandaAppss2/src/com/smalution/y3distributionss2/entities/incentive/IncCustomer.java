package com.smalution.y3distributionss2.entities.incentive;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class IncCustomer implements Parcelable
{
	private String id;
    private String first_name;
    private String last_name;
    
    public IncCustomer(){}
	public IncCustomer(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			first_name=jsonObect.isNull("first_name")?"":jsonObect.getString("first_name");
			last_name=jsonObect.isNull("last_name")?"":jsonObect.getString("last_name");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public IncCustomer(Parcel in)
 	{
	    id = in.readString();
	    first_name = in.readString();
	    last_name = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 	    dest.writeString(first_name);
 	    dest.writeString(last_name);
 	}
 	public static final Parcelable.Creator<IncCustomer> CREATOR = new Parcelable.Creator<IncCustomer>() 
 	{
 		public IncCustomer createFromParcel(Parcel in) 
 		{
 			return new IncCustomer(in);
 		}
 	
 		public IncCustomer[] newArray (int size) 
 		{
 			return new IncCustomer[size];
 		}
 	};

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFname() {
		return first_name;
	}
	public void setFname(String first_name) {
		this.first_name = first_name;
	}
	public String getLname() {
		return last_name;
	}
	public void setLname(String last_name) {
		this.last_name = last_name;
	}
 	
}
