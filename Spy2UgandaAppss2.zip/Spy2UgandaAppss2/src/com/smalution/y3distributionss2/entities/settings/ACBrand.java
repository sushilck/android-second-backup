package com.smalution.y3distributionss2.entities.settings;

import org.json.JSONObject;

public class ACBrand 
{
	private String id;
    private String name;
    public ACBrand(){}
	public ACBrand(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			name=jsonObect.isNull("name")?"":jsonObect.getString("name");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
