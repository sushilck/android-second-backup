package com.smalution.y3distributionss2.fragments.expenses;

import com.smalution.y3distributionss2.AppManager;
import com.smalution.y3distributionss2.SendDataToServerAsyncTask;
import com.smalution.y3distributionss2.database.Y3QueryDataSource;
import com.smalution.y3distributionss2.entities.expense.Expense;
import com.smalution.y3distributionss2.entities.settings.Brand;
import com.smalution.y3distributionss2.entities.settings.Brands;
import com.smalution.y3distributionss2.entities.settings.Depots;
import com.smalution.y3distributionss2.entities.settings.ExpenseTypeList;
import com.smalution.y3distributionss2.entities.settings.PaymentModes;
import com.smalution.y3distributionss2.fragments.SuperFragment;
import com.smalution.y3distributionss2.utils.DatePickerFragment;
import com.smalution.y3distributionss2.R;
import com.smalution.y3distributionss2.entities.settings.Regions;

import java.util.Calendar;

import android.app.AlertDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.Toast;

import com.androidquery.AQuery;

public class ExpensesEditFragment extends SuperFragment 
{
	Expense expense;
	View rootView;
	AQuery aq; 
	public static final int FLAG_SELECT_EXPENSETYPE=101;
	public static final int FLAG_SELECT_DEPOT=102;
	public static final int FLAG_SELECT_BRAND=103;
	public static final int FLAG_SELECT_PAYMENTMODE=104;
	public static final int FLAG_SELECT_REGION=105;
	public int userGrade;
	String region_id="0";
	String depot_id="0";
	UIHandler uiHandler;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        	
	        	case FLAG_SELECT_PAYMENTMODE:
	    		{
	    			String selectedValue=(String)msg.obj;
	    			aq.id(R.id.buttonPaymentMode).text(selectedValue);
	    			expense.getExpense().setPayment_mode(selectedValue);
	    			break;
				}
        		case FLAG_SELECT_EXPENSETYPE:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonExpenseType).text(selectedValue);
        			expense.getExpType().setName(selectedValue);
        			
        			ExpenseTypeList expenseTypeList=AppManager.getInstance().getExpenseType(aq);
        			if(expenseTypeList!=null)
        			{
        				expense.getExpense().setExp_type_id(expenseTypeList.getItem(msg.arg2).getId());
        			}
        			expense.getExpType().setName(selectedValue);
        			
        			
        			break;
				}
        		
        		/*case FLAG_SELECT_DEPOT:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonDepot).text(selectedValue);
        			Depots depots=AppManager.getInstance().getDepots(aq);
        			if(depots!=null)
        			{
        				expense.getExpense().setDepot_id(depots.getItem(msg.arg2).getId());
        			}
        			//expence.getExpense().getDepot_id()
        			
        			break;
        		}*/
        		
        		case FLAG_SELECT_REGION:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonRegion).text(selectedValue);
        			Regions regions = AppManager.getInstance().getRegions(aq);
        			if(regions !=null)
        			{
        				region_id=regions.getItem(msg.arg2).getId();
        				expense.getExpense().setRegion_id(regions.getItem(msg.arg2).getId());
        				aq.id(R.id.buttonDepot).text(getString(R.string.select_depot));
        			}       			
        			break;
        		}
        		case FLAG_SELECT_DEPOT:
	    		{
	    			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonDepot).text(selectedValue);
        			Depots depots=AppManager.getInstance().getDepots(aq,region_id);
	    			if(depots!=null)
	    			{
	    				depot_id = depots.getItem(msg.arg2).getId();
	    				expense.getExpense().setDepot_id(depot_id);
	    			}	    			
	    			break;
	    		}
        		case FLAG_SELECT_BRAND:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonBrand).text(selectedValue);
        			Brands brands = AppManager.getInstance().getBrands(aq);
        			if(brands!=null)
        			{
        				expense.getExpense().setBrand_id(brands.getItem(msg.arg2).getId());	
        			}
        			break;
        		}
        	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	expense= args.getParcelable("EXPENSE");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		expense = getArguments().getParcelable("EXPENSE");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.expenses_edit_fragment, container, false);
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        initUI();
        return rootView;
    }
	private void initUI() 
	{
		//final SharedPreferences prefs=getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		//userGrade = prefs.getInt("grade", 0);
		//if (userGrade > 3 ){
			//aq.id(R.id.tableRowDepot).gone();
		//}
		
		final SharedPreferences prefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		userGrade = prefs.getInt("grade", 0);
		
		/*if (userGrade > 2){
			aq.id(R.id.tableRowRegion).gone();
			region_id=expense.getRegion().getId();
			if(region_id == "0" || region_id == null)
				region_id = prefs.getString("region_id", null);
		}else{
			region_id=expense.getRegion().getId();
		}
		
		if (userGrade > 3){
			aq.id(R.id.tableRowDepot).gone();
			depot_id =expense.getDepot().getId();
			if(depot_id == "0" || depot_id == null)
				depot_id = prefs.getString("depot_id", null);
		}else{
			depot_id =expense.getDepot().getId();
		}*/
		
		//aq.id(R.id.buttonRegion).text(expense.getRegion().getTitle());
		//aq.id(R.id.buttonDepot).text(expense.getDepot().getTitle());
		
		
		aq.id(R.id.tableRowDate).invisible();
		Calendar calender = Calendar.getInstance();
		String dateStr= calender.get(Calendar.YEAR)+"-"+(calender.get(Calendar.MONTH)+1)+"-"+calender.get(Calendar.DAY_OF_MONTH);
		aq.id(R.id.editTextDate).text(dateStr);
		expense.getExpense().setExp_date(dateStr);
		
		
		
		
		aq.id(R.id.buttonExpenseType).text(expense.getExpType().getName());
		aq.id(R.id.buttonExpenseType).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				ExpenseTypeList expenseTypeList=AppManager.getInstance().getExpenseType(aq);
				if(expenseTypeList!=null)
				{
					String[] arr = expenseTypeList.getName();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_EXPENSETYPE, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.exptype_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		final Depots depots=AppManager.getInstance().getDepots(aq);
		if(depots!=null)
		{
			System.out.println("*********"+expense.getExpense().getDepot_id());
			String name=depots.getDepotNameById(expense.getExpense().getDepot_id());
			if(name!=null)
			{
				aq.id(R.id.buttonDepot).text(name);
			}
		}
		
		/*aq.id(R.id.buttonDepot).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				if(depots!=null)
				{
					String[] arr=depots.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DEPOT, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.depot_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});*/
		
		aq.id(R.id.buttonRegion).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Regions regions = AppManager.getInstance().getRegions(aq);
				if(regions!=null)
				{
					String arr[]=regions.getRegionNames();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_REGION, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.region_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonDepot).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Depots depots=AppManager.getInstance().getDepots(aq,region_id);
				if(depots!=null)
				{
					String[] arr=depots.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DEPOT, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.depot_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		final Brands brands = AppManager.getInstance().getBrands(aq);
		if(brands!=null)
		{
			Brand brand = brands.getBrandById(expense.getExpense().getBrand_id());
			if(brand!=null)
			{
				//aq.id(R.id.buttonBrand).text(brand.getName());
			}
		}
		/*aq.id(R.id.buttonBrand).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				if(brands!=null)
				{
					String[] arr=brands.getBrandsNames();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_BRAND, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.brand_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});*/
		aq.id(R.id.buttonPaymentMode).text(expense.getExpense().getPayment_mode());
		aq.id(R.id.buttonPaymentMode).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				PaymentModes paymentModes=AppManager.getInstance().getPaymentModes(aq);
				if(paymentModes!=null)
				{
					String[] arr=paymentModes.getName();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_PAYMENTMODE, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.payment_mode_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.editTextDate).text(expense.getExpense().getExp_date());
		aq.id(R.id.editTextDate).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				showDatePicker();
			}
		});
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(validateInput())
				{
					
					if(AppManager.isOnline(getActivity())){
						String jsonString = expense.createJson(aq, true);
						new SendDataToServerAsyncTask<Expense>(
								getActivity(), 
								jsonString,
								null, 
								AppManager.getInstance().URL_UPDATE_EXPENSE,
								getString(R.string.exp_updated),
								true,
								null,
								null,
								-1,"").execute();
					}else{
						 Y3QueryDataSource datasource=new Y3QueryDataSource(getActivity());
						 datasource.open();
						 datasource.updateExpenseData(expense,expense.getExpense().getId());	
						 showEditDialog();
						 //Toast.makeText(getActivity(), "Expenses updated successfully.", Toast.LENGTH_SHORT).show();
					     //getActivity().getSupportFragmentManager().popBackStack();						
					}
					
				}
			}
		});
		aq.id(R.id.editTextExpenseRef).text(expense.getExpense().getExpense_ref());
		aq.id(R.id.editTextExpenseAmount).text(expense.getExpense().getExp_amount());
		aq.id(R.id.editTextExpenseDetails).text(expense.getExpense().getDescription());
	}
	private void showDatePicker() 
	{
		  DatePickerFragment date = new DatePickerFragment();
		  Calendar calender = Calendar.getInstance();
		  Bundle args = new Bundle();
		  args.putInt("year", calender.get(Calendar.YEAR));
		  args.putInt("month", calender.get(Calendar.MONTH));
		  args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
		  date.setArguments(args);
		  date.setCallBack(ondate);
		  date.show(getActivity().getSupportFragmentManager(), getString(R.string.date_picker));
	}
	OnDateSetListener ondate = new OnDateSetListener() 
	{
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth) 
		{
			String dateStr=String.valueOf(year) + "-" + String.valueOf(monthOfYear+1)+ "-" + String.valueOf(dayOfMonth);
			aq.id(R.id.editTextDate).text(dateStr);
			expense.getExpense().setExp_date(dateStr);
		}
	};
	private boolean validateInput() 
	{
		String expenseDetail =aq.id(R.id.editTextExpenseDetails).getText().toString();
		
			expense.getExpense().setDescription(expenseDetail);
			String expenseType = aq.id(R.id.buttonExpenseType).getText().toString();
			if(expenseType!=null && expenseType.length()>0)
			{
//				String paymentMode =aq.id(R.id.buttonPaymentMode).getText().toString();
//				if(paymentMode!=null && paymentMode.length()>0)
//				{
					//String depot = aq.id(R.id.buttonDepot).getText().toString();
					//if(depot!=null && depot.length()>0 || userGrade > 3)
					//{
				
				if((aq.id(R.id.buttonRegion).getButton().getText().toString().length()>0 &&
						!aq.id(R.id.buttonRegion).getButton().getText().toString().startsWith( getString(R.string.select) ) ) || userGrade > 2)
				{
					if((aq.id(R.id.buttonDepot).getButton().getText().toString().length()>0 &&
							!aq.id(R.id.buttonDepot).getButton().getText().toString().startsWith(getString(R.string.select) ) ) || userGrade > 3)
					{
						
						//expense.getRegion().setId(expense.getExpense().getRegion_id());
						//expense.getRegion().setTitle(aq.id(R.id.buttonRegion).getButton().getText().toString());
						//expense.getDepot().setId(expense.getExpense().getDepot_id());
						//expense.getDepot().setTitle(aq.id(R.id.buttonDepot).getButton().getText().toString());
				
						//String brand =aq.id(R.id.buttonBrand).getText().toString();
						//if(brand!=null && brand.length()>0)
						//{
							String expenseRef =aq.id(R.id.editTextExpenseRef).getText().toString();
						/*	if(expenseRef!=null && expenseRef.length()>0)
							{*/
								expense.getExpense().setExpense_ref(expenseRef);
								String expenseAmount =aq.id(R.id.editTextExpenseAmount).getText().toString();
								if(expenseAmount!=null && expenseAmount.length()>0
										&& AppManager.getInstance().isValidNumber(expenseAmount))
								{
									expense.getExpense().setExp_amount(expenseAmount);
									String expenseDate =aq.id(R.id.editTextDate).getText().toString();
									if(expenseDate!=null && expenseDate.length()>0)
									{
										expense.getExpense().setExp_date(expenseDate);
										return true;
									}
									else
									{
										Toast.makeText(getActivity(),  getString(R.string.Expense_Date), Toast.LENGTH_SHORT).show();
									}
								}
								else
								{
									Toast.makeText(getActivity(),  getString(R.string.ExpenseAmount), Toast.LENGTH_SHORT).show();
								}
							//}
							/*else
							{
								Toast.makeText(getActivity(), "Please enter expense ref", Toast.LENGTH_SHORT).show();
							}*/
						//}
						//else
						//{
						//	Toast.makeText(getActivity(),  getString(R.string.select_brand), Toast.LENGTH_SHORT).show();
						//}
					}
					else
					{
						Toast.makeText(getActivity(),  getString(R.string.select_depot), Toast.LENGTH_SHORT).show();
					}
				}
				else
				{
					Toast.makeText(getActivity(),  getString(R.string.select_region), Toast.LENGTH_SHORT).show();
				}
//				}
//				else
//				{
//					Toast.makeText(getActivity(), "Please select payment mode", Toast.LENGTH_SHORT).show();
//				}
			}
			else
			{
				Toast.makeText(getActivity(),  getString(R.string.select_exp_type), Toast.LENGTH_SHORT).show();
			}
		

	/*	else
		{
			Toast.makeText(getActivity(), "Please enter expense details", Toast.LENGTH_SHORT).show();
		}*/
		return false;
	}
	private void showEditDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle( getString(R.string.confirm));
		alertDialogBuilder
				.setMessage( getString(R.string.exp_updated))
				.setCancelable(false)
				.setPositiveButton(
						 getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								getActivity().getSupportFragmentManager().popBackStack();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
}
