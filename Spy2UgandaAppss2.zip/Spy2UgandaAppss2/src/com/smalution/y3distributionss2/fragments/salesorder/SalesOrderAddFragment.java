package com.smalution.y3distributionss2.fragments.salesorder;

import com.smalution.y3distributionss2.AppManager;
import com.smalution.y3distributionss2.Utils;
import com.smalution.y3distributionss2.database.Y3QueryDataSource;
import com.smalution.y3distributionss2.entities.User;
import com.smalution.y3distributionss2.entities.customer.CustDepot;
import com.smalution.y3distributionss2.entities.customer.CustRegion;
import com.smalution.y3distributionss2.entities.customer.Customer;
import com.smalution.y3distributionss2.entities.customer.SearchCutomer;
import com.smalution.y3distributionss2.entities.salesorder.FreeItemSales;
import com.smalution.y3distributionss2.entities.salesorder.Sales;
import com.smalution.y3distributionss2.entities.salesorder.SalesOrderDetail;
import com.smalution.y3distributionss2.entities.settings.ActiveCompaignManager;
import com.smalution.y3distributionss2.entities.settings.ActiveCompaigns;
import com.smalution.y3distributionss2.entities.settings.SelectionButtonItem;
import com.smalution.y3distributionss2.fragments.SuperFragment;
import com.smalution.y3distributionss2.utils.AppConstant;
import com.smalution.y3distributionss2.utils.DatePickerFragment;
import com.smalution.y3distributionss2.R;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.Toast;

import com.androidquery.AQuery;


public class SalesOrderAddFragment extends SuperFragment 
{
	boolean isOnlineCustomerSelectionModeOn=true;
	SalesOrderDetail salesOrderDetail;
	View rootView;
	AQuery aq; 
	AQuery aqFooter;
	ArrayAdapter<Sales> salesAdapter;
	ArrayList<Sales> salesArrayList;
	ArrayAdapter<FreeItemSales> freeItemsAdapter;
	ArrayList<FreeItemSales> freeItemsArrayList;
	ArrayList<ActiveCompaigns> qualifyingCompaignList;
	Hashtable<String, String> offlineCustomers;
	public static final int FLAG_SELECT_CUSTOMER=101;
	UIHandler uiHandler;
	private final int SALES_ITEM_ACTIVITY_CODE=100;
	private String salesOrder_json;
	public  String customer_id;
	public boolean isDraft = false;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		case FLAG_SELECT_CUSTOMER:
        		{
        			//String selectedValue=(String)msg.obj;
        			//customers.getItem(msg.arg2);
        			//System.out.println(itm.getTitle());
        			if(isOnlineCustomerSelectionModeOn)
        			{
        				SelectionButtonItem itm = (SelectionButtonItem) msg.obj; 
        				aq.id(R.id.buttonCustomer).text(itm.getTitle());
            			//Customers customers = AppManager.getInstance().getCustomers(aq);
            			/*if(customers!=null)
            			{
            				//SelectionButtonItem itm = customers.getItem(msg.arg2);
            				if(msg.arg2 != 0)
            				{
            					salesOrderDetail.getOrder().getOrder().setCustomer_id(itm.getId());
            					salesOrderDetail.getOrder().getCustomer().setFirst_name(itm.getTitle());
            					salesOrderDetail.getOrder().getCustomer().setLast_name("");            					
            					customer_name= itm.getTitle().toString();
                    			new GetCompaignAsyncTask(aq, itm.getId()).execute();
            				}
                		}*/
            			if(msg.arg2 != 0)
        				{
            				customer_id= Integer.toString(msg.arg2);
        					salesOrderDetail.getOrder().getOrder().setCustomer_id(itm.getId());
        					salesOrderDetail.getOrder().getCustomer().setFirst_name(itm.getTitle());
        					salesOrderDetail.getOrder().getCustomer().setLast_name("");            					
        					//itm.getTitle().toString();
                			new GetCompaignAsyncTask(aq, itm.getId()).execute();
        				}
        			}
        			else
        			{
        				/*aq.id(R.id.buttonOfflineCustomer).text(selectedValue);
        				salesOrderDetail.getOrder().getCustomer().setFirst_name(selectedValue);
    					salesOrderDetail.getOrder().getCustomer().setLast_name("");  

        			    String jsonString = offlineCustomers.get(selectedValue);
        			    salesOrderDetail.setOfflineCustomerJSON(jsonString);
        			    if(jsonString!=null && jsonString.length()>0)
        			    {
        			    	new GetCompaignAsyncTask(aq, "").execute();
        			    }*/
        				String selectedValue=(String)msg.obj;
        				aq.id(R.id.buttonOfflineCustomer).text(selectedValue);
        				customer_id= Integer.toString(msg.arg2);
        				salesOrderDetail.getOrder().getCustomer().setFirst_name(selectedValue);
    					salesOrderDetail.getOrder().getCustomer().setLast_name("");  

        			    String jsonString = offlineCustomers.get(selectedValue);
        			    salesOrderDetail.setOfflineCustomerJSON(jsonString);
        			    if(jsonString!=null && jsonString.length()>0)
        			    {
        			    	new GetCompaignAsyncTask(aq, "").execute();
        			    }
        			}
        			break;
        		}
        	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	
	        }
	    });
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
 
        rootView = inflater.inflate(R.layout.sales_order_add_fragment, container, false);
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        AppManager.getInstance().getActiveCompaign(aq);
        salesArrayList=new ArrayList<Sales>();
        freeItemsArrayList=new ArrayList<FreeItemSales>();
        salesOrderDetail=new SalesOrderDetail();
        initUI(); 
        sofillfromDraft();
        return rootView;
    }
	
	public void onPause(){
		super.onPause();
		System.out.println("This is OnPause activity");
		soaddDraft();
	}
	
	public void onStop(){
		super.onStop();
		System.out.println("This is onStop activity");
		soaddDraft();
	}
	
	public void onDestroy(){
		super.onDestroy();
		System.out.println("This is onDestroy activity");
		soaddDraft();
	}
	
	private void showDatePicker() 
	{
		  DatePickerFragment date = new DatePickerFragment();
		  Calendar calender = Calendar.getInstance();
		  Bundle args = new Bundle();
		  args.putInt("year", calender.get(Calendar.YEAR));
		  args.putInt("month", calender.get(Calendar.MONTH));
		  args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
		  date.setArguments(args);
		  date.setCallBack(ondate);
		  date.show(getActivity().getSupportFragmentManager(), "Date Picker");
	}
	OnDateSetListener ondate = new OnDateSetListener() 
	{
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth) 
		{
			String dateStr=String.valueOf(year) + "-" + String.valueOf(monthOfYear+1)+ "-" + String.valueOf(dayOfMonth);
			aq.id(R.id.editTextSalesDate).text(dateStr);
			salesOrderDetail.getOrder().getOrder().setOrder_date(dateStr);
		   //Toast.makeText(getActivity(),String.valueOf(year) + "-" + String.valueOf(monthOfYear+1)+ "-" + String.valueOf(dayOfMonth),Toast.LENGTH_LONG).show();
		}
	};
	private void initUI() 
	{
		ListView listView=aq.id(R.id.customerList).getListView();
		View header = LayoutInflater.from(getActivity()).inflate(R.layout.sales_order_add_list_header, null);
		listView.addHeaderView(header, null, false);
		View footer = LayoutInflater.from(getActivity()).inflate(R.layout.sales_order_add_list_footer, null);
		listView.addFooterView(footer, null, false);
		aqFooter=new AQuery(footer);
		
		if(qualifyingCompaignList!=null && qualifyingCompaignList.size()>0)
		{
			aq.id(R.id.buttonCompaignAvailable).visible();
		}
		aq.id(R.id.buttonCompaignAvailable).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(qualifyingCompaignList!=null && qualifyingCompaignList.size()>0)
				{
					showCompaignDialog(aq.getContext(), qualifyingCompaignList);
				}
				else
				{
					Toast.makeText(getActivity(), getString(R.string.select_customer), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonCustomer).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				aq.id(R.id.buttonOfflineCustomer).text(getString(R.string.select_offline_customer));
				isOnlineCustomerSelectionModeOn=true;
				//boolean flag=false;
				boolean flag=true;
				
				//Customers customers = AppManager.getInstance().getCustomers(aq);
				SearchCutomer.showAutosearchAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER);
				
				/*
				if(customers!=null)
				{
					String[] arr=customers.getCustomerNamesArr();
					if(arr.length>0)
					{
						//SearchCutomer searchCustomer;
						//AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER, arr);
						//AppManager.getInstance().showAutosearchAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER, arr);
						
					}
				}*/
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.customer_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		aq.id(R.id.buttonOfflineCustomer).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				isOnlineCustomerSelectionModeOn=false;
				aq.id(R.id.buttonCustomer).text(getString(R.string.select_customer_btn));
				new GetOfflineCustomersAsyncTask(aq).execute();
			}
		});
		
		//Default date
		
		Calendar calender = Calendar.getInstance();
		String dateStr= calender.get(Calendar.YEAR)+"-"+(calender.get(Calendar.MONTH)+1)+"-"+calender.get(Calendar.DAY_OF_MONTH);
		aq.id(R.id.editTextSalesDate).text(dateStr);
		salesOrderDetail.getOrder().getOrder().setOrder_date(dateStr);
		
		aq.id(R.id.editTextSalesDate).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				showDatePicker();
			}
		});
		salesAdapter= new ArrayAdapter<Sales>(this.getActivity(), R.layout.sales_order_add_list_item, salesArrayList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.sales_order_add_list_item, parent, false);
	            }
	            final AQuery aql=new AQuery(convertView);
	            final int pos=position;
	            aql.id(R.id.removeButtonParent).clicked(new OnClickListener() 
				{
					@Override
					public void onClick(View v) 
					{
						salesArrayList.remove(pos);
						
						BigDecimal grandTotal = getGrandTotal();
						salesOrderDetail.getOrder().getOrder().setTotal(""+grandTotal);
						aqFooter.id(R.id.textViewGrandTotal).text(""+grandTotal);
						
						salesAdapter.notifyDataSetChanged();
						aq.id(R.id.freeItemsParent).invisible();
						getFreeItems();
					}
				});
	            aql.id(R.id.textViewBrand).text(getItem(position).getBrand().getName());
	            aql.id(R.id.textViewUnit).text(getItem(position).getSale().getUnit());
	            aql.id(R.id.textViewUnitPrice).text(getItem(position).getSale().getUnit_price());
	            aql.id(R.id.textViewQuantity).text(getItem(position).getSale().getQuantity());
	            aql.id(R.id.textViewTotal).text(getItem(position).getSale().getAmount());
	            return convertView;
	        }
		};
		aqFooter.id(R.id.addMoreButtonParent).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				Intent intent=new Intent(getActivity(), SalesOrderItemAddActivity.class);
				startActivityForResult(intent, SALES_ITEM_ACTIVITY_CODE);
			}
		});
		listView.setAdapter(salesAdapter);
		
		ListView freeItemsView=aq.id(R.id.freeItemsList).getListView();
		View freeItemsHeader = LayoutInflater.from(getActivity()).inflate(R.layout.sales_order_view_list_freeitems_header, null);
		freeItemsView.addHeaderView(freeItemsHeader, null, false);
		freeItemsAdapter = new ArrayAdapter<FreeItemSales>(this.getActivity(), R.layout.sales_order_view_list_freeitems_item, freeItemsArrayList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.sales_order_view_list_freeitems_item, parent, false);
	            }
	            AQuery aql=new AQuery(convertView);
	            FreeItemSales freeItem=(FreeItemSales)getItem(position);
	            aql.id(R.id.textViewBrand).text(freeItem.getBrand().getName());
	            aql.id(R.id.textViewItem).text(freeItem.getFreeItem().getQuantity()+" "+freeItem.getFreeItem().getUnit());
	            return convertView;
	        }
		};
		freeItemsView.setAdapter(freeItemsAdapter);		
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(aq.id(R.id.editTextSalesDate).getTextView().getText().toString().length()>0)
				{
					if(salesArrayList!=null && salesArrayList.size()>0)
					{
						salesOrderDetail.setSales(salesArrayList);
						salesOrderDetail.setFreeItems(freeItemsArrayList);
					
						
						if(AppManager.isOnline(getActivity()))
						{
							salesOrder_json = salesOrderDetail.createJson(aq, isOnlineCustomerSelectionModeOn);
							Log.d("MTK",salesOrder_json);
							new AddSalesOrder().execute();
							
							
						}else{
							  DateFormat dateFormat = new SimpleDateFormat("HHmmss");
							  Date date = new Date();
							  System.out.println(dateFormat.format(date));	
							  String  firstLetter = dateFormat.format(date).toString().replaceFirst("^0+(?!$)", "");
							  salesOrderDetail.getOrder().getOrder().setId(firstLetter);	
							  salesOrderDetail.getOrder().getOrder().setCreated(AppConstant.getCurrentDateAndTime());
							  salesOrderDetail.getOrder().getOrder().setModified(AppConstant.SYNC_NOT_DONE);
							  String jsonStr = salesOrderDetail.createJson(aq, isOnlineCustomerSelectionModeOn,1);							
							  Log.d("MTK",jsonStr );
							 final SharedPreferences prefs=getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
							 String str = prefs.getString("user_object", "");
							//final String token = prefs.getString("token", null);
							if(str!="")
							{
								try
								{
									JSONObject userJSONObject = new JSONObject(str);
									final User user=new User(userJSONObject);
									salesOrderDetail.getOrder().getUser().setFirst_name(user.getFirst_name());
									salesOrderDetail.getOrder().getUser().setLast_name(user.getLast_name());
									SharedPreferences soprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
									Editor edt = soprefs.edit();
									edt.putString("sodraftJsonString", null);
									edt.commit();
									isDraft = true;
								}
								catch(Exception e){
									e.printStackTrace();
									
								}
							}
							Y3QueryDataSource dataSource = new Y3QueryDataSource(getActivity());
						    dataSource.open();				
						    String json=						    		
						    		"{"+"\""+"Customer"+"\""+":{" 
						    		+"\"first_name\":\""+salesOrderDetail.getOrder().getCustomer().getFirst_name()+"\"," 
						    		+"\"id\":\""+salesOrderDetail.getOrder().getCustomer().getId()+"\"}," 
						    		+"\""+"User"+"\""+":"+"{\"last_name\":\""+salesOrderDetail.getOrder().getUser().getLast_name()+"\"," 
						    		+"\"first_name\":\""+salesOrderDetail.getOrder().getUser().getFirst_name()+"\"},"						    		
									+"\""+"Order"+"\""+":"+"{"+"\"total\":\""+salesOrderDetail.getOrder().getOrder().getTotal()+"\"," 
						    		+"\"id\":\""+salesOrderDetail.getOrder().getOrder().getId()+"\"," 
						    		+"\"created\":\""+salesOrderDetail.getOrder().getOrder().getCreated()+"\"," 
						    		+"\"status\":\""+salesOrderDetail.getOrder().getOrder().getStatus()+"\"," 
						    		+"\"items\":\""+salesOrderDetail.getOrder().getOrder().getItems()+"\"," +
						    		"\"user_id\":\""+salesOrderDetail.getOrder().getOrder().getUser_id()+"\"," +
						    		"\"order_date\":\""+salesOrderDetail.getOrder().getOrder().getOrder_date()+"\"," +
						    		"\"customer_id\":\""+salesOrderDetail.getOrder().getOrder().getCustomer_id()+"\"," +						    		
						    		"\"modified\":\""+salesOrderDetail.getOrder().getOrder().getModified()+"\"}," +"\""+"sno"+"\""+":"+null+"}";						    		
						    							    		
						    		dataSource.addSalesData(json,jsonStr,"1");
						    		showSaveDialog();
									//Toast.makeText(getActivity(), "Sales Order added successfully.", Toast.LENGTH_SHORT).show();
									//getActivity().getSupportFragmentManager().popBackStack();
						}
					}
					else
					{
						Toast.makeText(getActivity(), getString(R.string.add_sale_item), Toast.LENGTH_SHORT).show();
					}
				}
				else
				{
					Toast.makeText(getActivity(), getString(R.string.enter_date), Toast.LENGTH_SHORT).show();
				}
			}
		});
	}
	private class GetOfflineCustomersAsyncTask extends AsyncTask<Void, Void,String[]>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		boolean flag=false;
		public GetOfflineCustomersAsyncTask(AQuery aq)
		{
			this.aq=aq;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected String[] doInBackground(Void... params) 
		{
			Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		    datasource.open();
			SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
			String token = prefs.getString("token", null);
		    offlineCustomers = datasource.getOfflineCustomeData(token);
		    datasource.close();
		    
		    if(offlineCustomers!=null)
			{
		    	Set<String> keys = offlineCustomers.keySet();
			    String[] arr=new String[keys.size()];
			    keys.toArray(arr);
			    return arr;
			}
			return null;
		}
		@Override
		protected void onPostExecute(String[] result) 
		{
			super.onPostExecute(result);
			if(result!=null)
			{
		    	if(result.length>0)
				{
					AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER, result);
					flag=true;
				}
			}
			if(!flag)
			{
				Toast.makeText(getActivity(), getString(R.string.offline_customer_mess), Toast.LENGTH_SHORT).show();
			}
			progressDialog.dismiss();
		}
	}
	private class GetCompaignAsyncTask extends AsyncTask<Void, Void,ArrayList<ActiveCompaigns>>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		String customerId;
		public GetCompaignAsyncTask(AQuery aq, String customerId)
		{
			this.aq=aq;
			this.customerId=customerId;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected ArrayList<ActiveCompaigns> doInBackground(Void... params) 
		{
			boolean flag=false;
			try
			{
				if(isOnlineCustomerSelectionModeOn)
				{
					String depotId = null;
					String regionId = null;
					if( AppManager.isOnline(getActivity()) ){
						Customer customer = AppManager.getInstance().getCustomerDetails(aq, customerId);
						if(customer!=null)
						{
							depotId = customer.getDepot().getId();
							regionId =  customer.getRegion().getId();
						}
					}else{
						 final SharedPreferences prefs=getActivity().getSharedPreferences("BGGeoCollector", Context.MODE_PRIVATE);
						 String str = prefs.getString("user_object", "");
						 
						if(str!="")
						{
							
							JSONObject userJSONObject = new JSONObject(str);
							final User user=new User(userJSONObject);
							depotId = user.getDepot_id();
							regionId = user.getRegion_id();
						}
							
					}
					ActiveCompaignManager activeCompaignManager=AppManager.getInstance().getActiveCompaign(aq);
					if(activeCompaignManager!=null)
					{
						flag=true;
						//System.out.println("Checking regin depot: "+depotId+" Region: "+regionId);
						return activeCompaignManager.getQualifyingCompaign(depotId,regionId);
						
					}
				}
				else
				{
					if(salesOrderDetail.getOfflineCustomerJSON()!=null && salesOrderDetail.getOfflineCustomerJSON().length()>0)
					{
						JSONObject jsonObject=new JSONObject(salesOrderDetail.getOfflineCustomerJSON());
						if(jsonObject!=null && !jsonObject.isNull("depot_id") && !jsonObject.isNull("region_id"))
						{
							CustDepot suctDepot=new CustDepot();
							suctDepot.setId(jsonObject.getString("depot_id"));
							CustRegion custRegion=new CustRegion();
							custRegion.setId(jsonObject.getString("region_id"));
							
							ActiveCompaignManager activeCompaignManager=AppManager.getInstance().getActiveCompaign(aq);
							if(activeCompaignManager!=null)
							{
								flag=true;
								return activeCompaignManager.getQualifyingCompaign(suctDepot.getId(), custRegion.getId());
							}
						}
					}
				}
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			if(!flag)
			{
				//'Toast.makeText(getActivity(), "Selected customer details not found on server.", Toast.LENGTH_SHORT).show();
			}
			return new ArrayList<ActiveCompaigns>();
		}
		@Override
		protected void onPostExecute(final ArrayList<ActiveCompaigns> result) 
		{
			super.onPostExecute(result);
			if(result!=null && result.size()>0)
			{
				qualifyingCompaignList=result;
				aq.id(R.id.buttonCompaignAvailable).visible();
				//aq.id(R.id.freeItemsParent).visible();
				aq.id(R.id.salesItemsParent).visible();
			}
			else
			{
				aq.id(R.id.buttonCompaignAvailable).invisible();
				aq.id(R.id.freeItemsParent).invisible();
				aq.id(R.id.salesItemsParent).visible();
			}
			
			progressDialog.dismiss();
		}
	}
	private void showCompaignDialog(Context context, ArrayList<ActiveCompaigns> compaignArrayList)
	{
	    final Dialog dialog = new Dialog(aq.getContext());
	    dialog.setTitle(R.string.Active_Campaigns);
	    View view = LayoutInflater.from(aq.getContext()).inflate(R.layout.compaign_dialog_main, null);
	    ListView lv = (ListView) view.findViewById(R.id.compaignList);
	    ArrayAdapter<ActiveCompaigns> compaignListaAdapter= new ArrayAdapter<ActiveCompaigns>(aq.getContext(), R.layout.compaign_dialog_listitem, compaignArrayList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.compaign_dialog_listitem, parent, false);
	            }
	            final AQuery aql=new AQuery(convertView);
	            ActiveCompaigns activeCompaigns=getItem(position);
	            aql.id(R.id.textViewCompaignTitle).text(activeCompaigns.getCompaign().getTitle());
	            aql.id(R.id.textViewCompaignDescription).text(getString(R.string.get)+" "+activeCompaigns.getCompaign().getFree_qty()+" "+activeCompaigns.getCompaign().getFree_unit()+" "+getString(R.string.of)+" \""+activeCompaigns.getBrand().getName()+"\" "+getString(R.string.on_purchase_of)+" "+activeCompaigns.getCompaign().getRequired_qty()+" "+activeCompaigns.getCompaign().getRequired_unit()+" "+activeCompaigns.getBrand().getName());
	            return convertView;
	        }
		};
	    lv.setAdapter(compaignListaAdapter);
	    dialog.setContentView(view);
	    dialog.setCancelable(true);
	    dialog.show();
	}
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode==Activity.RESULT_OK)
		{
			if(requestCode == SALES_ITEM_ACTIVITY_CODE)
			{
				Sales salesItem = data.getParcelableExtra("ADDED_SALES_ITEM");
				salesArrayList.add(salesItem);
				BigDecimal grandTotal = getGrandTotal();
				salesOrderDetail.getOrder().getOrder().setTotal(""+grandTotal);
				aqFooter.id(R.id.textViewGrandTotal).text(""+grandTotal);
				getFreeItems();
				salesAdapter.notifyDataSetChanged();
			}
		}
	}
	private void getFreeItems()
	{
		if(qualifyingCompaignList==null || qualifyingCompaignList.size()==0)
		{
			return;
		}
		Hashtable<String, Float> salesTable=new Hashtable<String, Float>(); 
		freeItemsArrayList.clear();
 		for(ActiveCompaigns comp:qualifyingCompaignList)
		{
 			for(Sales sales: salesArrayList)
 			{
 				if(comp.getCompaign().getBrand_id().equals(sales.getSale().getBrand_id()))
 				{
 					String compaignRequirdRoleUnit=comp.getCompaign().getRequired_unit();
 					String salesUnit=sales.getSale().getUnit();
 					
 					if(compaignRequirdRoleUnit.equals(salesUnit))
 					{
 						if(salesTable.containsKey(comp.getCompaign().getId()))
 						{
 							Float qty = salesTable.get(comp.getCompaign().getId());
 							qty=qty+Float.parseFloat(sales.getSale().getQuantity());
 							salesTable.put(comp.getCompaign().getId(), qty);
 						}
 						else
 						{
 							salesTable.put(comp.getCompaign().getId(), Float.parseFloat(sales.getSale().getQuantity()));
 						}
 					}
 				}
 			}
		}
 		for(ActiveCompaigns comp:qualifyingCompaignList)
 		{
 			if(salesTable.containsKey(comp.getCompaign().getId()))
 			{
 				if(Float.parseFloat(comp.getCompaign().getRequired_qty())<=salesTable.get(comp.getCompaign().getId()))
				{
 					float roundOfCount;
 					aq.id(R.id.freeItemsParent).visible();
 					FreeItemSales freeItem=new FreeItemSales();
 					freeItem.getFreeItem().setBrand_id(comp.getCompaign().getBrand_id());
 					freeItem.getBrand().setName(comp.getBrand().getName());
 					freeItem.getFreeItem().setUnit(comp.getCompaign().getFree_unit());
 					Float freeItemCount=salesTable.get(comp.getCompaign().getId())/Float.parseFloat(comp.getCompaign().getRequired_qty());
 					
 					roundOfCount=(float)( Math.floor(freeItemCount.floatValue()) * Float.parseFloat(comp.getCompaign().getFree_qty()) );
 					
 					if ( Integer.parseInt(comp.getCompaign().getCal_percent()) == 1 ){
 						roundOfCount=(float)( freeItemCount.floatValue() * Float.parseFloat(comp.getCompaign().getFree_qty()) );
 					} 
 					
 					
					freeItem.getFreeItem().setQuantity(""+roundOfCount);
 					freeItem.getFreeItem().setCompaign_id(comp.getCompaign().getId());
 					freeItemsArrayList.add(freeItem);
				}
 			}
 		}
 		freeItemsAdapter.notifyDataSetChanged();
 	}
	private BigDecimal getGrandTotal()
	{
		BigDecimal grandTotal = new BigDecimal("0");
		for(Sales sales:salesArrayList)
		{
			//float amount=Float.parseFloat(sales.getSale().getAmount());
			String amt = sales.getSale().getAmount().toString();
			BigDecimal amount = new BigDecimal(amt);
			grandTotal = grandTotal.add(amount); //grandTotal.add(amount);
			//grandTotal=grandTotal+amount;
		}
		return grandTotal;
	}
	
	private class AddSalesOrder extends AsyncTask<Void, Void, String> {

		ProgressDialog progressDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
			progressDialog.setMessage(getString(R.string.wait_progress));
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(true);
			progressDialog.show();
			progressDialog
					.setOnKeyListener(new DialogInterface.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog,
								int keyCode, KeyEvent event) {
							return false;
						}
					});
		}


		protected String doInBackground(Void... params) {
			if (AppManager.getInstance().isOnline(aq.getContext())) {
				Hashtable<String,String> params1=new Hashtable<String,String>();
				params1.put("jsonString", salesOrder_json);			
				String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_SALESORDER, params1, null);
				return response;
			}
			return null;
		}

		protected void onPostExecute(String response) {
			
			progressDialog.dismiss();
			
			try {
				if(response!=null){
				int errorCode=new JSONObject(response).getInt("error");
				
				if(errorCode==0){
					System.out.println("Added");
					showSaveDialog();
					SharedPreferences soprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
					Editor edt = soprefs.edit();
					edt.putString("sodraftJsonString", null);
					edt.commit();
					isDraft = true;
					 //Toast.makeText(getActivity(), "Sales added successfully.", Toast.LENGTH_SHORT).show();
				     //getActivity().getSupportFragmentManager().popBackStack();
				}
				else{
					System.out.println("something wrong");
					
				}
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
	
}	
	private void showSaveDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(getString(R.string.confirm));
		alertDialogBuilder
				.setMessage(getString(R.string.sale_success))
				.setCancelable(false)
				.setPositiveButton(
						getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								getActivity().getSupportFragmentManager().popBackStack();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
	
	public void soaddDraft(){
		if(!isDraft){	
			
			salesOrderDetail.getOrder().getCustomer().setId(customer_id);
			salesOrderDetail.getOrder().getOrder().setCustomer_id(customer_id);
			salesOrderDetail.getOrder().getCustomer().setFirst_name(aq.id(R.id.buttonCustomer).getButton().getText().toString());
			
			salesOrderDetail.getOrder().getOrder().setOrder_date(aq.id(R.id.editTextSalesDate).getEditText().getText().toString());
			String sodraftJsonString = salesOrderDetail.createJson(aq,true);
			SharedPreferences soprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
			Editor edt = soprefs.edit();
			edt.putString("sodraftJsonString", sodraftJsonString);
			edt.commit();
			isDraft = true;
		}
	}
	
	
	
	public void sofillfromDraft(){
		SharedPreferences soprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		String sodraftJsonString = soprefs.getString("sodraftJsonString", null);
		//System.out.println("LISTSALES:"+sodraftJsonString);
		if(sodraftJsonString != null){
			try {
				JSONObject orderJson = new JSONObject(sodraftJsonString);
				
				customer_id = orderJson.isNull("customer_id") ? ""	: orderJson.getString("customer_id");
				salesOrderDetail.getOrder().getOrder().setCustomer_id(customer_id);
				String CustomerName = orderJson.isNull("customer_name") ? ""	: orderJson.getString("customer_name");
				aq.id(R.id.buttonCustomer).text(CustomerName);
				
				String OrderDate = orderJson.isNull("sale_date") ? ""	: orderJson.getString("sale_date");
				aq.id(R.id.editTextSalesDate).text(OrderDate);
				
			

			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	
}
