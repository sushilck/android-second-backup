package com.smalution.y3distributionguco1.fragments.distributorsalesorder;

import org.json.JSONException;
import org.json.JSONObject;

import com.smalution.y3distributionguco1.AppManager;
import com.smalution.y3distributionguco1.R;
import com.smalution.y3distributionguco1.entities.distributor.Distributor;
import com.smalution.y3distributionguco1.entities.distributor.DistributorDetail;
import com.smalution.y3distributionguco1.entities.distributor.DistributorFreeItem;
import com.smalution.y3distributionguco1.entities.distributor.DistributorSale;
import com.smalution.y3distributionguco1.entities.salesorder.SalesOrder;
import com.smalution.y3distributionguco1.entities.salesorder.SalesOrderDetail;
import com.smalution.y3distributionguco1.entities.settings.Brands;
import com.smalution.y3distributionguco1.fragments.SuperFragment;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.androidquery.AQuery;


public class DistributorSalesOrderViewFragment extends SuperFragment 
{
	Distributor distributor;
	View rootView;
	AQuery aq; 
	ArrayAdapter<DistributorSale> adapter;
	ArrayAdapter<DistributorFreeItem> freeItemAdapter;
	DistributorDetail distributorDetail;
	public static final int FLAG_SELECT_CUSTOMER=101;
	UIHandler uiHandler;
	public static boolean isOnline=false;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		case FLAG_SELECT_CUSTOMER:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonCustomer).text(selectedValue);
        			break;
        		}
        	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	distributor=args.getParcelable("SALESORDER");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		distributor=getArguments().getParcelable("SALESORDER");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		
		
		
 
        rootView = inflater.inflate(R.layout.distributor_sales_order_view_fragment, container, false);
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        
        if(AppManager.isOnline(getActivity())){
        	isOnline=true;
        
        
        
        if(distributorDetail==null)
        {
        	new DistributorSalesOrderDetailAsyncTask(aq,distributor.getRedistributorSale().getId()).execute();
        }
        else
        {
        	try {
				initUI();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        }else{
        	isOnline=false;
        	try {
				initUI();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
        }
        return rootView;
    }
	private void initUI() throws JSONException 
	{
		if(isOnline)
		{
		
		ListView listView=aq.id(R.id.customerList).getListView();
		View header = LayoutInflater.from(getActivity()).inflate(R.layout.distributor_sales_order_view_list_header, null);
		listView.addHeaderView(header, null, false);
		View footer = LayoutInflater.from(getActivity()).inflate(R.layout.distributor_sales_order_view_list_footer, null);
		listView.addFooterView(footer, null, false);
		
		AQuery aqHeader=new AQuery(header);
		
		aqHeader.id(R.id.textViewRedistributor).text(distributor.getRedistributor().getFirst_name()+" "+distributor.getRedistributor().getLast_name());
		aqHeader.id(R.id.textViewCustomer).text(distributor.getCustomer().getFirst_name()+" "+distributor.getCustomer().getLast_name());
		aqHeader.id(R.id.textViewSalesDate).text(distributorDetail.getRdsale().getRedistributorSale().getSale_date());
		aqHeader.id(R.id.textViewCreatedDate).text(distributor.getRedistributorSale().getCreated());
		aqHeader.id(R.id.textViewSynchronizationData).text(distributor.getRedistributorSale().getModified());
		
		
		
		AQuery aqFooter=new AQuery(footer);
		float grandTotal=0f;
		for(DistributorSale sale:distributorDetail.getSales())
		{
			float val=Float.parseFloat(sale.getRedistributorSaleitem().getAmount());
			grandTotal=grandTotal+val;
		}
		aqFooter.id(R.id.textViewGrandTotal).text(""+grandTotal);
		
		adapter = new ArrayAdapter<DistributorSale>(this.getActivity(), R.layout.distributor_sales_order_view_list_item, distributorDetail.getSales())
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.distributor_sales_order_view_list_item, parent, false);
	            }
	            AQuery aql=new AQuery(convertView);
	            if(isOnline){
	            DistributorSale sales=(DistributorSale)getItem(position);
	            aql.id(R.id.textViewSerialNo).text(sales.getRedistributorSaleitem().getId());	            
	            aql.id(R.id.textViewBrand).text(sales.getBrand().getName());
	            aql.id(R.id.textViewUnit).text(sales.getRedistributorSaleitem().getUnit());
	            aql.id(R.id.textViewUnitPrice).text(sales.getRedistributorSaleitem().getUnit_price());
	            aql.id(R.id.textViewQuantity).text(sales.getRedistributorSaleitem().getQuantity());
	            aql.id(R.id.textViewTotal).text(sales.getRedistributorSaleitem().getAmount());
	        	
	            }
	            else{
	            	
	            }
	            return convertView;
	        }
		};
		listView.setAdapter(adapter);
		
		ListView freeItemsView=aq.id(R.id.freeItemsList).getListView();
		
		View freeItemsHeader = LayoutInflater.from(getActivity()).inflate(R.layout.distributor_sales_order_view_list_freeitems_header, null);
		//freeItemsView.addHeaderView(freeItemsHeader, null, false);
		freeItemAdapter = new ArrayAdapter<DistributorFreeItem>(this.getActivity(), R.layout.distributor_sales_order_view_list_freeitems_item, distributorDetail.getFreeItems())
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.distributor_sales_order_view_list_freeitems_item, parent, false);
	            }
	            AQuery aql=new AQuery(convertView);
	            DistributorFreeItem freeItem=(DistributorFreeItem)getItem(position);
	            aql.id(R.id.textViewBrand).text(freeItem.getBrand().getName());
	            aql.id(R.id.textViewItem).text(freeItem.getRdFreeItem().getQuantity()+" "+freeItem.getRdFreeItem().getUnit());
	            return convertView;
	        }
		};
		//freeItemsView.setAdapter(freeItemAdapter);
	}
	else{
		
		String jsonString=null;
		
		if("1".equals(distributor.getCustOffline().getIsOfflineAddedSales()))
		{
			String tempString=distributor.getCustOffline().getJsonData().substring(0, distributor.getCustOffline().getJsonData().length() - 1)+",";
			jsonString= tempString+distributor.getCustOffline().getOfflineJson();			
			
		}
		else{
			jsonString=distributor.getCustOffline().getJsonData();
		}
			
		JSONObject jsonObject = new JSONObject(jsonString);	
		distributorDetail = new DistributorDetail(jsonObject,1,distributor.getCustOffline().getJsonData());
		//DistributorSale salesorder=new DistributorSale(jsonObject);
		
		
		ListView listView=aq.id(R.id.customerList).getListView();
		View header = LayoutInflater.from(getActivity()).inflate(R.layout.distributor_sales_order_view_list_header, null);
		listView.addHeaderView(header, null, false);
		View footer = LayoutInflater.from(getActivity()).inflate(R.layout.distributor_sales_order_view_list_footer, null);
		listView.addFooterView(footer, null, false);
		
		AQuery aqHeader=new AQuery(header);
		
		aqHeader.id(R.id.textViewRedistributor).text(distributor.getRedistributor().getFirst_name()+" "+distributor.getRedistributor().getLast_name());
		aqHeader.id(R.id.textViewCustomer).text(distributor.getCustomer().getFirst_name()+" "+distributor.getCustomer().getLast_name());
		aqHeader.id(R.id.textViewSalesDate).text(distributorDetail.getRdsale().getRedistributorSale().getSale_date());
		aqHeader.id(R.id.textViewCreatedDate).text(distributor.getRedistributorSale().getCreated());
		aqHeader.id(R.id.textViewSynchronizationData).text(distributor.getRedistributorSale().getModified());
		
		
		
		AQuery aqFooter=new AQuery(footer);
		float grandTotal=0f;
		for(DistributorSale sale:distributorDetail.getSales())
		{
			float val=Float.parseFloat(sale.getRedistributorSaleitem().getAmount());
			grandTotal=grandTotal+val;
		}
		aqFooter.id(R.id.textViewGrandTotal).text(""+grandTotal);
		
		adapter = new ArrayAdapter<DistributorSale>(this.getActivity(), R.layout.distributor_sales_order_view_list_item, distributorDetail.getSales())
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.distributor_sales_order_view_list_item, parent, false);
	            }
	            AQuery aql=new AQuery(convertView);
	           
	            DistributorSale sales=(DistributorSale)getItem(position);
	            aql.id(R.id.textViewSerialNo).text(sales.getRedistributorSaleitem().getId());
	            Brands brands = AppManager.getInstance().getBrands(aq);				
	            aql.id(R.id.textViewBrand).text(brands.getBrandById(sales.getRedistributorSaleitem().getBrand_id()).getName());
	            //aql.id(R.id.textViewBrand).text(sales.getBrand().getName());
	            aql.id(R.id.textViewUnit).text(sales.getRedistributorSaleitem().getUnit());
	            aql.id(R.id.textViewUnitPrice).text(sales.getRedistributorSaleitem().getUnit_price());
	            aql.id(R.id.textViewQuantity).text(sales.getRedistributorSaleitem().getQuantity());
	            aql.id(R.id.textViewTotal).text(sales.getRedistributorSaleitem().getAmount());
	           
	            return convertView;
	        }
		};
		listView.setAdapter(adapter);
		
		ListView freeItemsView=aq.id(R.id.freeItemsList).getListView();
		
		
		
		
		freeItemsView.setVisibility(aq.GONE);
		View freeItemsHeader = LayoutInflater.from(getActivity()).inflate(R.layout.distributor_sales_order_view_list_freeitems_header, null);
		//freeItemsView.addHeaderView(freeItemsHeader, null, false);
		freeItemAdapter = new ArrayAdapter<DistributorFreeItem>(this.getActivity(), R.layout.distributor_sales_order_view_list_freeitems_item, distributorDetail.getFreeItems())
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.distributor_sales_order_view_list_freeitems_item, parent, false);
	            }
	            AQuery aql=new AQuery(convertView);
	            DistributorFreeItem freeItem=(DistributorFreeItem)getItem(position);
	            //aql.id(R.id.textViewBrand).text(freeItem.getBrand().getName());
	            aql.id(R.id.textViewItem).text(freeItem.getRdFreeItem().getQuantity()+" "+freeItem.getRdFreeItem().getUnit());
	            return convertView;
	        }
		};
		//freeItemsView.setAdapter(freeItemAdapter);

	}
	}

	private class DistributorSalesOrderDetailAsyncTask extends AsyncTask<Void, Void, DistributorDetail>
	{
		AQuery aq;
		String rdsale_id;
		ProgressDialog progressDialog;
		public DistributorSalesOrderDetailAsyncTask(AQuery aq, String rdsale_id)
		{
			this.aq=aq;
			this.rdsale_id=rdsale_id;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected DistributorDetail doInBackground(Void... params) 
		{
			try
			{
				return AppManager.getInstance().getDistributorSalesOrderDetail(aq,rdsale_id);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				return null;
			}
		}
		@Override
		protected void onPostExecute(DistributorDetail result) 
		{
			super.onPostExecute(result);
			if(result!=null)
			{
				distributorDetail=result;
				try {
					initUI();
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				adapter.notifyDataSetChanged();
			}
			else
			{
				Toast.makeText(getActivity(), getString(R.string.no_distributor_sale_detail), Toast.LENGTH_SHORT).show();
			}
			progressDialog.dismiss();
		}
	}
}
