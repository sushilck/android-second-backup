package com.smalution.y3distributionguco1.entities.customervisits;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class CustVisitDepot implements Parcelable
{
	private String id;
	private String region_id;
	private String title;
	public CustVisitDepot(){}
	public CustVisitDepot(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			region_id=jsonObect.isNull("region_id")?"":jsonObect.getString("region_id");
			title=jsonObect.isNull("title")?"":jsonObect.getString("title");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public CustVisitDepot(Parcel in)
 	{
		id = in.readString();
		region_id = in.readString();
		title = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(region_id);
 		dest.writeString(title);
	}
 	public static final Parcelable.Creator<CustVisitDepot> CREATOR = new Parcelable.Creator<CustVisitDepot>() 
 	{
 		public CustVisitDepot createFromParcel(Parcel in) 
 		{
 			return new CustVisitDepot(in);
 		}
 	
 		public CustVisitDepot[] newArray (int size) 
 		{
 			return new CustVisitDepot[size];
 		}
 	};
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRegion_id() {
		return region_id;
	}
	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
}
