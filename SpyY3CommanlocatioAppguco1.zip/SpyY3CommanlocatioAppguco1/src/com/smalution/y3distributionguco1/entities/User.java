package com.smalution.y3distributionguco1.entities;

import org.json.JSONObject;

public class User 
{
	private String phone;
	private String fax;
    private String role_id;
    private String status;
    private String create_by;
    private String depot_id;
    private String zipcode;
    private String region_id;
    private String session_token;
    private String modified;
    private String country;
    private String city;
    private String id;
    private String state_id;
    private String first_name;
    private String username;
    private String login_time;
    private String image_url;
    private String created;
    private String address;
    private String email;
    private String file_id;
    private String birthdate;
    private String last_name;
    private String mobile;
	
	JSONObject jsonObject;
	public User(JSONObject jsonObject)
	{
		this.jsonObject=jsonObject;
		if(jsonObject!=null)
			init();
	}
	private void init()
	{
		try
		{
			phone=jsonObject.isNull("phone")?"":jsonObject.getString("phone");
			fax=jsonObject.isNull("fax")?"":jsonObject.getString("fax");
		    role_id=jsonObject.isNull("role_id")?"":jsonObject.getString("role_id");
		    status=jsonObject.isNull("status")?"":jsonObject.getString("status");
		    create_by=jsonObject.isNull("create_by")?"":jsonObject.getString("create_by");
		    depot_id=jsonObject.isNull("depot_id")?"":jsonObject.getString("depot_id");
		    zipcode=jsonObject.isNull("zipcode")?"":jsonObject.getString("zipcode");
		    region_id=jsonObject.isNull("region_id")?"":jsonObject.getString("region_id");
		    session_token=jsonObject.isNull("session_token")?"":jsonObject.getString("session_token");
		    modified=jsonObject.isNull("modified")?"":jsonObject.getString("modified");
		    country=jsonObject.isNull("country")?"":jsonObject.getString("country");
		    city=jsonObject.isNull("city")?"":jsonObject.getString("city");
		    id=jsonObject.isNull("id")?"":jsonObject.getString("id");
		    state_id=jsonObject.isNull("state_id")?"":jsonObject.getString("state_id");
		    first_name=jsonObject.isNull("first_name")?"":jsonObject.getString("first_name");
		    username=jsonObject.isNull("username")?"":jsonObject.getString("username");
		    login_time=jsonObject.isNull("login_time")?"":jsonObject.getString("login_time");
		    image_url=jsonObject.isNull("image_url")?"":jsonObject.getString("image_url");
		    created=jsonObject.isNull("created")?"":jsonObject.getString("created");
		    address=jsonObject.isNull("address")?"":jsonObject.getString("address");
		    email=jsonObject.isNull("email")?"":jsonObject.getString("email");
		    file_id=jsonObject.isNull("file_id")?"":jsonObject.getString("file_id");
		    birthdate=jsonObject.isNull("birthdate")?"":jsonObject.getString("birthdate");
		    last_name=jsonObject.isNull("last_name")?"":jsonObject.getString("last_name");
		    mobile=jsonObject.isNull("mobile")?"":jsonObject.getString("mobile");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getRole_id() {
		return role_id;
	}
	public void setRole_id(String role_id) {
		this.role_id = role_id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreate_by() {
		return create_by;
	}
	public void setCreate_by(String create_by) {
		this.create_by = create_by;
	}
	public String getDepot_id() {
		return depot_id;
	}
	public void setDepot_id(String depot_id) {
		this.depot_id = depot_id;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getRegion_id() {
		return region_id;
	}
	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}
	public String getSession_token() {
		return session_token;
	}
	public void setSession_token(String session_token) {
		this.session_token = session_token;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getState_id() {
		return state_id;
	}
	public void setState_id(String state_id) {
		this.state_id = state_id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getLogin_time() {
		return login_time;
	}
	public void setLogin_time(String login_time) {
		this.login_time = login_time;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFile_id() {
		return file_id;
	}
	public void setFile_id(String file_id) {
		this.file_id = file_id;
	}
	public String getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getImage_url() {
		return image_url;
	}
	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}
	
}
