package com.smalution.y3distributionguco1.entities.settings;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.json.JSONObject;

public class PaymentModes 
{
	Map<String, String> paymentModes;
	String[] name;
	public PaymentModes(){}
	public PaymentModes(JSONObject jsonObject)
	{
		try
		{
			paymentModes=new HashMap<String, String>();
			Iterator itr = jsonObject.keys();
			name=new String[jsonObject.length()];
			int i=0;
			while(itr.hasNext())
			{
				String key = (String)itr.next();
				String value = (String) jsonObject.getString(key);
				paymentModes.put(key, value);
				name[i]=value;
				i++;
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getNameById(String id)
	{
		Set<Entry<String , String>> entries = paymentModes.entrySet();
		Iterator<Entry<String , String>> itr = entries.iterator();
		while(itr.hasNext())
		{
			Entry entry = itr.next();
			String d=(String)entry.getValue();
			if(d.equals(id))
			{
				return (String)entry.getKey();
			}
		}
		return null;
	}
	public String getId(String name)
	{
		return paymentModes.get(name);
	}
	public Map<String, String> getPaymentModes() {
		return paymentModes;
	}
	public void setPaymentModes(Map<String, String> paymentModes) {
		this.paymentModes = paymentModes;
	}
	public String[] getName() {
		return name;
	}
	public void setName(String[] name) {
		this.name = name;
	}
	
}
