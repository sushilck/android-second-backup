package com.smalution.y3distributionguco1.entities.salesorder;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class SOSale implements Parcelable
{
	private String depot_id;
    private String brand_id;
    private String order_id;
    private String unit_price;
    private String modified;
    private String amount;
    private String id;
    private String unit;
    private String created;
    private String quantity;
    private String user_id;
    private String sale_date;
    private String cal_qty;
    private String customer_id;
    
    
	public SOSale(){}
	public SOSale(JSONObject jsonObect)
	{
		try
		{
			depot_id=jsonObect.isNull("depot_id")?"":jsonObect.getString("depot_id");
		    brand_id=jsonObect.isNull("brand_id")?"":jsonObect.getString("brand_id");
		    order_id=jsonObect.isNull("order_id")?"":jsonObect.getString("order_id");
		    unit_price=jsonObect.isNull("unit_price")?"":jsonObect.getString("unit_price");
		    modified=jsonObect.isNull("status")?"":jsonObect.getString("status");
		    amount=jsonObect.isNull("amount")?"":jsonObect.getString("amount");
		    id=jsonObect.isNull("id")?"":jsonObect.getString("id");
		    unit=jsonObect.isNull("unit")?"":jsonObect.getString("unit");
		    created=jsonObect.isNull("created")?"":jsonObect.getString("created");
		    quantity=jsonObect.isNull("quantity")?"":jsonObect.getString("quantity");
		    user_id=jsonObect.isNull("user_id")?"":jsonObect.getString("user_id");
		    sale_date=jsonObect.isNull("sale_date")?"":jsonObect.getString("sale_date");
		    cal_qty=jsonObect.isNull("cal_qty")?"":jsonObect.getString("cal_qty");
		    customer_id=jsonObect.isNull("customer_id")?"":jsonObect.getString("customer_id");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public SOSale(Parcel in)
 	{
		depot_id = in.readString();
	    brand_id = in.readString();
	    order_id = in.readString();
	    unit_price = in.readString();
	    modified = in.readString();
	    amount = in.readString();
	    id = in.readString();
	    unit = in.readString();
	    created = in.readString();
	    quantity = in.readString();
	    user_id = in.readString();
	    sale_date = in.readString();
	    cal_qty = in.readString();
	    customer_id = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(depot_id);
 	    dest.writeString(brand_id);
 	    dest.writeString(order_id);
 	    dest.writeString(unit_price);
 	    dest.writeString(modified);
 	    dest.writeString(amount);
 	    dest.writeString(id);
 	    dest.writeString(unit);
 	    dest.writeString(created);
 	    dest.writeString(quantity);
 	    dest.writeString(user_id);
 	    dest.writeString(sale_date);
 	    dest.writeString(cal_qty);
 	    dest.writeString(customer_id);
 	}
 	public static final Parcelable.Creator<SOSale> CREATOR = new Parcelable.Creator<SOSale>() 
 	{
 		public SOSale createFromParcel(Parcel in) 
 		{
 			return new SOSale(in);
 		}
 	
 		public SOSale[] newArray (int size) 
 		{
 			return new SOSale[size];
 		}
 	};


	public String getDepot_id() {
		return depot_id;
	}
	public void setDepot_id(String depot_id) {
		this.depot_id = depot_id;
	}
	public String getBrand_id() {
		return brand_id;
	}
	public void setBrand_id(String brand_id) {
		this.brand_id = brand_id;
	}
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	public String getUnit_price() {
		return unit_price;
	}
	public void setUnit_price(String unit_price) {
		this.unit_price = unit_price;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getSale_date() {
		return sale_date;
	}
	public void setSale_date(String sale_date) {
		this.sale_date = sale_date;
	}
	public String getCal_qty() {
		return cal_qty;
	}
	public void setCal_qty(String cal_qty) {
		this.cal_qty = cal_qty;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	} 	
}
