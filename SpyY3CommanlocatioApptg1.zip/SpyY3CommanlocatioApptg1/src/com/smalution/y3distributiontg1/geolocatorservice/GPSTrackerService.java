package com.smalution.y3distributiontg1.geolocatorservice;


import java.io.File;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlarmManager;
import android.app.IntentService;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;

import com.androidquery.AQuery;
import com.androidquery.callback.AjaxStatus;
import com.androidquery.callback.LocationAjaxCallback;
import com.smalution.y3distributiontg1.AppManager;
import com.smalution.y3distributiontg1.Utils;
import com.smalution.y3distributiontg1.database.MySQLiteHelper;
import com.smalution.y3distributiontg1.database.Y3Query;
import com.smalution.y3distributiontg1.database.Y3QueryDataSource;
import com.smalution.y3distributiontg1.utils.Constants;

public class GPSTrackerService extends IntentService 
{
	AppManager appManager;
	//private long servedTimeSlice=120000l;
	public GPSTrackerService()
	{
		super("GPSTrackerService");
		System.out.println("This is Backend Services is working all the time...");
	}
	public void locationCB(String url, Location loc, AjaxStatus status)
	{
		Log.d("MTK","status GPSAlert locationCB :"+status.getCode());
		
		long currentTime = System.currentTimeMillis();
		SharedPreferences prefs=getSharedPreferences("BGGeoCollector", MODE_PRIVATE);
		long previousDataSendTime = prefs.getLong("PREVIOUS_DATA_SEND_TIME", 0l);
		long timeSlice = prefs.getLong("timeSlice", 0l);
		if((currentTime-previousDataSendTime)>=timeSlice)//check for 3 min
		{
			prefs.edit().putLong("PREVIOUS_DATA_SEND_TIME", currentTime).commit();
			double previousLat = Double.parseDouble(prefs.getString("LATTITUDE", "0.0"));
			double previousLong = Double.parseDouble(prefs.getString("LONGITUDE", "0.0"));
			
			GPSTracker locTrack = new GPSTracker(GPSTrackerService.this);
			if(loc!=null)
			{
				if(previousLat==loc.getLatitude() && previousLong==loc.getLongitude())
				{
					Log.d("MTK", "same lat long! = "+previousLat+"=="+loc.getLatitude()+", "+previousLong+"=="+loc.getLongitude());
				}
				else
				{
					Editor edt2 = prefs.edit();
					edt2.putString("LATTITUDE", String.valueOf(loc.getLatitude()));
					edt2.putString("LONGITUDE", String.valueOf(loc.getLongitude()));
					edt2.commit();
					
					Log.d("MTK", "lat:"+loc.getLatitude()+", long:"+loc.getLongitude());
					Map<String, Object> params = new HashMap<String, Object>();
					params.put("user_id", prefs.getString("user_id", ""));
					params.put("token", prefs.getString("token", ""));
					params.put("lat", loc.getLatitude());
					params.put("long", loc.getLongitude());
					
					String dateStr = android.text.format.DateFormat.format("yyyy-MM-dd kk:mm:ss", new java.util.Date()).toString();
					params.put("tracking_time", dateStr);
					if(loc.getLatitude() != 0 && loc.getLongitude() != 0){
						Y3QueryDataSource datasource = new Y3QueryDataSource(GPSTrackerService.this);
						datasource.open();
						datasource.insertTracking(String.valueOf(loc.getLatitude()), String.valueOf(loc.getLongitude()), dateStr);
						datasource.close();	
					}
					//appManager.sendLatLong(new AQuery(getApplicationContext()), params);
				}
			}
    	}
	}
	private void sendY3Queries() throws Exception
	{
		Y3QueryDataSource datasource = new Y3QueryDataSource(GPSTrackerService.this);
	    datasource.open();
	    List<Y3Query> result = datasource.getAllY3Queries();
	    for(int i=0;i<result.size();i++)
	    {
	    	Y3Query y3q=result.get(i);
	    	if(y3q.getAction().equals(Y3QueryDataSource.ACTION_CUSTOMER_ADD))
	    	{
	    		Hashtable<String,String> params=new Hashtable<String,String>();
	    		params.put("jsonString", y3q.getJson());
	    		Hashtable<String,File> fileParams=null;
	    		if(y3q.getImage()!=null && y3q.getImage().length()>0)
	    		{
	    			fileParams=new Hashtable<String,File>();
		    		fileParams.put("image", new File(y3q.getImage()));
	    		}
	    		String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_CUSTOMER, params, fileParams);
	    		if(examinServerResponse(datasource, y3q, response))
	    		{
	    			Hashtable<String,String> params2=new Hashtable<String,String>();
		    		SharedPreferences prefs=getSharedPreferences("BGGeoCollector", MODE_PRIVATE);
		    		String token = prefs.getString("token", "");
		    		params2.put("token", token);
		    		String response2 = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_SETTINGS_LIST_CUSTOMER, params2, null);
		    		if(response2!=null)
		    		{
		    			JSONObject rootJSONObject= new JSONObject(response2);
		    			JSONObject dataJSONObject = rootJSONObject.isNull("data")?null:rootJSONObject.getJSONObject("data");
		    			if(dataJSONObject!=null)
		    			{
		    				JSONArray customerJSONArray = dataJSONObject.isNull(Constants.PREFKEY_CUSTOMERS)?null:dataJSONObject.getJSONArray(Constants.PREFKEY_CUSTOMERS);
		    				if(customerJSONArray!=null)
		    				{
		    					Editor edt = prefs.edit();
			    				edt.putString(Constants.PREFKEY_CUSTOMERS, customerJSONArray.toString());
			    				edt.commit();
		    				}
		    			}
		    		}
	    		}
	    	}
	    	else if(y3q.getAction().equals(Y3QueryDataSource.ACTION_CUSTOMERVISIT_ADD))
	    	{
	    		Hashtable<String,String> params=new Hashtable<String,String>();
	    		params.put("jsonString", y3q.getJson());
	    		String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_CUSTOMERVISITS, params, null);
	    		Log.d("MTK", "server response: "+response);
	    		examinServerResponse(datasource, y3q, response);
	    	}
	    	else if(y3q.getAction().equals(Y3QueryDataSource.ACTION_SALESORDER_ADD))
	    	{
	    		Hashtable<String,String> params=new Hashtable<String,String>();
	    		params.put("jsonString", y3q.getJson());
	    		String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_SALESORDER, params, null);
	    		Log.d("MTK", "server response: "+response);
	    		examinServerResponse(datasource, y3q, response);
	    	}
	    	else if(y3q.getAction().equals(Y3QueryDataSource.ACTION_DISTRIBUTOR_SALESORDER_ADD))
	    	{
	    		Hashtable<String,String> params=new Hashtable<String,String>();
	    		params.put("jsonString", y3q.getJson());
	    		String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_DISTRIBUTOR_SALESORDER, params, null);
	    		Log.d("MTK", "server response: "+response);
	    		examinServerResponse(datasource, y3q, response);
	    	}
	    	else if(y3q.getAction().equals(Y3QueryDataSource.ACTION_PAYMENT_ADD))
	    	{
	    		Hashtable<String,String> params=new Hashtable<String,String>();
	    		params.put("jsonString", y3q.getJson());
	    		String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_PAYMENTS, params, null);
	    		Log.d("MTK", "server response: "+response);
	    		examinServerResponse(datasource, y3q, response);
	    	}
	    	else if(y3q.getAction().equals(Y3QueryDataSource.ACTION_EXPENSE_ADD))
	    	{
	    		Hashtable<String,String> params=new Hashtable<String,String>();
	    		params.put("jsonString", y3q.getJson());
	    		String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_EXPENSE, params, null);
	    		Log.d("MTK", "server response: "+response);
	    		examinServerResponse(datasource, y3q, response);
	    	}
	    	else if(y3q.getAction().equals(Y3QueryDataSource.ACTION_INCENTIVE_ADD))
	    	{
	    		Hashtable<String,String> params=new Hashtable<String,String>();
	    		params.put("jsonString", y3q.getJson());
	    		String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_INCENTIVE, params, null);
	    		Log.d("MTK", "server response: "+response);
	    		examinServerResponse(datasource, y3q, response);
	    	}
	    	else
	    	{
	    		Log.d("MTK", "!UNKNOWN ACTION TYPE FOUND");
	    	}
	    }
	    Log.d("MTK","getAllY3Queries size: "+result.size());
	    datasource.close();
	}
	private boolean examinServerResponse(Y3QueryDataSource datasource,Y3Query y3q, String response)throws Exception
	{
		Log.d("MTK", "server response: "+response);
		if(response!=null)
		{
			int errorCode=new JSONObject(response).getInt("error");
			if(errorCode==0)
			{
				boolean isQueryDeleted = datasource.deleteY3Query(y3q.get_id());
				if(y3q.getImage()!=null && y3q.getImage().length()>0 && new File(y3q.getImage()).exists())
					new File(y3q.getImage()).delete();
	    		Log.d("MTK","isQueryDeleted:"+isQueryDeleted);
	    		return true;
	    	}
			else
			{
				datasource.insertServerLog(y3q.get_id(), "PENDING", "ERROR", response);
			}
		}
		else
		{
			datasource.insertServerLog(y3q.get_id(), "PENDING", "ERROR", "server response is \"null\"");
		}
		return false;
	}
	@Override
	protected void onHandleIntent(Intent intent) 
	{
		//System.out.println("<<<<<<<<<<This is just onHandleIntent>>>>>>");
		appManager=AppManager.getInstance();
		long currentTime = System.currentTimeMillis();
		SharedPreferences prefs=getSharedPreferences("BGGeoCollector", MODE_PRIVATE);
		Editor edt = prefs.edit();
		edt.putLong("LAST_SERVE_TIME", currentTime);
		edt.commit();
		
		boolean isRunService = prefs.getBoolean("isRunService", false);
		long timeSlice = prefs.getLong("timeSlice", 0l);
		if(isRunService)
		{
			if(appManager.isOnline(getApplicationContext()))
			{
				try
				{
					//sendY3Queries();
					//1
					CustomerQueryies();
					
					//2
					customerVisitQuery();
					
					//3 
					salesQuery();
					
					//
					distributorSalesQuery();
					
					//5
					incentivesQuery();
					
					//6
					paymentQuery();
					
					//7
					expensesQuery();
					snedlatlong();
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
				
				
				LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
				boolean isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
				if(isGPSEnabled)
				{
					try
					{
						LocationAjaxCallback lac=new LocationAjaxCallback();
						lac.weakHandler(GPSTrackerService.this, "locationCB");
						lac.async(GPSTrackerService.this);
					}
					catch(NumberFormatException ex)
					{
						ex.printStackTrace();
					}
				}
				else
				{
					//open dialog to enable gps service
					Intent intent2=new Intent(this, GPSAlertDialogActivity.class);
					intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(intent2);
				}

				
				
				
				
				
//				GPSTracker gps = new GPSTracker(this);
//				if(gps.canGetLocation())
//				{
//					try
//					{
//						double previousLat = Double.parseDouble(prefs.getString("LATTITUDE", "0.0"));
//						double previousLong = Double.parseDouble(prefs.getString("LONGITUDE", "0.0"));
//						if(previousLat==gps.getLatitude() && previousLong==gps.getLongitude())
//						{
//							Log.d("MTK", "same lat long! = "+previousLat+"=="+gps.getLatitude()+", "+previousLong+"=="+gps.getLongitude());
//						}
//						else
//						{
//							Editor edt2 = prefs.edit();
//							edt2.putString("LATTITUDE", String.valueOf(gps.getLatitude()));
//							edt2.putString("LONGITUDE", String.valueOf(gps.getLongitude()));
//							edt2.commit();
//							
//							Log.d("MTK", "lat:"+gps.getLatitude()+", long:"+gps.getLongitude());
//							Map<String, Object> params = new HashMap<String, Object>();
//							params.put("user_id", prefs.getString("user_id", ""));
//							params.put("token", prefs.getString("token", ""));
//							params.put("lat", gps.getLatitude());
//							params.put("long", gps.getLongitude());
//							
//							String dateStr = android.text.format.DateFormat.format("yyyy-MM-dd hh:mm:ss", new java.util.Date()).toString();
//							params.put("tracking_time", dateStr);
//							appManager.sendLatLong(new AQuery(getApplicationContext()), params);
//						}
//					}
//					catch(NumberFormatException ex)
//					{
//						ex.printStackTrace();
//					}
//				}
//				else
//				{
//					//open dialog to enable gps service
//					gps.showSettingsAlert();
//				}
//				gps.stopUsingGPS();
			}
			else
			{
//				Intent intent2=new Intent(getApplicationContext(), NetworkAlertDialogActivity.class);
//	        	intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//	        	startActivity(intent2);
	        }
		
			Calendar cal = Calendar.getInstance();
	        cal.add(Calendar.SECOND, 10);
	        Intent serviceIntent = new Intent(this, GPSTrackerService.class);
	        PendingIntent pintent = PendingIntent.getService(this, 0, serviceIntent, 0);
	        AlarmManager alarm = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
	        //every 2 min
	        alarm.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(),timeSlice, pintent);
		}
		else
		{
			Log.d("MTK", "isRunService:"+isRunService);
		}
	}
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) 
	{
		super.onStartCommand(intent, flags, startId);
		return START_STICKY;
	}
	
	
	private void CustomerQueryies(){
		try{	
			
		// this is for add customer to server.......	
		Y3QueryDataSource datasource1;			
		datasource1 = new Y3QueryDataSource(GPSTrackerService.this);		 
		datasource1.open();
		Cursor cursor=datasource1.getCustomerData();
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {					
			if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ISOFFLINEADDED))))
			{				
				SharedPreferences prefs = AppManager.getInstance().getPrefs(GPSTrackerService.this);
				String token = prefs.getString("token", null);
				boolean isViewDetails;
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.VIEW_DETAILS)))){
					isViewDetails=true;
				}else{
					isViewDetails=false;
				}
				String json="{" +
						"\"token\":\""+token+"\","+"\"request_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REQUEST_ID))+"\"," ;
				json=json+"\"first_name\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.FIRST_NAME))+"\"," +
						"\"last_name\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LAST_NAME))+"\"," +
						"\"email\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EMAIL_ID))+"\"," +
						"\"route_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ROUTE_ID))+"\"," +
						"\"address\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ADDRESS))+"\"," +
						"\"city\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CITY))+"\"," +
						"\"state_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.STATE_ID))+"\"," +
						"\"latitude\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LATITUDE))+"\"," +
						"\"longitude\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LONGITUDE))+"\"," +
						"\"zipcode\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ZIPCODE))+"\"," +
						"\"created\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CREATED_DATE))+"\"," +
						"\"phone\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PHONE))+"\"," +
						"\"region_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REGION_ID))+"\"," +
						"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DEPOT_ID))+"\"," +
						"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LGAREA_ID))+"\"," +
						"\"description\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DESCRIPTION))+"\"," +
						"\"view_details\":\""+isViewDetails+"\"" ;								
						json=json+",\"assignToOption\":"+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ASSIGNTO));
				json=json+"}";
				
				
				 	Hashtable<String,String> paramforAddcustomer=new Hashtable<String,String>();
				 	paramforAddcustomer.put("jsonString", json);
				 	
					Hashtable<String,File> fileParams=null;
					String imagePath=cursor.getString(cursor.getColumnIndex(MySQLiteHelper.IMAGE_PATH));
		    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
		    		{
		    			fileParams=new Hashtable<String,File>();
			    		fileParams.put("image", new File(imagePath));
		    		}
		    		//Utils.post(context, url, parameters, fileParams);
				    String response = Utils.post(GPSTrackerService.this,AppManager.getInstance().URL_UPDATE_CUSTOMER, paramforAddcustomer, fileParams);
				    System.out.println("This is Addcustomer Server response"+response);
				    if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasource1.updateISAdded(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_ID)));
			
					}
				    }
			}
			
			cursor.moveToNext();
			}
		datasource1.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
		//this portion for DeleteData From Server.....
		//------------------------------------------------------
		
		Y3QueryDataSource datasource ;//;= new Y3QueryDataSource(getActivity());		
			datasource = new Y3QueryDataSource(GPSTrackerService.this);
		
		datasource.open();
		
		try{
		
		List<Y3Query> result = datasource.getAllY3Queries();
		for (int i = 0; i < result.size(); i++) {
			Y3Query y3q = result.get(i);
			if (y3q.getAction().equals(Y3QueryDataSource.ACTION_CUSTOMER_DELETE)) {
				Hashtable<String, String> params1 = new Hashtable<String, String>();
				params1.put("jsonString", y3q.getJson());
				String response = Utils.post(GPSTrackerService.this,AppManager.getInstance().URL_DELETE_CUSTOMER,params1, null);
				Log.d("MTK", "server response: " + response);
				System.out.println("This is DeleteCustomer Server response"+response);

				try {
					if (response != null
							&& new JSONObject(response).getInt("error") == 0) {
						boolean isQueryDeleted = datasource.deleteY3Query(y3q.get_id());
						Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}
			}

		}
		}catch(Exception e){
			e.printStackTrace();
		}
		datasource.close();
		
		//-------------------------------------------------------------------------------------------------------------
		// this is for edit data is......
		
		try {
			
				Y3QueryDataSource datasource1;			
				datasource1 = new Y3QueryDataSource(GPSTrackerService.this);			
				datasource1.open();
				Cursor cursor=datasource1.getCustomerData();
				cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ISOFFLINEEDITED))))
				{				
					SharedPreferences prefs = AppManager.getInstance().getPrefs(GPSTrackerService.this);
					String token = prefs.getString("token", null);
					boolean isViewDetails=true;
					
					String json="{" +"\"token\":\""+token+"\",";	
					if(!false)
					{
						json=json+"\"id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_ID))+"\"," +
						"\"oldFile_id\":\""+0+"\",";
					}
				
					json=json+"\"first_name\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.FIRST_NAME))+"\"," +
							"\"last_name\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LAST_NAME))+"\"," +
							"\"email\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EMAIL_ID))+"\"," +
							"\"route_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ROUTE_ID))+"\"," +
							"\"address\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ADDRESS))+"\"," +
							"\"city\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CITY))+"\"," +
							"\"state_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.STATE_ID))+"\"," +
							"\"latitude\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LATITUDE))+"\"," +
							"\"longitude\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LONGITUDE))+"\"," +
							"\"zipcode\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ZIPCODE))+"\"," +
							"\"phone\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PHONE))+"\"," +
							"\"region_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REGION_ID))+"\"," +
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DEPOT_ID))+"\"," +
							"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LGAREA_ID))+"\"," +
							"\"description\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DESCRIPTION))+"\"," +
							"\"view_details\":\""+isViewDetails+"\"" ;								
					json=json+"}";		
					System.out.println("edit json add"+json);
					 Hashtable<String,String> parametersforEdit=new Hashtable<String,String>();
					 parametersforEdit.put("jsonString", json);
						Hashtable<String,File> fileParams=null;
						String imagePath=cursor.getString(cursor.getColumnIndex(MySQLiteHelper.IMAGE_PATH));
			    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
			    		{
			    			fileParams=new Hashtable<String,File>();
				    		fileParams.put("image", new File(imagePath));
			    		}
			    		//Utils.post(context, url, parameters, fileParams);
					    String response = Utils.post(GPSTrackerService.this,AppManager.getInstance().URL_UPDATE_CUSTOMER, parametersforEdit, fileParams);
					    System.out.println("This is EditCustomer Server response"+response);
					    if(response!=null){
					    int error = new JSONObject(response).getInt("error");
					    if (error == 0) 
						{
						System.out.println("All is welll");
						datasource1.updateISUpdated(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_ID)));
						}
					    }
					    Log.d("MTK", "ISUPDATE:" + response);   
	
					}
				

			
			cursor.moveToNext();
			}
		datasource1.close();
		}
		catch(Exception e){
			System.out.println("Error In Edit Customer");
			e.printStackTrace();
		}
			
	}
	
	public void expensesQuery(){
		Y3QueryDataSource datasource1 = null;
		try{	
			datasource1 = new Y3QueryDataSource(GPSTrackerService.this);			
			datasource1.open();			
			Cursor cursor=datasource1.getExpenceData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) 
			{					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENCE_OFFLINE_ADD))))
				{				
					SharedPreferences prefs = AppManager.getInstance().getPrefs(GPSTrackerService.this);
					String token = prefs.getString("token", null);
					String json="{" +"\"token\":\""+token+"\","+
							"\"request_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REQUEST_ID))+"\","+
							"\"created\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CREATED_DATE))+"\"," ;
					json=json+
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_DEPOT_ID))+"\"," +
							"\"region_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_REGION_ID))+"\"," +
							"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_BRAND_ID))+"\"," +
							"\"exp_amount\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_EXP_AMOUNT))+"\"," +
							"\"exp_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_EXP_DATA))+"\"," +
//							"\"payment_mode\":\""+getExpense().getPayment_mode()+"\"," +
							"\"expense_ref\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_REF))+"\"," +
							"\"description\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_DESCRIPTION))+"\"," +
							"\"exp_type_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_TYPE_ID))+"\"" +
							"}";						
					Hashtable<String,String> params=new Hashtable<String,String>();
		    		params.put("jsonString", json);
		    		String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_EXPENSE, params, null);
		    		System.out.println("Check expence is add or not "+response);
		    		if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISADDED:" + response);
					System.out.println(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_ID)));
					datasource1.expenseupdateISAdded(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_ID)));
			
					}
				    }
				}
			 cursor.moveToNext();
			}
			datasource1.close();
		}
		catch(Exception sqException){
			datasource1.close();
			System.out.println("Exception In Add Expenses Data");
			sqException.printStackTrace();
		}

		// this is for delete data from server,,,,,,,,,,

		Y3QueryDataSource datasource ;//;= new Y3QueryDataSource(getActivity());
		
		
			datasource = new Y3QueryDataSource(GPSTrackerService.this);
		
		datasource.open();
		List<Y3Query> result = datasource.getAllY3Queries();
		for (int i = 0; i < result.size(); i++) {
			Y3Query y3q = result.get(i);
			if (y3q.getAction().equals(
					Y3QueryDataSource.ACTION_EXPENCE_DELETE)) {
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", y3q.getJson());
				Hashtable<String,File> fileParams=null;
				String imagePath=null;
	    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
	    		{
	    			fileParams=new Hashtable<String,File>();
		    		fileParams.put("image", new File(imagePath));
	    		}
			    String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_DELETE_EXPENSE, parameters, fileParams);

				try {
					if (response != null
							&& new JSONObject(response).getInt("error") == 0) {
						boolean isQueryDeleted = datasource
								.deleteY3Query(y3q.get_id());
						Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}
			}

		}
		datasource.close();
		
		
		
		// this is for edit expence from server....................................................
		try{
				Y3QueryDataSource datasourceedit;
			
				datasourceedit = new Y3QueryDataSource(GPSTrackerService.this);
			
			datasourceedit.open();
			Cursor cursor=datasourceedit.getExpenceData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENCE_OFFLINE_EDIT)))){				
					SharedPreferences prefs = AppManager.getInstance().getPrefs(GPSTrackerService.this);
					String token = prefs.getString("token", null);
					String json="{" +"\"token\":\""+token+"\","
					+"\"id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_ID))+"\",";
					json=json+
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_DEPOT_ID))+"\"," +
							"\"region_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_REGION_ID))+"\"," +
							"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_BRAND_ID))+"\"," +
							"\"exp_amount\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_EXP_AMOUNT))+"\"," +
							"\"exp_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_EXP_DATA))+"\"," +
//							"\"payment_mode\":\""+getExpense().getPayment_mode()+"\"," +
							"\"expense_ref\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_REF))+"\"," +
							"\"description\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_DESCRIPTION))+"\"," +
							"\"exp_type_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_EXPTYPE_ID))+"\"" +
							"}";	
					System.out.println(json);
					Hashtable<String,String> params=new Hashtable<String,String>();
		    		params.put("jsonString", json);
		    		Hashtable<String,File> fileParams=null;
		    		String imagePath=null;
		    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
		    		{
		    			fileParams=new Hashtable<String,File>();
			    		fileParams.put("image", new File(imagePath));
		    		}
		    		String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_EXPENSE, params, fileParams);
		    		System.out.println("Check expence is add or not "+response);
		    		if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasource1.expenseupdateIsEdited(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_ID)));			
					}
				    }
				}
			 cursor.moveToNext();
			}
			datasourceedit.close();
		}
		catch(Exception sqException){
			sqException.printStackTrace();
		}
	}

	public void paymentQuery(){
		try{
			Y3QueryDataSource datasource1; //= new Y3QueryDataSource(getActivity());
		
			datasource1 = new Y3QueryDataSource(GPSTrackerService.this);
			
			datasource1.open();
			Cursor cursor=datasource1.getPaymentData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_ISOFFLINEADDED)))){	
					SharedPreferences prefs = AppManager.getInstance().getPrefs(GPSTrackerService.this);
					String token = prefs.getString("token", null);
					String json="{" +
						"\"token\":\""+token+"\","+
							"\"request_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REQUEST_ID))+"\","
							+"\"created\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_CREATED))+"\"," ;
				
					json=json+
						"\"payment_mode\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_MODE))+"\"," +
						"\"bank_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_BANK_ID))+"\"," +
						"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_DEPOT_ID))+"\"," +
						"\"region_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_REGION_ID))+"\"," +
						"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_BRAND_ID))+"\"," +
						"\"distributor_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_DISTRIBUTOR_ID))+"\"," +
						"\"amount\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_AMOUNT))+"\"," +
						"\"payment_ref\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_REF))+"\"," +
						"\"transaction_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_TRANSACTION_ID))+"\"," +
						"\"payment_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_DATE))+"\"," +
						"\"notes\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_NOTES))+"\"" +
						"}";
					
					Hashtable<String,String> params1=new Hashtable<String,String>();
					params1.put("jsonString", json);			
					String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_PAYMENTS, params1, null);
					System.out.println("Response"+response);
					if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasource1.paymentupdateISAdded(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_ID)));			
					}
				    }
			}
			cursor.moveToNext();
		  }
			datasource1.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		

		Y3QueryDataSource datasource ; //= new Y3QueryDataSource(getActivity());
		
		 datasource = new Y3QueryDataSource(GPSTrackerService.this);
		
		datasource.open();
		List<Y3Query> result = datasource.getAllY3Queries();
		for (int i = 0; i < result.size(); i++) {
			Y3Query y3q = result.get(i);
			if (y3q.getAction().equals(
					Y3QueryDataSource.ACTION_PAYMENT_DELETE)) {
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", y3q.getJson());
				Hashtable<String,File> fileParams=null;
				String imagePath=null;
	    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
	    		{
	    			fileParams=new Hashtable<String,File>();
		    		fileParams.put("image", new File(imagePath));
	    		}
			    String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_DELETE_PAYMENTS, parameters, fileParams);

				try {
					if (response != null
							&& new JSONObject(response).getInt("error") == 0) {
						boolean isQueryDeleted = datasource
								.deleteY3Query(y3q.get_id());
						Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}
			}

		}
		datasource.close();
		// this is for edit.....
		
		try{
			
				Y3QueryDataSource datasource1 ;// = new Y3QueryDataSource(getActivity());				
			    datasource1 = new Y3QueryDataSource(GPSTrackerService.this);				
				datasource1.open();
				Cursor cursor=datasource1.getPaymentData();
				cursor.moveToFirst();
				while (!cursor.isAfterLast()) {					
					if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_ISOFFLINEEDITED)))){				
						SharedPreferences prefs = AppManager.getInstance().getPrefs(GPSTrackerService.this);
						String token = prefs.getString("token", null);
						String json="{" +
							"\"token\":\""+token+"\",";						
							json=json+"\"id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_ID))+"\",";					
							
						json=json+
							"\"payment_mode\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_MODE))+"\"," +
							"\"bank_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_BANK_ID))+"\"," +
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_DEPOT_ID))+"\"," +
							"\"region_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_REGION_ID))+"\"," +
							"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_BRAND_ID))+"\"," +
							"\"distributor_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_DISTRIBUTOR_ID))+"\"," +
							"\"amount\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_AMOUNT))+"\"," +
							"\"payment_ref\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_REF))+"\"," +
							"\"transaction_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_TRANSACTION_ID))+"\"," +
							"\"payment_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_DATE))+"\"," +
							"\"notes\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_NOTES))+"\"" +
							"}";
						
						Hashtable<String,String> parameters=new Hashtable<String,String>();
						parameters.put("jsonString", json);
						Hashtable<String,File> fileParams=null;
						String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_PAYMENTS, parameters, null);	
						if(response!=null)
					    {
					    int error = new JSONObject(response).getInt("error");
					    if (error == 0) 
						{
						System.out.println("All is welll");
						Log.d("MTK", "ISUPDATE:" + response); 					
						datasource1.paymentupdateISEdit(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_ID)));			
						}
					    }
					}
					cursor.moveToNext();
				}
				datasource1.close();
		   
		   }
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private void customerVisitQuery(){
		try{
			
			//System.out.println(getActivity().getApplicationContext());
			
			Y3QueryDataSource datasourcedelete ; //= new Y3QueryDataSource(getActivity());
			
			
			datasourcedelete = new Y3QueryDataSource(GPSTrackerService.this);		
			datasourcedelete.open();
			Cursor cursor=datasourcedelete.getCustomerVisitData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEADDED)))){				
					SharedPreferences prefs = AppManager.getInstance().getPrefs(GPSTrackerService.this);
					String token = prefs.getString("token", null);
					
					String json="{" +
							"\"token\":\""+token+"\","+"\"request_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REQUEST_ID))+"\","+
							"\"created\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CREATED_DATE))+"\",";
					
					
					if(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))==null)
					{
						json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))+"\"," +
								"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_LGAREAID))+"\"," +
								"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_DEPOTID))+"\"," +
								"\"visiting_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_VISITING_DATE))+"\"," +
								"\"comment\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_COMMENT))+"\"";
						json=json+",";
						json=json+"\"newCustomer\":" ;
						json=json+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMER_JSON));		
						json=json+"}";
					}
					else{
						
						json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))+"\"," +
								"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_LGAREAID))+"\"," +
								"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_DEPOTID))+"\"," +
								"\"visiting_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_VISITING_DATE))+"\"," +
								"\"comment\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_COMMENT))+"\"";
						json=json+"}";
						
					}
					
					Hashtable<String,String> params1=new Hashtable<String,String>();
		    		params1.put("jsonString",json);	
		    		//String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_INCENTIVE, params, null);
					String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_CUSTOMERVISITS, params1, null);
					System.out.println("The Response is now find "+response);
					
					if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasourcedelete.customerVisitupdateISAdded(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ID)));			
					}
				    }
					
					
					
					
					
				}
				cursor.moveToNext();
			}
			datasourcedelete.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		
	// this is for delete data from server.......	
		Y3QueryDataSource datasource ;// = new Y3QueryDataSource(getActivity());
	
			datasource = new Y3QueryDataSource(GPSTrackerService.this);
		
		datasource.open();
		List<Y3Query> result = datasource.getAllY3Queries();
		for (int i = 0; i < result.size(); i++) {
			Y3Query y3q = result.get(i);
			if (y3q.getAction().equals(
					Y3QueryDataSource.ACTION_CUSTOMER_VISITING_DELETE)) {
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", y3q.getJson());
				Hashtable<String,File> fileParams=null;
				String imagePath=null;
	    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
	    		{
	    			fileParams=new Hashtable<String,File>();
		    		fileParams.put("image", new File(imagePath));
	    		}
			    String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_DELETE_CUSTOMERVISITS, parameters, fileParams);

				try {
					if (response != null
							&& new JSONObject(response).getInt("error") == 0) {
						boolean isQueryDeleted = datasource
								.deleteY3Query(y3q.get_id());
						Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}
			}

		}
		datasource.close();
		// this is for edit.........................................URL_UPDATE_CUSTOMERVISITS
		try{
			Y3QueryDataSource datasourceedit ;//= new Y3QueryDataSource(getActivity());
			
				datasourceedit = new Y3QueryDataSource(GPSTrackerService.this);
			
			datasourceedit.open();
			Cursor cursor=datasourceedit.getCustomerVisitData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEEDITED)))){				
					SharedPreferences prefs = AppManager.getInstance().getPrefs(GPSTrackerService.this);
					String token = prefs.getString("token", null);
					String json="{" +"\"token\":\""+token+"\",";
					if(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))!=null)
					{
						json=json+"\"visit_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ID))+"\",";
					
					json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))+"\"," +
							"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_LGAREAID))+"\"," +
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_DEPOTID))+"\"," +
							"\"visiting_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_VISITING_DATE))+"\"," +
							"\"comment\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_COMMENT))+"\"";
					json=json+"}";
					}
					Hashtable<String,String> parameters=new Hashtable<String,String>();
					parameters.put("jsonString", json);				
				    String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_CUSTOMERVISITS, parameters, null);
				    System.out.println("This is for edit "+response);
				    
				    if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasourceedit.customerVisitupdateISEdit(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ID)));			
					}
				    }
					
				}
				cursor.moveToNext();	
				}
				
			datasourceedit.close();
			}
		
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private void incentivesQuery(){
		try{
			
			Y3QueryDataSource datasource1;
			
			
				datasource1 = new Y3QueryDataSource(GPSTrackerService.this);
			
			datasource1.open();
			Cursor cursor=datasource1.getIncentiveData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_ISOFFLINEADDED)))){				
					SharedPreferences prefs = AppManager.getInstance().getPrefs(GPSTrackerService.this);
					String token = prefs.getString("token", null);
					String json="{" +
							"\"token\":\""+token+"\","+
							"\"request_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REQUEST_ID))+"\","
							+"\"created\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CREATED_DATE))+"\"," ;
					
					if(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVECUSTOMER_ID))==null)
					{							
						json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVECUSTOMER_ID))+"\"," +
								"\"incentive_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_DATE))+"\"," +
								"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_BRAND_BRAND_ID))+"\"," +
								"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_DEPOTID))+"\"," +
								"\"incentive_type\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_TYPE))+"\"," +
								"\"unit\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_UNIT))+"\"," +
								"\"quantity\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_QUANTITY))+"\"";
						json=json+",";
						json=json+"\"newCustomer\":" ;
						json=json+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_CUSTOMER_JSON));		
						json=json+"}";
						
					}
					else{
						json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVECUSTOMER_ID))+"\"," +
								"\"incentive_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_DATE))+"\"," +
								"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_BRAND_BRAND_ID))+"\"," +
								"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_DEPOTID))+"\"," +
								"\"incentive_type\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_TYPE))+"\"," +
								"\"unit\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_UNIT))+"\"," +
								"\"quantity\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_QUANTITY))+"\"";
						json=json+"}";
					}
					Hashtable<String,String> params=new Hashtable<String,String>();
		    		params.put("jsonString",json);	
		    		//String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_INCENTIVE, params, null);
					String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_INCENTIVE, params, null);
					System.out.println("The Response is now find "+response);
					
					
				    if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasource1.incentiveupdateISAdded(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_ID)));
			
					}
				    }
					}
			cursor.moveToNext();
			}
			datasource1.close();
		}catch(Exception e){
			e.printStackTrace();
		}
//this is for delete from server................
		Y3QueryDataSource datasource;
		
		
		datasource = new Y3QueryDataSource(GPSTrackerService.this);
	
		datasource.open();
		List<Y3Query> result = datasource.getAllY3Queries();
		for (int i = 0; i < result.size(); i++) {
			Y3Query y3q = result.get(i);
			if (y3q.getAction().equals(
					Y3QueryDataSource.ACTION_INCENTIVE_DELETE)) {
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", y3q.getJson());
				Hashtable<String,File> fileParams=null;
				String imagePath=null;
	    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
	    		{
	    			fileParams=new Hashtable<String,File>();
		    		fileParams.put("image", new File(imagePath));
	    		}
			    String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_DELETE_INCENTIVE, parameters, fileParams);
			    System.out.println("Delete Response in INcentive"+response);

				try {
					if (response != null
							&& new JSONObject(response).getInt("error") == 0) {
						boolean isQueryDeleted = datasource
								.deleteY3Query(y3q.get_id());
						Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}
			}

		}
		datasource.close();
//this is for edit data from server.....
		
		try{
			Y3QueryDataSource datasource1;
			
			
				datasource1 = new Y3QueryDataSource(GPSTrackerService.this);
			
		datasource1.open();
		Cursor cursor=datasource1.getIncentiveData();
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {					
			if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_ISOFFLINEEDITED)))){				
				SharedPreferences prefs = AppManager.getInstance().getPrefs(GPSTrackerService.this);
				String token = prefs.getString("token", null);
				String json="{" +"\"token\":\""+token+"\",";
				
				if(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVECUSTOMER_ID))!=null)
				{							
					json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVECUSTOMER_ID))+"\"," +
							"\"incentive_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_DATE))+"\"," +
							"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_BRAND_BRAND_ID))+"\"," +
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_DEPOTID))+"\"," +
							"\"incentive_type\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_TYPE))+"\"," +
							"\"unit\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_UNIT))+"\"," +
							"\"quantity\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_QUANTITY))+"\"";
					json=json+"}";
					
				}
		
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", json);				
			    String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_INCENTIVE, parameters, null);
			    System.out.println("This is for edit "+response);
			    System.out.println("This is Addcustomer Server response"+response);
			    if(response!=null)
			    {
			    int error = new JSONObject(response).getInt("error");
			    if (error == 0) 
				{
				System.out.println("All is welll");
				Log.d("MTK", "ISUPDATE:" + response); 					
				datasource1.incentiveupdateISUpdated(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_ID)));
		
				}
			    }
			}
		cursor.moveToNext();
		}
		datasource1.close();
		}
	catch(Exception e){
		System.out.println("Exception in edit");
		e.printStackTrace();
	}
		
	}
	
	public void salesQuery(){
		try{
			Y3QueryDataSource datasource1 ;
			
				 datasource1 = new Y3QueryDataSource(GPSTrackerService.this);
			
		
			datasource1.open();
			Cursor cursor=datasource1.getSalesData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SALES_ISOFFLINEADDED)))){	
					SharedPreferences prefs = AppManager.getInstance().getPrefs(GPSTrackerService.this);
					String token = prefs.getString("token", null);
					String json="{" +
						"\"token\":\""+token+"\",";
					
					json=json+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SALES_OFFLINE_ADDEDJON));
					Hashtable<String,String> params1=new Hashtable<String,String>();
		    		params1.put("jsonString", json);
		    		String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_SALESORDER, params1, null);
		    		Log.d("MTK", "server response: "+response);
		    		 if(response!=null)
					    {
					    int error = new JSONObject(response).getInt("error");
					    if (error == 0) 
						{
						System.out.println("All is welll");
						Log.d("MTK", "ISUPDATE:" + response); 					
						datasource1.salesUpdateAdd(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ID)));
				
						}
					    }
		    		
					
				}
				cursor.moveToNext();
			}
			datasource1.close();
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("The Exception in add sales order");
		}
		
		//---------------------------------------------------------------
		// this is for add delete operation.........
		Y3QueryDataSource datasource ;//= new Y3QueryDataSource(getActivity());
		
			 datasource = new Y3QueryDataSource(GPSTrackerService.this);
		
		datasource.open();
		List<Y3Query> result = datasource.getAllY3Queries();
		for (int i = 0; i < result.size(); i++) {
			Y3Query y3q = result.get(i);
			if (y3q.getAction().equals(
					Y3QueryDataSource.ACTION_SALES_DELETE)) {
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", y3q.getJson());
				String imagePath=y3q.getImage();
				Hashtable<String,File> fileParams=null;
	    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
	    		{
	    			fileParams=new Hashtable<String,File>();
		    		fileParams.put("image", new File(imagePath));
	    		}
	    		
			    String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_DELETE_SALESORDER, parameters, fileParams);

				try {
					if (response != null
							&& new JSONObject(response).getInt("error") == 0) {
						boolean isQueryDeleted = datasource
								.deleteY3Query(y3q.get_id());
						Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
						
					}
				} catch (JSONException e) {
					e.printStackTrace();

				}}}
		datasource.close();
		
	}

private void distributorSalesQuery(){
	try{
		Y3QueryDataSource datasource1 ;//= new Y3QueryDataSource(getActivity());
		
	   datasource1 = new Y3QueryDataSource(GPSTrackerService.this);
	
		datasource1.open();
		Cursor cursor=datasource1.getRedistibutorSalesdata();
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {					
			if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REDISTRIBUTORJSON_ISOFFLINEADDED)))){	
				SharedPreferences prefs = AppManager.getInstance().getPrefs(GPSTrackerService.this);
				String token = prefs.getString("token", null);
				String json="{" +
					"\"token\":\""+token+"\",";
				
				json=json+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REDISTRIBUTORJSON_OFFLINE_ASSEDJSON));
				System.out.println("Add Distributor Json"+json);
				Hashtable<String,String> params1=new Hashtable<String,String>();
	    		params1.put("jsonString", json);
	    		String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_DISTRIBUTOR_SALESORDER, params1, null);
	    		Log.d("MTK", "server response: "+response);
	    		
	    		 if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasource1.distributorUpdateAdd(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ID)));
			
					}
				    }
	    		
				
			}
			cursor.moveToNext();
		}
		datasource1.close();
	}
	catch(Exception e){
		e.printStackTrace();
		System.out.println("The Exception in Distributor sales order");
	}
	

		 Y3QueryDataSource datasource ;//= new Y3QueryDataSource(getActivity());		
	
		 datasource = new Y3QueryDataSource(GPSTrackerService.this);
	
	datasource.open();
	List<Y3Query> result = datasource.getAllY3Queries();
	for (int i = 0; i < result.size(); i++) {
		Y3Query y3q = result.get(i);
		if (y3q.getAction().equals(
				Y3QueryDataSource.ACTION_DISTRIBUTOR_SALES_DELETE)) {
			Hashtable<String,String> parameters=new Hashtable<String,String>();
			parameters.put("jsonString", y3q.getJson());
			String imagePath=y3q.getImage();
			Hashtable<String,File> fileParams=null;
    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
    		{
    			fileParams=new Hashtable<String,File>();
	    		fileParams.put("image", new File(imagePath));
    		}
    		
		    String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_DELETE_DISTRIBUTOR_SALESORDER, parameters, fileParams);

			try {
				if (response != null
						&& new JSONObject(response).getInt("error") == 0) {
					boolean isQueryDeleted = datasource
							.deleteY3Query(y3q.get_id());
					Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
					
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		}

	}
	datasource.close();
}

//Send Lat long
	public void snedlatlong(){
		
		Y3QueryDataSource datasource1 ;//= new Y3QueryDataSource(getActivity());		
		datasource1 = new Y3QueryDataSource(GPSTrackerService.this);	
		datasource1.open();
		Cursor cursor=datasource1.getTrakingData();
		try{
			if(cursor.getCount() > 0){
				int itr = 1;
				cursor.moveToFirst();
				SharedPreferences prefs = AppManager.getInstance().getPrefs(GPSTrackerService.this);
				String token = prefs.getString("token", null);
				String user_id = prefs.getString("user_id", "");
				String jsonStr="{" +
						"\"token\":\""+token+"\",\"multiple\":1,\"user_id\":\""+user_id+"\",\"trackdata\":[";
				while (!cursor.isAfterLast()) {					
					jsonStr = jsonStr+"{";
					jsonStr = jsonStr+"\"lat\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LATITUDE))+"\"," +
							"\"long\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LONGITUDE))+"\"," +
							"\"dbid\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ID))+"\"," +
							"\"tracking_time\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.TRACKING_TIME))+"\"}" ;					
					if(itr < cursor.getCount()){
						jsonStr = jsonStr+",";
					}
					itr++;
					cursor.moveToNext();					
				}
				jsonStr = jsonStr+"]}";
				
				Hashtable<String,String> params1=new Hashtable<String,String>();
	    		params1.put("jsonString",jsonStr);	
	    		System.out.println("TjsonString "+jsonStr);
	    		//String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_INCENTIVE, params, null);
				String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().SEND_LAT_LAONG_API, params1, null);
				System.out.println("The Response is now find "+response);
				
				if(response!=null)
			    {
					JSONObject dataJSONObject = new JSONObject(response);
					String deleteIds = dataJSONObject.isNull("ids") ? "" : dataJSONObject.getString("ids");
					int error = dataJSONObject.isNull("error") ? 0 :dataJSONObject.getInt("error");
					
				    if (error == 0) 
					{
						//System.out.println("All is welll");
						//Log.d("MTK", "ISUPDATE:" + response); 
						//Remove send lat/long from database
					
						System.out.println("dfdf "+deleteIds);
						if( !deleteIds.equals("") ){
							datasource1.deleteTrakingData(deleteIds);
						}
						//datasourcedelete.customerVisitupdateISAdded(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ID)));			
					}
			    }
				
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		datasource1.close();

	}


}
