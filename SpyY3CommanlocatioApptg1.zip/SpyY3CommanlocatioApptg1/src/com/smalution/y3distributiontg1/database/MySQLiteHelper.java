package com.smalution.y3distributiontg1.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class MySQLiteHelper extends SQLiteOpenHelper {
	public static final String TABLE_QUERIES = "queries";
	public static final String COLUMN_ID = "_id";
	public static final String COLUMN_ACTION = "action";
	public static final String COLUMN_JSON = "json";
	public static final String COLUMN_IMAGE = "image";
	public static final String COLUMN_STATUS = "status";
	public static final String COLUMN_SERVERLOG = "serverlog";
	public static final String COLUMN_SERVERLOGDETAIL = "serverlogdetail";
	
	//SOME COMMON DATA FOR SLQITE 
	public static  String ID="id";
	
	// this is common Data.....
	
	public static String CREATED_DATE="created_date";
	
	// this is for requestId for offline user..
	public static String REQUEST_ID="request_id";
	
	// this is for synchronization date to show on screen.
	
	public static String SYNCHRONIZATION="synchronization";

	private static final String DATABASE_NAME = "y3distribution.db";
	private static final int DATABASE_VERSION = 3;

	// Database creation sql statement
	private static final String DATABASE_CREATE = "create table "
			+ TABLE_QUERIES + "(" + COLUMN_ID
			+ " integer primary key autoincrement, " + COLUMN_ACTION
			+ " text not null," + COLUMN_JSON + " text not null,"
			+ COLUMN_IMAGE + " text," + COLUMN_STATUS + " text,"
			+ COLUMN_SERVERLOG + " text," + COLUMN_SERVERLOGDETAIL + " text"
			+ ");";

//---------------------------------------------------------------------------------------------
	
	public static String CUSTOMERS_TABLE_NAME="customers";
	  public static String CUSTOMER_ID="customer_id";
	  public static String FIRST_NAME="first_name";
	  public static String LAST_NAME="last_name";	
	  public static String EMAIL_ID="email";
	  public static String ADDRESS="address";
	  public static String CITY="city";
	  public static String USER_ID="user_id";
	   
	  public static String LATITUDE="latitude";
	  public static  String LONGITUDE="longitude";
	  public static String ZIPCODE="zipcode";
	  public static String PHONE="phone";
	  public static String DESCRIPTION="description";
	  public static String AMOUNT="amount";
	  public static String VIEW_DETAILS="view_details";
	  public static String STATUS="status";
	  public static String IMAGE_PATH="image_path";
	  public static String SNO="sno";
	  public static String ASSIGNTO="assignTo";
	  
	  // this is for  ddepot..
	  public static String DEPOT_ID="depot_id";
	  public static String DEPOT="depottitle";
	  
	  // this is for state;
	  public static String STATE_ID="state_id";
	  public static String STATE="state";	  
	  //user LgArea
	  public static String LGAREA_ID="lgarea_id";
	  public static String LGAREA="LgArea";
	  //user Region
	  public static String REGION_ID="region_id";
	  public static String REGION="region";
	  
	  //For Route
	  public static String ROUTE_ID="route_id";
	  
	  // this is for offline addcustomer..
	  public static String ISOFFLINEADDED="isofflineadded";
	  
	  // this is for offline editcustomerData;
	  public static String ISOFFLINEEDITED="isofflineedited";
	  //27
	   
	   
	   private static final String DATABASE_CUSTOMER = "create table "
			      + CUSTOMERS_TABLE_NAME + "(" 
					  + ID + " integer primary key autoincrement," 
					  +CUSTOMER_ID+" text,"
					  +FIRST_NAME+" text,"
					  +LAST_NAME+" text,"
					  +EMAIL_ID+" text,"
					  +ROUTE_ID+" text,"
			          +ADDRESS + " text," +CREATED_DATE+" text," + REQUEST_ID+" text,"
					  +CITY+" text,"	+LATITUDE+" text,"	+LONGITUDE+" text,"
			          +ZIPCODE+" text,"	+PHONE+" text,"	+DESCRIPTION+" text,"
					  +AMOUNT+" text,"	+VIEW_DETAILS+" text," 	+ STATUS + " text,"+SYNCHRONIZATION +" text,"
			          + IMAGE_PATH + " text,"	+SNO+" text,"+ASSIGNTO+ " text,"+	ISOFFLINEADDED+" text,"+	ISOFFLINEEDITED+" text,"
					  +USER_ID+" text,"+	DEPOT_ID+" text,"+	DEPOT+" text,"+	STATE_ID+" text,"+	STATE+" text,"
			          +LGAREA_ID+" text,"+LGAREA+" text,"	+REGION_ID+" text,"	+REGION+" text" +");";	
	
	
	//-----------------------------------------------------------------------------
	
	
	public static String TABLE_NAME="customerDetails";
	
	public static String CUSTOMERJSON="customerJson";
	/*
	private static final String CUSTOMER_DATABASE_CREATE = "create table "
			+ TABLE_NAME + "(" + ID
			+ " integer primary key autoincrement, " +CUSTOMERJSON + " text"+ ");";
	
	
	*/
	// this is for sales table...
	
	
/*	{"error":0,"data":[{"Order":{"id":"158","customer_id":"217","user_id":"97","items":"1","total":"520.000",
 * "status":"1","order_date":"2014-03-02","created":"2014-03-02 17:31:30","modified":"2014-03-02 17:31:30"},
		"User":{"first_name":"Vijay","last_name":"Gurumukhi"},
		"Customer":{"id":"217","first_name":"fffff","last_name":"ffffff"},"sno":1}
	}*/
	
	
	
	
	public static String SALES_TABLE_NAME="salesDetails";	
	public static String SALESJSON="salesJson";
	public static String SALES_OFFLINE_ADDEDJON="json";
	public static String SALES_ISOFFLINEADDED="isofflineadded";
	private static final String SALES_DATABASE_CREATE = "create table "
			+ SALES_TABLE_NAME + "(" + ID
			+ " integer primary key autoincrement, " 
			+SALES_OFFLINE_ADDEDJON+" text,"
			+SALES_ISOFFLINEADDED+" text,"
			+SALESJSON + " text"+ ");";
	
	//--------------------------------------------------------------
	
	
	
	// this is for redistributor sales table....
	
	public static String REDISTRIBUTOR_SALES_TABLE_NAME="redistributorsalesDetails";
	
	public static String REDISTRIBUTORJSON="redistributorsalesJson";
	public static String REDISTRIBUTORJSON_OFFLINE_ASSEDJSON="json";
	public static String REDISTRIBUTORJSON_ISOFFLINEADDED="isofflineadded";
	
	
	private static final String REDISTRIBUTOR_DATABASE_CREATE = "create table "
			+ REDISTRIBUTOR_SALES_TABLE_NAME + "(" + ID+ " integer primary key autoincrement, " 
			+ REDISTRIBUTORJSON_OFFLINE_ASSEDJSON+" text,"
			+ REDISTRIBUTORJSON_ISOFFLINEADDED+ " text,"
			+REDISTRIBUTORJSON + " text"+ ");";
	
	
	///------------------------------------------------------------------------------------------

	public static String CUSTOMERSVISIT_TABLE_NAME="customersVisit";
	
	public static String CUSTOMER_VISIT_ID="custometvisit_id";
	public static String CUSTOMER_VISIT_USERID="userid";
	public static String CUSTOMER_VISIT_CUSTOMERID="customerid";
	public static String CUSTOMER_VISIT_VISITING_DATE="visiting_date";
	public static String CUSTOMER_VISIT_CREATED="created";
	public static String CUSTOMER_VISIT_MODIFIED="modified";
	public static String CUSTOMER_VISIT_COMMENT="comment";
	public static String CUSTOMER_VISIT_DEPOTID="depot_id";
	public static String CUSTOMER_VISIT_LGAREAIF="lgarea_id";
	public static String CUSTOMER_VISIT_CVLATITUDE="latitude";
	public static String CUSTOMER_VISIT_CVLONGITUDE="longitude";
	public static String CUSTOMER_VISIT_USERFIRSTNAME="userfirstname";
	public static String CUSTOMER_VISIT_USERLASTNAME="userlastname";
	public static String CUSTOMER_VISIT_CUSTOMERFIRSTNAME="customerfirstname";
	public static String CUSTOMER_VISIT_CUSTOMERLASTNAME="customerlastname";	
	public static String CUSTOMER_VISIT_DEPOTTITLE="title";
	public static String CUSTOMER_VISIT_CUSVISITING_REGION_ID="region_id";
	public static String CUSTOMER_VISIT_LGAREAID="lgareaid";
	public static String CUSTOMER_VISIT_LGAREANAME="lgarea_name";
	public static String CUSTOMER_VISIT_STATEID="state_id";
	public static String CUSTOMER_VISIT_SNO="sno";
	public static String CUSTOMER_VISIT_STATE_ID="state_id";
	public static String CUSTOMER_VISIT_STATE_STATE_ID="state_state_id";
	public static String CUSTOMER_VISIT_STATE_STATE_NAME="state_state_name";
	public static String CUSTOMER_VISIT_ISOFFLINEADDED="isofflineadded";
	public static String CUSTOMER_VISIT_ISOFFLINEEDITED="isofflinedited";	
	public static String CUSTOMER_VISIT_CUSTOMER_JSON="customer_json";
	
	
	private static final String DATABASE_CUSTOMER_VISITING = "create table "
		      + CUSTOMERSVISIT_TABLE_NAME + "(" 
				  + ID + " integer primary key autoincrement,"
		          +CUSTOMER_VISIT_ID+" text,"
				  +CUSTOMER_VISIT_USERID+" text,"
		          +CUSTOMER_VISIT_CUSTOMERID+" text,"
				  +CUSTOMER_VISIT_VISITING_DATE+" text,"
		          +CUSTOMER_VISIT_COMMENT+" text,"
		          +CUSTOMER_VISIT_DEPOTID + " text,"
		          +CUSTOMER_VISIT_LGAREAIF+" text,"
		          +CUSTOMER_VISIT_CVLATITUDE+" text,"
		          +CUSTOMER_VISIT_CVLONGITUDE+" text,"
		          +CUSTOMER_VISIT_USERFIRSTNAME+" text,"
		          +CUSTOMER_VISIT_USERLASTNAME+" text,"
		          +CUSTOMER_VISIT_CUSTOMERFIRSTNAME+" text,"
		          +CUSTOMER_VISIT_CUSTOMERLASTNAME+" text,"
		          +CUSTOMER_VISIT_CUSVISITING_REGION_ID+" text,"
		          +CUSTOMER_VISIT_DEPOTTITLE+" text," 
		          + CUSTOMER_VISIT_LGAREANAME + " text,"
		          +CUSTOMER_VISIT_CREATED+" text,"
		          +CUSTOMER_VISIT_MODIFIED+" text,"
		          +CUSTOMER_VISIT_SNO+" text,"
		          +CUSTOMER_VISIT_LGAREAID+" text,"
		          +CUSTOMER_VISIT_CUSTOMER_JSON+" text,"
		          +CUSTOMER_VISIT_ISOFFLINEADDED+" text,"
		          +CUSTOMER_VISIT_ISOFFLINEEDITED+" text,"
		          +CUSTOMER_VISIT_STATE_STATE_ID+" text,"
		          +CUSTOMER_VISIT_STATE_STATE_NAME+" text,"
		          +CREATED_DATE+" text,"
		          +REQUEST_ID+" text,"
		          +SYNCHRONIZATION+" text,"
		          +CUSTOMER_VISIT_STATEID + " text" +");";
	
	//22
	//------------------------------------------------------------------------------------------------------------

	
public static String INCENTIVE_TABLE_NAME="incentive";
	
public static String INCENTIVE_ID="incentive_id";
public static String INCENTIVE_BRAND_ID="brand_id";
public static String INCENTIVE_USER_ID="user_id";
public static String INCENTIVE_CUSTOMER_ID="customer_id";
public static String INCENTIVE_DEPOT_ID="depot_id";
public static String INCENTIVE_INCENTIVE_DATE="incentive_data";
public static String INCENTIVE_INCENTIVE_TYPE="incentive_type";
public static String INCENTIVE_UNIT="unit";
public static String INCENTIVE_CAL_QNT="cal_qnt";
public static String INCENTIVE_QUANTITY="quantity";
public static String INCENTIVE_CREATED="created";
public static String INCENTIVE_MODIFIED="modified";
public static String INCENTIVE_FIRST_NAME="first_name";
public static String INCENTIVE_LAST_NAME="last_name";
public static String INCENTIVE_BRAND_BRAND_ID="brand_brand_id";
public static String INCENTIVE_BRAND_NAME="brand_name";
public static String INCENTIVE_BRAND_DESCRIPTION="description";
public static String INCENTIVE_BRAND_USER_ID="brand_user_id";
public static String INCENTIVE_CASE_PRICE="case_price";

public static String INCENTIVE_ROLL_PRICE="roll_price";
public static String INCENTIVE_PACK_PRICE="pack_price";
public static String INCENTIVE_2PACK_PRICE="secondpack_price";
public static String INCENTIVE_CASE_ROLL="case_roll";
public static String INCENTIVE_ROLL_PACK="roll_pack";
public static String INCENTIVE_PACK_STICKS="pack_sticks";
public static String INCENTIVE_2ND_PACK_PACK="secondnd_pack_pack";
public static String INCENTIVE_STATUS="status";
public static String INCENTIVE_RD_CASE_PRICE="rd_case_price";
public static String INCENTIVE_RD_ROLL_PRICE="rd_roll_price";
public static String INCENTIVE_RD_PACK_PRICE="rd_pack_price";
public static String INCENTIVE_RD_2ND_PACK_PRICE="rd_2nd_pack_price";
public static String INCENTIVE_BRAND_CREATED="brand_created";
public static String INCENTIVE_BRAND_MODIFIED="brand_modified";
public static String INCENTIVE_DEPOTID="depotid";
public static String INCENTIVE_DEPOT_NAME="depot_name";
public static String INCENTIVE_DEPOT_REGION_ID="depot_region_id";
public static String INCENTIVECUSTOMER_ID="incentive_customer_id";
public static String INCENTIVE_CUSTOMER_FIRST_NAME="customer_firstname";
public static String INCENTIVE_CUSTOMER_LAST_NAME="customer_lastname";
public static String INCENTIVE_SNO="sno";
public static String INCENTIVE_CUSTOMER_JSON="customer_json";
public static String INCENTIVE_ISOFFLINEADDED="isofflineadded";
public static String INCENTIVE_ISOFFLINEEDITED="isofflineedited";

	
	
	
private static final String DATABASE_INCENTIVE = "create table "
	      + INCENTIVE_TABLE_NAME + "(" 
			  + ID + " integer primary key autoincrement,"
	          +INCENTIVE_ID+" text,"
			  +INCENTIVE_BRAND_ID+" text,"
	          +INCENTIVE_USER_ID+" text,"
			  +INCENTIVE_CUSTOMER_ID+" text,"
	          +INCENTIVE_DEPOT_ID+" text,"
	          +INCENTIVE_INCENTIVE_DATE + " text,"
	          +INCENTIVE_INCENTIVE_TYPE+" text,"
	          +INCENTIVE_UNIT+" text,"
	          +INCENTIVE_CAL_QNT+" text,"
	          +INCENTIVE_QUANTITY+" text,"
	          +INCENTIVE_CREATED+" text,"
	          +INCENTIVE_MODIFIED+" text,"
	          +INCENTIVE_FIRST_NAME+" text,"
	          +INCENTIVE_LAST_NAME+" text,"
	          +INCENTIVE_BRAND_BRAND_ID+" text," 
	          +INCENTIVE_BRAND_NAME + " text,"
	          +INCENTIVE_BRAND_DESCRIPTION+" text,"	          
	          +INCENTIVE_BRAND_USER_ID+" text,"
	          +INCENTIVE_CASE_PRICE+" text,"	          
	          +INCENTIVE_ROLL_PRICE+" text,"
	          +INCENTIVE_PACK_PRICE+" text,"
	          +INCENTIVE_2PACK_PRICE+" text,"
	          +INCENTIVE_CASE_ROLL+" text,"
	          +INCENTIVE_ROLL_PACK+" text,"
	          +INCENTIVE_PACK_STICKS+" text,"
	          +INCENTIVE_2ND_PACK_PACK+" text,"
	          +INCENTIVE_RD_CASE_PRICE+" text,"
	          +INCENTIVE_RD_ROLL_PRICE+" text,"
	          +INCENTIVE_RD_PACK_PRICE+" text,"
	          +INCENTIVE_RD_2ND_PACK_PRICE+" text,"
	          +INCENTIVE_BRAND_CREATED+" text,"
	          +INCENTIVE_BRAND_MODIFIED+" text,"
	          +INCENTIVE_DEPOTID+" text,"
	          +INCENTIVE_STATUS+" text,"
	          +INCENTIVE_DEPOT_NAME+" text,"
	          +INCENTIVE_DEPOT_REGION_ID+" text,"
	          +INCENTIVECUSTOMER_ID+" text,"
	          +INCENTIVE_CUSTOMER_FIRST_NAME+" text,"
	          +INCENTIVE_CUSTOMER_LAST_NAME+" text,"
	          +INCENTIVE_SNO+" text,"
	          +INCENTIVE_CUSTOMER_JSON+" text,"
	          +INCENTIVE_ISOFFLINEADDED+" text,"
	          +CREATED_DATE+" text," 
	          +REQUEST_ID+" text,"
	          +INCENTIVE_ISOFFLINEEDITED + " text" +");";
	
	
//------------------------------------------------------------------------------------------------------------------------------------------

	
public static String PAYMENT_TABLE_NAME="payment";

public static String PAYMENT_ID="payment_id";
public static String PAYMENT_TITLE="payment_title";
public static String PAYMENT_USER_ID="payment_user_id";
public static String PAYMENT_PAYMENT_MODE="payment_mode";
public static String PAYMENT_BANK_ID="payment_bank_id";
public static String PAYMENT_DEPOT_ID="payment_depot_id";
public static String PAYMENT_REGION_ID="payment_region_id";
public static String PAYMENT_BRAND_ID="payment_brand_id";
public static String PAYMENT_DISTRIBUTOR_ID="payment_distributor_id";
public static String PAYMENT_AMOUNT="payment_amount";
public static String PAYMENT_PAYMENT_REF="payment_ref";
public static String PAYMENT_TRANSACTION_ID="tans_id";
public static String PAYMENT_PAYMENT_DATE="payement_date";
public static String PAYMENT_NOTES="payment_notes";
public static String PAYMENT_CREATED="payemnt_created";
public static String PAYMENT_MODIFIED="payment_modified";
public static String PAYMENT_USER_FIRST_NAME="payment_firstname";
public static String PAYMENT_USER_LAST_NAME="payment_lastname";
public static String PAYMENT_BANK_BANK_ID="bank_id";
public static String PAYMENT_BANK_NAME="bank_name";
public static String PAYMENT_SNO="sno";
public static String PAYMENT_ISOFFLINEADDED="payment_isoffline_added";
public static String PAYMENT_ISOFFLINEEDITED="payment_isoffline_edited";

private static final String DATABASE_PAYMENT = "create table "
	      +PAYMENT_TABLE_NAME + "(" 
			  + ID + " integer primary key autoincrement,"
	          +PAYMENT_ID+" text,"
			  +PAYMENT_TITLE+" text,"
	          +PAYMENT_USER_ID+" text,"
			  +PAYMENT_PAYMENT_MODE+" text,"
	          +PAYMENT_BANK_ID+" text,"
	          +PAYMENT_DEPOT_ID + " text,"
	          +PAYMENT_REGION_ID + " text,"
	          +PAYMENT_BRAND_ID+" text,"
	          +PAYMENT_DISTRIBUTOR_ID+" text,"
	          +PAYMENT_AMOUNT+" text,"
	          +PAYMENT_PAYMENT_REF+" text,"
	          +PAYMENT_TRANSACTION_ID+" text,"
	          +PAYMENT_PAYMENT_DATE+" text,"
	          +PAYMENT_NOTES+" text,"
	          +PAYMENT_CREATED+" text,"
	          +PAYMENT_MODIFIED+" text," 
	          +PAYMENT_USER_FIRST_NAME + " text,"
	          +PAYMENT_USER_LAST_NAME+" text,"
	          +PAYMENT_BANK_BANK_ID+" text,"
	          +PAYMENT_BANK_NAME+" text,"
	          +PAYMENT_SNO+" text,"	
	          +CREATED_DATE+" text," 
	          +REQUEST_ID+" text,"
	          +PAYMENT_ISOFFLINEADDED+" text,"
	          +PAYMENT_ISOFFLINEEDITED + " text" +");";
	
//----------------------------------------------------------------------------------------------------
//[{"Expense":{"id":"57","title":"","depot_id":"3","brand_id":"1","user_id":"1",
//"exp_amount":"36.00","exp_date":"2014-02-23","payment_mode":"","expense_ref":"Aggdafga ",
//"description":"fgsdgdf ","exp_type_id":"1","created":"2014-02-22 22:00:00",
//"modified":"2014-02-22 22:00:00"},"User":{"first_name":"System","last_name":"Admin"},/
//"ExpType":{"id":"1","name":"Office Furniture","category_id":"1"},"sno":1},
	
public static String EXPENSE_TABLE_NAME="expense";

public static String EXPENSE_ID="expense_ID";
public static String EXPENSE_TITLE="expence_title";
public static String EXPENSE_DEPOT_ID="expence_depot_id";
public static String EXPENSE_REGION_ID="expence_region_id";
public static String EXPENSE_BRAND_ID="expence_brand_id";
public static String EXPENSE_USER_ID="expence_user_id";
public static String EXPENSE_EXP_AMOUNT="exp_amount";
public static String EXPENSE_EXP_DATA="exp_date";
public static String EXPENSE_PAYMENT_MODE="exp_payment_mode";
public static String EXPENSE_REF="exp_ref";
public static String EXPENSE_DESCRIPTION="exp_description";
public static String EXPENSE_TYPE_ID="exp_type_id";
public static String EXPENSE_CREATE="created";
public static String EXPENSE_MODIFIED="modified";
public static String EXPENSE_USER_FIRST_NAME="first_name";
public static String EXPENSE_USER_LAST_NAME="last_name";
public static String EXPENSE_EXPTYPE_ID="exptypeid";
public static String EXPENSE_NAME="exp_name";
public static String EXPENSE_CATEGORY_ID="category_id";
public static String EXPENSE_SNO="sno";
public static String EXPENCE_OFFLINE_ADD="offlineadd";
public static String EXPENCE_OFFLINE_EDIT="offlineedit";


private static final String DATABASE_EXPENSE = "create table "
	      +EXPENSE_TABLE_NAME + "(" 
			  + ID + " integer primary key autoincrement,"
	          +EXPENSE_ID+" text,"
			  +EXPENSE_TITLE+" text,"
			  +EXPENSE_DEPOT_ID+" text,"
			  +EXPENSE_REGION_ID+" text,"
	          +EXPENSE_USER_ID+" text,"
	          +EXPENSE_BRAND_ID+" text,"
			  +EXPENSE_EXP_AMOUNT+" text,"
	          +EXPENSE_EXP_DATA+" text,"
	          +EXPENSE_PAYMENT_MODE + " text,"
	          +EXPENSE_REF+" text,"
	          +EXPENSE_DESCRIPTION+" text,"
	          +EXPENSE_TYPE_ID+" text,"
	          +EXPENSE_CREATE+" text,"
	          +EXPENSE_MODIFIED+" text,"
	          +EXPENSE_USER_FIRST_NAME+" text,"
	          +EXPENSE_USER_LAST_NAME+" text,"
	          +EXPENSE_EXPTYPE_ID+" text,"
	          +EXPENSE_NAME+" text," 
	          +EXPENSE_CATEGORY_ID + " text,"
	          +EXPENCE_OFFLINE_ADD+" text,"
	          +CREATED_DATE+" text," 
	          +REQUEST_ID+" text,"
	          +EXPENCE_OFFLINE_EDIT+" text,"
	          +EXPENSE_SNO + " text" +");";


	
	//Device Log table

		public static String DEVICELOGS_TABLE_NAME="deviceLogs";	
		public static String USERID = "user_id";
		public static String START_TIME = "start_time";
		public static String END_TIME = "end_time";
		public static String CURR_DATE = "curr_date";
		public static String DURATION = "duration";
		public static String ACTIVITY = "activity";
		public static String MESSAGE = "message";
		public static String LOG_STATUS = "status";
		public static String CREATED = "created";
		
		private static final String DEVICELOGS_DATABASE_CREATE = "create table "
				+ DEVICELOGS_TABLE_NAME + "(" + ID
				+ " integer primary key autoincrement, " 
				+ USERID + " integer,"
				+ START_TIME + " text,"
				+ END_TIME + " text,"
				+ CURR_DATE + " text,"
				+ DURATION + " text,"		
				+ ACTIVITY + " text,"
				+ MESSAGE + " text,"
				+ LOG_STATUS + " text,"
				+ LATITUDE + " text,"
				+ LONGITUDE + " text,"
				+ CREATED + " text"+ ");";
	

	
	//Customer list table
	public static String CUSTOMER_LIST_TABLE_NAME = "customersList";
	public static String CUSTOMER_NAME = "customer_name";
	
	public static String CUSTOMER_LIST_DATABASE_CREATE = "create table if not exists "
			+ CUSTOMER_LIST_TABLE_NAME + "(" + ID + " integer, "
			+ CUSTOMER_NAME + " text"+ ");";
	
	//Notifications	
	public static String NOTIFICATION_TABLE_NAME = "notifications";
	public static String NOTIFY_MESSAGE = "message";
	public static String NOTIFY_TIME = "notify_time";
	
	public static String NOTIFICATION_TABLE_CREATE = "create table if not exists "
				+ NOTIFICATION_TABLE_NAME + "(" + ID + " integer, "
				+ NOTIFY_MESSAGE + " text, "+  NOTIFY_TIME + " text );";
	
	//Tracking table
	public static String USER_TRACKING_TABLE = "user_tracking";
	public static String TRACKING_TIME = "tracking_time";
	private static final String TRACKING_TABLE_CREATE = "create table " + USER_TRACKING_TABLE + "(" + ID + " integer primary key autoincrement, " + LATITUDE+" text, "+LONGITUDE+" text,"+TRACKING_TIME+" text)";
		
		
	public MySQLiteHelper(Context context) {		
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		//sqLiteHelper = new MySQLiteHelper(context, DATABASE_NAME, null, DATABASE_VERSION)
	}
	
	

	@Override
	public void onCreate(SQLiteDatabase database) {
		database.execSQL(DATABASE_CREATE);
		//database.execSQL(CUSTOMER_DATABASE_CREATE);
		database.execSQL(DATABASE_CUSTOMER);
		database.execSQL(SALES_DATABASE_CREATE);
		database.execSQL(REDISTRIBUTOR_DATABASE_CREATE);
		database.execSQL(DATABASE_CUSTOMER_VISITING);
		database.execSQL(DATABASE_INCENTIVE);
		database.execSQL(DATABASE_PAYMENT);
		database.execSQL(DATABASE_EXPENSE);
		database.execSQL(DEVICELOGS_DATABASE_CREATE);
		database.execSQL(CUSTOMER_LIST_DATABASE_CREATE);
		database.execSQL(NOTIFICATION_TABLE_CREATE);
		database.execSQL(TRACKING_TABLE_CREATE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		Log.w(MySQLiteHelper.class.getName(),
				"Upgrading database from version " + oldVersion + " to "
						+ newVersion + ", which will destroy all old data");
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUERIES);
		db.execSQL("DROP TABLE IF EXISTS " + CUSTOMERS_TABLE_NAME);
		db.execSQL("DROP TABLE IF EXISTS " + SALES_TABLE_NAME);
		db.execSQL("DROP TABLE IF EXISTS " + REDISTRIBUTOR_SALES_TABLE_NAME);
		db.execSQL("DROP TABLE IF EXISTS " + CUSTOMERSVISIT_TABLE_NAME );
		db.execSQL("DROP TABLE IF EXISTS " + INCENTIVE_TABLE_NAME);
		db.execSQL("DROP TABLE IF EXISTS " + PAYMENT_TABLE_NAME);		
		db.execSQL("DROP TABLE IF EXISTS " + EXPENSE_TABLE_NAME);
		db.execSQL("DROP TABLE IF EXISTS " + DEVICELOGS_TABLE_NAME);
		db.execSQL("DROP TABLE IF EXISTS " + CUSTOMER_LIST_TABLE_NAME);
		db.execSQL("DROP TABLE IF EXISTS " + NOTIFICATION_TABLE_NAME);
		db.execSQL("DROP TABLE IF EXISTS " + USER_TRACKING_TABLE);
		onCreate(db);
	}
}
