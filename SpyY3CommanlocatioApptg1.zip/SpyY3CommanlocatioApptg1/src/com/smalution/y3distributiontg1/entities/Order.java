package com.smalution.y3distributiontg1.entities;

import android.os.Parcel;
import android.os.Parcelable;

public class Order implements Parcelable
{
	private String customer;
	private String orderDate;
	private String brand;
	private String unit;
	private String unitPrice;
	private String quantity;
	private String total;
	private String grandTotal;
	
	
	public Order(){}
	
	public Order(Parcel in)
 	{
		customer = in.readString();
		orderDate = in.readString();
		brand = in.readString();
		unit = in.readString();
		unitPrice = in.readString();
		quantity = in.readString();
		total = in.readString();
		grandTotal = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(customer);
 		dest.writeString(orderDate);
 		dest.writeString(brand);
 		dest.writeString(unit);
 		dest.writeString(unitPrice);
 		dest.writeString(quantity);
 		dest.writeString(total);
 		dest.writeString(grandTotal);
	}
 	public static final Parcelable.Creator<Order> CREATOR = new Parcelable.Creator<Order>() 
 	{
 		public Order createFromParcel(Parcel in) 
 		{
 			return new Order(in);
 		}
 	
 		public Order[] newArray (int size) 
 		{
 			return new Order[size];
 		}
 	};
}
