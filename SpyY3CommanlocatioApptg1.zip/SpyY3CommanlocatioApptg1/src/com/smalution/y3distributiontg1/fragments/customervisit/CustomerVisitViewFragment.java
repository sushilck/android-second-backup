package com.smalution.y3distributiontg1.fragments.customervisit;
import com.smalution.y3distributiontg1.R;
import com.smalution.y3distributiontg1.entities.customervisits.CustomerVisit;
import com.smalution.y3distributiontg1.fragments.SuperFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.androidquery.AQuery;

public class CustomerVisitViewFragment extends SuperFragment 
{
	CustomerVisit customerVisit;
	View rootView;
	AQuery aq; 
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	customerVisit = args.getParcelable("CUSTOMERVISIT");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		customerVisit = getArguments().getParcelable("CUSTOMERVISIT");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.customer_visit_view_fragment, container, false);
        aq=new AQuery(rootView);
        initUI();
        return rootView;
    }
	private void initUI() 
	{
		aq.id(R.id.textViewName).text(customerVisit.getCustomer().getFirst_name()+" "+customerVisit.getCustomer().getLast_name());
		aq.id(R.id.textViewDepot).text(customerVisit.getDepot().getTitle());
		//aq.id(R.id.textViewLGA).text(customerVisit.getLgArea().getName());
		aq.id(R.id.textViewVisitingDate).text(customerVisit.getCustomerVisit().getVisiting_date());
		aq.id(R.id.textViewCreatedDate).text(customerVisit.getCustomerVisit().getCreated());
		aq.id(R.id.textViewSynchronizationData).text(customerVisit.getCustomerVisit().getModified());
		aq.id(R.id.textViewComment).text(customerVisit.getCustomerVisit().getComment());
	}
}
