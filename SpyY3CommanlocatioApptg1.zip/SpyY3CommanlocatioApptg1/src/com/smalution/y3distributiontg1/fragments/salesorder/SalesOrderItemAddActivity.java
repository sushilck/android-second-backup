package com.smalution.y3distributiontg1.fragments.salesorder;

import com.smalution.y3distributiontg1.AppManager;
import com.smalution.y3distributiontg1.R;
import com.smalution.y3distributiontg1.entities.salesorder.Sales;
import com.smalution.y3distributiontg1.entities.settings.Brand;
import com.smalution.y3distributiontg1.entities.settings.Brands;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import com.androidquery.AQuery;

public class SalesOrderItemAddActivity extends Activity 
{
	Sales salesItem;
	AQuery aq; 
	UIHandler uiHandler;
	private final int SALEITEM_UPDATE_BRAND=100;
	private final int SALEITEM_UPDATE_UNIT=101;
	private final int SALEITEM_UPDATE_UNITPRICE=102;
	private final int SALEITEM_UPDATE_QUANTITY=103;
	private final int SALEITEM_UPDATE_AMOUNT=104;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		case SALEITEM_UPDATE_BRAND:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonBrand).getButton().setText(selectedValue);
        			String quantity = aq.id(R.id.editTextQuantity).getTextView().getText().toString();
        			String unit = aq.id(R.id.buttonUnit).getButton().getText().toString();
        			updateSalesItem(salesItem, selectedValue, unit, quantity);
        			break;
        		}
        		case SALEITEM_UPDATE_UNIT:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonUnit).getButton().setText(selectedValue);
        			String quantity = aq.id(R.id.editTextQuantity).getTextView().getText().toString();
        			String brand = aq.id(R.id.buttonBrand).getButton().getText().toString();
        			updateSalesItem(salesItem, brand, selectedValue, quantity);
        			break;
        		}
        		case SALEITEM_UPDATE_UNITPRICE:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.textViewUnitPrice).getTextView().setText(selectedValue);
        			break;
        		}
        		case SALEITEM_UPDATE_QUANTITY:
        		{
        			String selectedValue=(String)msg.obj;
        			String brand = aq.id(R.id.buttonBrand).getButton().getText().toString();
        			String unit = aq.id(R.id.buttonUnit).getButton().getText().toString();
        			updateSalesItem(salesItem, brand, unit, selectedValue);
        			break;
        		}
        		case SALEITEM_UPDATE_AMOUNT:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.textViewTotal).getTextView().setText(selectedValue);
        			break;
        		}
        	}
        }
    };
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sales_order_item_add_fragment);
		uiHandler=new UIHandler();
		aq=new AQuery(this);
        salesItem=new Sales();
        initUI();
	}
	private void initUI() 
	{
		aq.id(R.id.buttonBrand).clicked(new OnClickListener() 
        {
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Brands brands = AppManager.getInstance().getBrands(aq);
				
				if(brands!=null)
				{
					String[] arr=brands.getBrandsNames();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(SalesOrderItemAddActivity.this, uiHandler, SALEITEM_UPDATE_BRAND, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(SalesOrderItemAddActivity.this, getString(R.string.brand_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
        aq.id(R.id.buttonUnit).clicked(new OnClickListener() 
        {
			@Override
			public void onClick(View v) 
			{
				AppManager.getInstance().showSelectionAlertDialog(SalesOrderItemAddActivity.this, uiHandler, SALEITEM_UPDATE_UNIT, AppManager.units);
			}
		});
        aq.id(R.id.editTextQuantity).getEditText().setOnFocusChangeListener(new OnFocusChangeListener() 
        {
			@Override
			public void onFocusChange(View v, boolean hasFocus) 
			{
				if(!hasFocus)
				{
					Message msg=new Message();
					msg.obj=aq.id(R.id.editTextQuantity).getEditText().getText().toString();
					msg.arg1=SALEITEM_UPDATE_QUANTITY;
					uiHandler.sendMessage(msg);
				}
			}
		});
        aq.id(R.id.editTextQuantity).getEditText().setOnEditorActionListener(new OnEditorActionListener() {        
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) 
            {
                if(actionId==EditorInfo.IME_ACTION_DONE)
                {
                	Message msg=new Message();
                	msg.obj=aq.id(R.id.editTextQuantity).getEditText().getText().toString();
					msg.arg1=SALEITEM_UPDATE_QUANTITY;
					uiHandler.sendMessage(msg);
                }
                return false;
            }
        });
        aq.id(R.id.buttonSave).clicked(new OnClickListener() 
        {
			@Override
			public void onClick(View v) 
			{
				if(validateInput())
				{
					updateSalesItem(salesItem, aq.id(R.id.buttonBrand).getText().toString(), aq.id(R.id.buttonUnit).getText().toString(), aq.id(R.id.editTextQuantity).getText().toString());
					Intent intent =new Intent();
					intent.putExtra("ADDED_SALES_ITEM", salesItem);
					setResult(RESULT_OK, intent);
					finish();
				}
			}
		});
	}
	private boolean validateInput()
	{
		if(salesItem.getSale().getBrand_id()!=null && salesItem.getSale().getBrand_id().length()>0 && salesItem.getBrand().getName()!=null && salesItem.getBrand().getName().length()>0)
		{
			if(salesItem.getSale().getUnit()!=null && salesItem.getSale().getUnit().length()>0)
			{
				if(salesItem.getSale().getQuantity()!=null 
						&& salesItem.getSale().getQuantity().length()>0
						&& aq.id(R.id.editTextQuantity).getText().toString().length()>0)
				{
					try
					{
						Integer.parseInt(salesItem.getSale().getQuantity());
					}
					catch(NumberFormatException nfe)
					{
						Toast.makeText(aq.getContext(), getString(R.string.valid_qty_mess), Toast.LENGTH_SHORT).show();
						return false;
					}
					
					Message msg=new Message();
			    	msg.obj=aq.id(R.id.editTextQuantity).getEditText().getText().toString();
					msg.arg1=SALEITEM_UPDATE_QUANTITY;
					uiHandler.sendMessage(msg);
					return true;
				}
				else
				{
					Toast.makeText(aq.getContext(), getString(R.string.enter_quantity), Toast.LENGTH_SHORT).show();
				}
			}
			else
			{
				Toast.makeText(aq.getContext(), getString(R.string.select_unit), Toast.LENGTH_SHORT).show();
			}
		}
		else
		{
			Toast.makeText(aq.getContext(), getString(R.string.select_brand), Toast.LENGTH_SHORT).show();
		}
		return false;
	}

	private void updateSalesItem(Sales sales, String brandName, String unit, String quantity)
	{
		if(quantity!=null && quantity.length()>0)
		{
			try
			{
				Integer.parseInt(quantity);
			}
			catch(NumberFormatException nfe)
			{
				Toast.makeText(aq.getContext(), getString(R.string.valid_qty_mess), Toast.LENGTH_SHORT).show();
				return;
			}
		}
		
		boolean goFlagBrand=true;
		boolean goFlagUnit=true;
		Brand brand=null;
		if(brandName!=null && brandName.length()>0 && !brandName.equals("Brand"))
		{
			Brands brands = AppManager.getInstance().getBrands(aq);
			if(brands!=null)
			{
				brand = brands.getBrandByName(brandName);
				if(brand!=null)
				{
					sales.getSale().setBrand_id(brand.getId());
			        sales.getBrand().setName(brand.getName());
				}
			}
		}
		else
		{
			goFlagBrand=false;
		}
		if(unit!=null && unit.length()>0 && !unit.equals("Unit"))
		{
			sales.getSale().setUnit(unit);
		}
		else
		{
			goFlagUnit=false;
		}
		if(!(goFlagBrand && goFlagUnit))
		{
			return; 
		}
        float brandPrice = AppManager.getInstance().getSalesItemBrandPrice(brand, unit);
        
        Message msg=new Message();
		msg.arg1=SALEITEM_UPDATE_UNITPRICE;
		msg.obj=String.valueOf(brandPrice);
		uiHandler.sendMessage(msg);
		sales.getSale().setUnit_price(""+brandPrice);
		
		int qty=1;
		if(quantity!=null && quantity.length()>0)
			qty=Integer.parseInt(quantity);
		
		sales.getSale().setQuantity(""+qty);
		
		Message msg1=new Message();
		msg1.arg1=SALEITEM_UPDATE_AMOUNT;
		msg1.obj=String.valueOf(brandPrice*qty);
		uiHandler.sendMessage(msg1);
		
		sales.getSale().setAmount(""+(brandPrice*qty));
	}
}
