package com.smalution.y3distributiontg1.fragments.distributorsalesorder;

import com.smalution.y3distributiontg1.AppManager;
import com.smalution.y3distributiontg1.R;
import com.smalution.y3distributiontg1.Utils;
import com.smalution.y3distributiontg1.database.Y3QueryDataSource;
import com.smalution.y3distributiontg1.entities.User;
import com.smalution.y3distributiontg1.entities.customer.CustDepot;
import com.smalution.y3distributiontg1.entities.customer.CustRegion;
import com.smalution.y3distributiontg1.entities.customer.Customer;
import com.smalution.y3distributiontg1.entities.customer.SearchCutomer;
import com.smalution.y3distributiontg1.entities.distributor.DistributorDetail;
import com.smalution.y3distributiontg1.entities.distributor.DistributorFreeItem;
import com.smalution.y3distributiontg1.entities.distributor.DistributorSale;
import com.smalution.y3distributiontg1.entities.settings.ActiveCompaignManager;
import com.smalution.y3distributiontg1.entities.settings.ActiveCompaigns;
import com.smalution.y3distributiontg1.entities.settings.Redistributors;
import com.smalution.y3distributiontg1.entities.settings.SelectionButtonItem;
import com.smalution.y3distributiontg1.fragments.SuperFragment;
import com.smalution.y3distributiontg1.utils.AppConstant;
import com.smalution.y3distributiontg1.utils.DatePickerFragment;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.Toast;

import com.androidquery.AQuery;



public class DistributorSalesOrderAddFragment extends SuperFragment 
{
	boolean isOnlineCustomerSelectionModeOn=true;
	DistributorDetail distributorDetail;
	View rootView;
	AQuery aq; 
	AQuery aqFooter;
	ArrayAdapter<DistributorSale> salesAdapter;
	ArrayList<DistributorSale> salesArrayList;
	ArrayAdapter<DistributorFreeItem> freeItemsAdapter;
	ArrayList<DistributorFreeItem> freeItemsArrayList;
	ArrayList<ActiveCompaigns> qualifyingCompaignList;
	Hashtable<String, String> offlineCustomers;
	public static final int FLAG_SELECT_CUSTOMER=101;
	public static final int FLAG_SELECT_DISTRIBUTOR=102;
	UIHandler uiHandler;
	private String distributor_salesOrder_json;
	private String redistributor_id;
	private String customer_id;
	public boolean isDraft = false;
	private final int SALES_ITEM_ACTIVITY_CODE=100;
	
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		case FLAG_SELECT_CUSTOMER:
        		{
        			
        			if(isOnlineCustomerSelectionModeOn)
        			{
        				/*Customers customers = AppManager.getInstance().getCustomers(aq);
            			if(customers!=null)
            			{
            				SelectionButtonItem itm = customers.getItem(msg.arg2);
            				if(itm!=null)
            				{
            					distributorDetail.getRdsale().getRedistributorSale().setCustomer_id(itm.getId());
            					distributorDetail.getRdsale().getCustomer().setFirst_name(itm.getTitle());
            					distributorDetail.getRdsale().getCustomer().setLast_name("");
            					aq.id(R.id.buttonCustomer).text(itm.getTitle());
                    			//new GetCompaignAsyncTask(aq, itm.getId()).execute();
            				}
                		}*/
        				SelectionButtonItem itm = (SelectionButtonItem) msg.obj;
        				if(itm != null)
        				{
        					
        					customer_id= Integer.toString(msg.arg2);	
                			distributorDetail.getRdsale().getRedistributorSale().setCustomer_id(itm.getId());
        					distributorDetail.getRdsale().getCustomer().setFirst_name(itm.getTitle());
        					distributorDetail.getRdsale().getCustomer().setLast_name("");
        					aq.id(R.id.buttonCustomer).text(itm.getTitle());
        					//new GetCompaignAsyncTask(aq, itm.getId()).execute();
        					aq.id(R.id.salesItemsParent).visible();
        				}
        			}
        			else
        			{
        				String selectedValue=(String)msg.obj;
        				aq.id(R.id.buttonOfflineCustomer).text(selectedValue);
        			    String jsonString = offlineCustomers.get(selectedValue);
        			    customer_id= Integer.toString(msg.arg2);
        			    distributorDetail.getRdsale().getCustomer().setFirst_name(selectedValue);
        			    distributorDetail.getRdsale().getCustomer().setLast_name("");
        			    distributorDetail.setOfflineCustomerJSON(jsonString);
        			    if(jsonString!=null && jsonString.length()>0)
        			    {
        			    	//new GetCompaignAsyncTask(aq, "").execute();
        			    	aq.id(R.id.salesItemsParent).visible();
        			    }
        			}
        			break;
        		}
        		case FLAG_SELECT_DISTRIBUTOR:
        		{
        			String selectedValue=(String)msg.obj;
        			
        			aq.id(R.id.buttonRedistributor).text(selectedValue);
        			Redistributors redistributor= AppManager.getInstance().getRedistributors(aq);
    				if(redistributor!=null)
        			{
    					
    					redistributor_id=redistributor.getItem(msg.arg2).getId();
    					distributorDetail.getRdsale().getRedistributorSale().setRedistributor_id(redistributor.getItem(msg.arg2).getId());		
    					distributorDetail.getRdsale().getRedistributor().setFirst_name(redistributor.getItem(msg.arg2).getTitle());
        			}
        			break;
        		}
        	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	
	        }
	    });
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
 
        rootView = inflater.inflate(R.layout.distributor_sales_order_add_fragment, container, false);
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        AppManager.getInstance().getActiveCompaign(aq);
        salesArrayList=new ArrayList<DistributorSale>();
        freeItemsArrayList=new ArrayList<DistributorFreeItem>();
        distributorDetail=new DistributorDetail();
        initUI(); 
        rsfillfromDraft();
        return rootView;
    }
	
	public void onPause(){
		super.onPause();
		System.out.println("This is OnPause activity");
		rsaddDraft();
	}
	
	public void onStop(){
		super.onStop();
		System.out.println("This is onStop activity");
		rsaddDraft();
	}
	
	public void onDestroy(){
		super.onDestroy();
		System.out.println("This is onDestroy activity");
		rsaddDraft();
	}
	
	private void showDatePicker() 
	{
		  DatePickerFragment date = new DatePickerFragment();
		  Calendar calender = Calendar.getInstance();
		  Bundle args = new Bundle();
		  args.putInt("year", calender.get(Calendar.YEAR));
		  args.putInt("month", calender.get(Calendar.MONTH));
		  args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
		  date.setArguments(args);
		  date.setCallBack(ondate);
		  date.show(getActivity().getSupportFragmentManager(), "Date Picker");
	}
	OnDateSetListener ondate = new OnDateSetListener() 
	{
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth) 
		{
			String dateStr=String.valueOf(year) + "-" + String.valueOf(monthOfYear+1)+ "-" + String.valueOf(dayOfMonth);
			aq.id(R.id.editTextSalesDate).text(dateStr);
			distributorDetail.getRdsale().getRedistributorSale().setSale_date(dateStr);
		   //Toast.makeText(getActivity(),String.valueOf(year) + "-" + String.valueOf(monthOfYear+1)+ "-" + String.valueOf(dayOfMonth),Toast.LENGTH_LONG).show();
		}
	};
	private void initUI() 
	{
		ListView listView=aq.id(R.id.customerList).getListView();
		View header = LayoutInflater.from(getActivity()).inflate(R.layout.distributor_sales_order_add_list_header, null);
		listView.addHeaderView(header, null, false);
		View footer = LayoutInflater.from(getActivity()).inflate(R.layout.distributor_sales_order_add_list_footer, null);
		listView.addFooterView(footer, null, false);
		aqFooter=new AQuery(footer);
		
		if(qualifyingCompaignList!=null && qualifyingCompaignList.size()>0)
		{
			aq.id(R.id.buttonCompaignAvailable).visible();
		}
		aq.id(R.id.buttonCompaignAvailable).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(qualifyingCompaignList!=null && qualifyingCompaignList.size()>0)
				{
					showCompaignDialog(aq.getContext(), qualifyingCompaignList);
				}
				else
				{
					Toast.makeText(getActivity(), getString(R.string.select_customer), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonRedistributor).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Redistributors redistributor= AppManager.getInstance().getRedistributors(aq);
				if(redistributor!=null)
				{
					String[] arr=redistributor.getName();
					//redistributor.getItem(0);
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DISTRIBUTOR, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.distributor_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonCustomer).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				aq.id(R.id.buttonOfflineCustomer).text(getString(R.string.select_offline_customer));
				isOnlineCustomerSelectionModeOn=true;
				
				SearchCutomer.showAutosearchAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER);
				
				/*boolean flag=false;
				Customers customers = AppManager.getInstance().getCustomers(aq);
				if(customers!=null)
				{
					String[] arr=customers.getCustomerNamesArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.customer_required_mess), Toast.LENGTH_SHORT).show();
				}*/
			}
		});
		aq.id(R.id.buttonOfflineCustomer).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				isOnlineCustomerSelectionModeOn=false;
				aq.id(R.id.buttonCustomer).text(getString(R.string.select_customer));
				new GetOfflineCustomersAsyncTask(aq).execute();
			}
		});
		aq.id(R.id.editTextSalesDate).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				showDatePicker();
			}
		});
		salesAdapter= new ArrayAdapter<DistributorSale>(this.getActivity(), R.layout.distributor_sales_order_add_list_item, salesArrayList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.distributor_sales_order_add_list_item, parent, false);
	            }
	            final AQuery aql=new AQuery(convertView);
	            final int pos=position;
	            aql.id(R.id.removeButtonParent).clicked(new OnClickListener() 
				{
					@Override
					public void onClick(View v) 
					{
						salesArrayList.remove(pos);
						
						float grandTotal = getGrandTotal();
						distributorDetail.getRdsale().getRedistributorSale().setTotal(""+grandTotal);
						aqFooter.id(R.id.textViewGrandTotal).text(""+grandTotal);
						
						salesAdapter.notifyDataSetChanged();
						getFreeItems();
					}
				});
	            aql.id(R.id.textViewBrand).text(getItem(position).getBrand().getName());
	            aql.id(R.id.textViewUnit).text(getItem(position).getRedistributorSaleitem().getUnit());
	            aql.id(R.id.textViewUnitPrice).text(getItem(position).getRedistributorSaleitem().getUnit_price());
	            aql.id(R.id.textViewQuantity).text(getItem(position).getRedistributorSaleitem().getQuantity());
	            aql.id(R.id.textViewTotal).text(getItem(position).getRedistributorSaleitem().getAmount());
	            return convertView;
	        }
		};
		aqFooter.id(R.id.addMoreButtonParent).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				Intent intent=new Intent(getActivity(), DistributorSalesOrderItemAddActivity.class);
				startActivityForResult(intent, SALES_ITEM_ACTIVITY_CODE);
			}
		});
		listView.setAdapter(salesAdapter);
		
		ListView freeItemsView=aq.id(R.id.freeItemsList).getListView();
		View freeItemsHeader = LayoutInflater.from(getActivity()).inflate(R.layout.distributor_sales_order_view_list_freeitems_header, null);
		freeItemsView.addHeaderView(freeItemsHeader, null, false);
		freeItemsAdapter = new ArrayAdapter<DistributorFreeItem>(this.getActivity(), R.layout.distributor_sales_order_view_list_freeitems_item, freeItemsArrayList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.distributor_sales_order_view_list_freeitems_item, parent, false);
	            }
	            AQuery aql=new AQuery(convertView);
	            DistributorFreeItem freeItem=(DistributorFreeItem)getItem(position);
	            aql.id(R.id.textViewBrand).text(freeItem.getBrand().getName());
	            aql.id(R.id.textViewItem).text(freeItem.getRdFreeItem().getQuantity()+" "+freeItem.getRdFreeItem().getUnit());
	            return convertView;
	        }
		};
		freeItemsView.setAdapter(freeItemsAdapter);
		
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(!aq.id(R.id.buttonRedistributor).getTextView().getText().toString().startsWith("Select") && aq.id(R.id.buttonRedistributor).getTextView().getText().toString().length()>0)
				{
					if(aq.id(R.id.editTextSalesDate).getTextView().getText().toString().length()>0)
					{
						if(salesArrayList!=null && salesArrayList.size()>0)
						{
							distributorDetail.setSales(salesArrayList);
							distributorDetail.setFreeItems(freeItemsArrayList);
							
							
							if(AppManager.isOnline(getActivity())){
								
							 distributor_salesOrder_json = distributorDetail.createJson(aq,isOnlineCustomerSelectionModeOn);
							 Log.d("MTK",distributor_salesOrder_json );
							 new AddSalesOrder().execute();
								
								
							}
							else{
								DateFormat dateFormat = new SimpleDateFormat("HHmmss");
								distributorDetail.getRdsale().getRedistributor().setLast_name("");
								  Date date = new Date();
								 System.out.println(dateFormat.format(date));
								
								String  offlineAddedID = dateFormat.format(date).toString().replaceFirst("^0+(?!$)", "");	
								distributorDetail.getRdsale().getRedistributorSale().setId(offlineAddedID);	
								distributorDetail.getRdsale().getRedistributorSale().setCreated(AppConstant.getCurrentDateAndTime());
								distributorDetail.getRdsale().getRedistributorSale().setModified(AppConstant.SYNC_NOT_DONE);
								
								
								 String jsonStr = distributorDetail.createJson(aq,isOnlineCustomerSelectionModeOn,1);							
								Log.d("MTK",jsonStr );
								final SharedPreferences prefs=getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
								String str = prefs.getString("user_object", "");
								//final String token = prefs.getString("token", null);
								if(str!="")
								{
									try
									{
										JSONObject userJSONObject = new JSONObject(str);
										final User user=new User(userJSONObject);
										distributorDetail.getRdsale().getUser().setFirst_name(user.getFirst_name());
										distributorDetail.getRdsale().getUser().setLast_name(user.getLast_name());
										
										SharedPreferences rsprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
										Editor edt = rsprefs.edit();
										edt.putString("rsdraftJsonString", null);
										edt.commit();
										isDraft = true;
									}
									catch(Exception e){
										
									}
								}
								Y3QueryDataSource dataSource = new Y3QueryDataSource(getActivity());
							    dataSource.open();
							    
							   
				    		
				    		String json=		    		
				    		
				    		"{"+"\""+"Customer"+"\""+":{" 
				    		+"\"last_name\":\""+distributorDetail.getRdsale().getCustomer().getLast_name()+"\"," 
				    		+"\"first_name\":\""+distributorDetail.getRdsale().getCustomer().getFirst_name()+"\"," 
				    		+"\"id\":\""+distributorDetail.getRdsale().getCustomer().getId()+"\"}," 
				    		
				    		+"\""+"User"+"\""+":"+"{\"last_name\":\""+distributorDetail.getRdsale().getUser().getLast_name()+"\"," 
				    		+"\"first_name\":\""+distributorDetail.getRdsale().getUser().getFirst_name()+"\"},"
				    		
				    		+"\""+"RedistributorSale"+"\""+":"+"{"+"\"total\":\""+distributorDetail.getRdsale().getRedistributorSale().getTotal()+"\"," 
				    		+"\"id\":\""+distributorDetail.getRdsale().getRedistributorSale().getId()+"\"," 
				    		+"\"created\":\""+distributorDetail.getRdsale().getRedistributorSale().getCreated()+"\"," 
				    		+"\"status\":\""+distributorDetail.getRdsale().getRedistributorSale().getStatus()+"\"," 
				    		+"\"items\":\""+distributorDetail.getRdsale().getRedistributorSale().getItems()+"\"," 
				    		
				    		+ "\"user_id\":\""+distributorDetail.getRdsale().getRedistributorSale().getUser_id()+"\"," 
				    		+ "\"redistributor_id\":\""+distributorDetail.getRdsale().getRedistributorSale().getRedistributor_id()+"\"," +
				    		"\"sale_date\":\""+distributorDetail.getRdsale().getRedistributorSale().getSale_date()+"\"," +
				    		"\"customer_id\":\""+distributorDetail.getRdsale().getRedistributorSale().getCustomer_id()+"\"," +						    		
				    		"\"modified\":\""+distributorDetail.getRdsale().getRedistributorSale().getModified()+"\"},"
				    		
				    		+"\""+"Redistributor"+"\""+":"+"{\"last_name\":\""+distributorDetail.getRdsale().getRedistributor().getLast_name()+"\"," 
				    		+ "\"id\":\""+distributorDetail.getRdsale().getRedistributor().getId()+"\","
				    		+"\"first_name\":\""+distributorDetail.getRdsale().getRedistributor().getFirst_name()+"\"}," +"\""+"sno"+"\""+":"+null+"}";
							    
							    
				    		dataSource.addRedistributorSaleData( json,"1",jsonStr);
				    		showSaveDialog();
							//Toast.makeText(getActivity(), "DistributorSale Order added successfully.", Toast.LENGTH_SHORT).show();
					    	//getActivity().getSupportFragmentManager().popBackStack();    
							    
							    
							    
							    
							    
							    
							    
							    
							    
							    
								
								
							}
							
							
							
							
							
							/*Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
						    datasource.open();
						    long result = datasource.addY3Query(Y3QueryDataSource.ACTION_DISTRIBUTOR_SALESORDER_ADD, jsonStr, null);
						    datasource.close();
						    if(result!=-1)
						    {
						    	Toast.makeText(getActivity(), "DistributorSale Order added successfully.", Toast.LENGTH_SHORT).show();
						    	getActivity().getSupportFragmentManager().popBackStack();
						    }*/
						}
						else
						{
							Toast.makeText(getActivity(), getString(R.string.add_sale_item), Toast.LENGTH_SHORT).show();
						}
					}
					else
					{
						Toast.makeText(getActivity(), getString(R.string.enter_date), Toast.LENGTH_SHORT).show();
					}
				}
				else
				{
					Toast.makeText(getActivity(), getString(R.string.pls_select_redistributor), Toast.LENGTH_SHORT).show();
				}
			}
		});
	}
	private class GetOfflineCustomersAsyncTask extends AsyncTask<Void, Void,String[]>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		boolean flag=false;
		public GetOfflineCustomersAsyncTask(AQuery aq)
		{
			this.aq=aq;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected String[] doInBackground(Void... params) 
		{
			Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		    datasource.open();
			SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
			String token = prefs.getString("token", null);
		    offlineCustomers = datasource.getOfflineCustomeData(token);
		    datasource.close();
		    
		    if(offlineCustomers!=null)
			{
		    	Set<String> keys = offlineCustomers.keySet();
			    String[] arr=new String[keys.size()];
			    keys.toArray(arr);
			    return arr;
			}
			return null;
		}
		@Override
		protected void onPostExecute(String[] result) 
		{
			super.onPostExecute(result);
			if(result!=null)
			{
		    	if(result.length>0)
				{
					AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER, result);
					flag=true;
				}
			}
			if(!flag)
			{
				Toast.makeText(getActivity(), getString(R.string.offline_customer_mess), Toast.LENGTH_SHORT).show();
			}
			progressDialog.dismiss();
		}
	}
	private class GetCompaignAsyncTask extends AsyncTask<Void, Void,ArrayList<ActiveCompaigns>>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		String customerId;
		public GetCompaignAsyncTask(AQuery aq, String customerId)
		{
			this.aq=aq;
			this.customerId=customerId;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected ArrayList<ActiveCompaigns> doInBackground(Void... params) 
		{
			boolean flag=false;
			try
			{
				if(isOnlineCustomerSelectionModeOn)
				{
					Customer customer = AppManager.getInstance().getCustomerDetails(aq, customerId);
					if(customer!=null)
					{
						ActiveCompaignManager activeCompaignManager=AppManager.getInstance().getActiveCompaign(aq);
						if(activeCompaignManager!=null)
						{
							return activeCompaignManager.getQualifyingCompaign(customer.getDepot().getId(), customer.getRegion().getId());
						}
					}
				}
				else
				{
					if(distributorDetail.getOfflineCustomerJSON()!=null && distributorDetail.getOfflineCustomerJSON().length()>0)
					{
						JSONObject jsonObject=new JSONObject(distributorDetail.getOfflineCustomerJSON());
						if(jsonObject!=null && !jsonObject.isNull("depot_id") && !jsonObject.isNull("region_id"))
						{
							CustDepot suctDepot=new CustDepot();
							suctDepot.setId(jsonObject.getString("depot_id"));
							CustRegion custRegion=new CustRegion();
							custRegion.setId(jsonObject.getString("region_id"));
							
							ActiveCompaignManager activeCompaignManager=AppManager.getInstance().getActiveCompaign(aq);
							if(activeCompaignManager!=null)
							{
								flag=true;
								return activeCompaignManager.getQualifyingCompaign(suctDepot.getId(), custRegion.getId());
							}
						}
					}
				}
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			return new ArrayList<ActiveCompaigns>();
		}
		@Override
		protected void onPostExecute(final ArrayList<ActiveCompaigns> result) 
		{
			super.onPostExecute(result);
			if(result!=null && result.size()>0)
			{
				qualifyingCompaignList=result;
				//aq.id(R.id.buttonCompaignAvailable).visible();
				aq.id(R.id.salesItemsParent).visible();
				//aq.id(R.id.freeItemsParent).visible();
			}
			else
			{
				aq.id(R.id.buttonCompaignAvailable).invisible();
				aq.id(R.id.salesItemsParent).visible();
				aq.id(R.id.freeItemsParent).invisible();
			}
			progressDialog.dismiss();
		}
	}
	private void showCompaignDialog(Context context, ArrayList<ActiveCompaigns> compaignArrayList)
	{
	    final Dialog dialog = new Dialog(aq.getContext());
	    dialog.setTitle(R.string.Active_Campaigns);
	    View view = LayoutInflater.from(aq.getContext()).inflate(R.layout.compaign_dialog_main, null);
	    ListView lv = (ListView) view.findViewById(R.id.compaignList);
	    ArrayAdapter<ActiveCompaigns> compaignListaAdapter= new ArrayAdapter<ActiveCompaigns>(aq.getContext(), R.layout.compaign_dialog_listitem, compaignArrayList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.compaign_dialog_listitem, parent, false);
	            }
	            final AQuery aql=new AQuery(convertView);
	            ActiveCompaigns activeCompaigns=getItem(position);
	            aql.id(R.id.textViewCompaignTitle).text(activeCompaigns.getCompaign().getTitle());
	            aql.id(R.id.textViewCompaignDescription).text("Get "+activeCompaigns.getCompaign().getFree_qty()+" "+activeCompaigns.getCompaign().getFree_unit()+" of \""+activeCompaigns.getBrand().getName()+"\" on puchase of "+activeCompaigns.getCompaign().getRequired_qty()+" "+activeCompaigns.getCompaign().getRequired_unit()+" "+activeCompaigns.getBrand().getName());
	            return convertView;
	        }
		};
	    lv.setAdapter(compaignListaAdapter);
	    dialog.setContentView(view);
	    dialog.setCancelable(true);
	    dialog.show();
	}
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode==Activity.RESULT_OK)
		{
			if(requestCode == SALES_ITEM_ACTIVITY_CODE)
			{
				DistributorSale salesItem = data.getParcelableExtra("ADDED_SALES_ITEM");
				salesArrayList.add(salesItem);
				float grandTotal = getGrandTotal();
				distributorDetail.getRdsale().getRedistributorSale().setTotal(""+grandTotal);
				aqFooter.id(R.id.textViewGrandTotal).text(""+grandTotal);
				getFreeItems();
				salesAdapter.notifyDataSetChanged();
			}
		}
	}
	private void getFreeItems()
	{
		if(qualifyingCompaignList==null || qualifyingCompaignList.size()==0)
			return;
		Hashtable<String, Float> salesTable=new Hashtable<String, Float>(); 
		freeItemsArrayList.clear();
 		for(ActiveCompaigns comp:qualifyingCompaignList)
		{
 			for(DistributorSale sales: salesArrayList)
 			{
 				if(comp.getCompaign().getBrand_id().equals(sales.getRedistributorSaleitem().getBrand_id()))
 				{
 					if(comp.getCompaign().getRequired_unit().equals(sales.getRedistributorSaleitem().getUnit()))
 					{
 						if(salesTable.containsKey(comp.getCompaign().getId()))
 						{
 							Float qty = salesTable.get(comp.getCompaign().getId());
 							qty=qty+Float.parseFloat(sales.getRedistributorSaleitem().getQuantity());
 							salesTable.put(comp.getCompaign().getId(), qty);
 						}
 						else
 						{
 							salesTable.put(comp.getCompaign().getId(), Float.parseFloat(sales.getRedistributorSaleitem().getQuantity()));
 						}
 					}
 				}
 			}
		}
 		for(ActiveCompaigns comp:qualifyingCompaignList)
 		{
 			if(salesTable.containsKey(comp.getCompaign().getId()))
 			{
 				if(Float.parseFloat(comp.getCompaign().getRequired_qty())<=salesTable.get(comp.getCompaign().getId()))
				{
 					DistributorFreeItem freeItem=new DistributorFreeItem();
 					freeItem.getRdFreeItem().setBrand_id(comp.getCompaign().getBrand_id());
 					freeItem.getBrand().setName(comp.getBrand().getName());
 					freeItem.getRdFreeItem().setUnit(comp.getCompaign().getRequired_unit());
 					Float freeItemCount=salesTable.get(comp.getCompaign().getId())/Float.parseFloat(comp.getCompaign().getRequired_qty());
 					int roundOfCount=(int)(freeItemCount.floatValue());
 					freeItem.getRdFreeItem().setQuantity(""+roundOfCount);
 					freeItem.getRdFreeItem().setCompaign_id(comp.getCompaign().getId());
 					freeItemsArrayList.add(freeItem);
				}
 			}
 		}
 		freeItemsAdapter.notifyDataSetChanged();
 	}
	private float getGrandTotal()
	{
		float grandTotal=0f;
		for(DistributorSale sales:salesArrayList)
		{
			float amount=Float.parseFloat(sales.getRedistributorSaleitem().getAmount());
			grandTotal=grandTotal+amount;
		}
		return grandTotal;
	}
	
	private class AddSalesOrder extends AsyncTask<Void, Void, String> {

		ProgressDialog progressDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
			progressDialog.setMessage(getString(R.string.wait_progress));
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(true);
			progressDialog.show();
			progressDialog
					.setOnKeyListener(new DialogInterface.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog,
								int keyCode, KeyEvent event) {
							return false;
						}
					});
		}


		protected String doInBackground(Void... params) {
			if (AppManager.getInstance().isOnline(aq.getContext())) {
				//return AppManager.getInstance().getCustomerList(aq, pageCount);
				Hashtable<String,String> params1=new Hashtable<String,String>();
				params1.put("jsonString", distributor_salesOrder_json);			
				String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_DISTRIBUTOR_SALESORDER, params1, null);
				return response;
			}
			return null;
		}

		protected void onPostExecute(String response) {
			
			progressDialog.dismiss();
			
			try {
				if(response!=null){
				int errorCode=new JSONObject(response).getInt("error");
				
				if(errorCode==0){
					System.out.println("Added");
					 //Toast.makeText(getActivity(), "DistributorSale Order added successfully.", Toast.LENGTH_SHORT).show();
				     //getActivity().getSupportFragmentManager().popBackStack();
					showSaveDialog();
					SharedPreferences rsprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
					Editor edt = rsprefs.edit();
					edt.putString("rsdraftJsonString", null);
					edt.commit();
					isDraft = true;
				}
				else{
					System.out.println("something wrong");
					
				}
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
	
}
	private void showSaveDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(R.string.confirm);
		alertDialogBuilder
				.setMessage(R.string.confirm_rd_sale)
				.setCancelable(false)
				.setPositiveButton(
						R.string.OK,
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								getActivity().getSupportFragmentManager().popBackStack();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
	
	public void rsaddDraft(){
		if(!isDraft){
			distributorDetail.getRdsale().getRedistributor().setId(redistributor_id);
			distributorDetail.getRdsale().getRedistributorSale().setRedistributor_id(redistributor_id);
			distributorDetail.getRdsale().getRedistributor().setFirst_name(aq.id(R.id.buttonRedistributor).getButton().getText().toString());		
		
			distributorDetail.getRdsale().getCustomer().setId(customer_id);
			distributorDetail.getRdsale().getRedistributorSale().setCustomer_id(customer_id);
			distributorDetail.getRdsale().getCustomer().setFirst_name(aq.id(R.id.buttonCustomer).getButton().getText().toString());		
			
			distributorDetail.getRdsale().getRedistributorSale().setSale_date(aq.id(R.id.editTextSalesDate).getEditText().getText().toString());
			
			
			String rsdraftJsonString = distributorDetail.createJson(aq,true);			
			SharedPreferences rsprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
			Editor edt = rsprefs.edit();
			edt.putString("rsdraftJsonString", rsdraftJsonString);
			edt.commit();
			isDraft = true;
		}
	}
	
	
	
	public void rsfillfromDraft(){
		SharedPreferences rsprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		String rsdraftJsonString = rsprefs.getString("rsdraftJsonString", null);
		//System.out.println("CUstomerLIST:"+rsdraftJsonString);
		if(rsdraftJsonString != null){
			try {
				JSONObject redistributorJson = new JSONObject(rsdraftJsonString);
				
				redistributor_id = redistributorJson.isNull("redistributor_id") ? ""	: redistributorJson.getString("redistributor_id");
				Redistributors distributors = AppManager.getInstance().getRedistributors(aq);
				String DistributorName = distributors.getDepotNameById(redistributor_id);
				aq.id(R.id.buttonRedistributor).text(DistributorName); 
				
				customer_id = redistributorJson.isNull("customer_id") ? ""	: redistributorJson.getString("customer_id");
				distributorDetail.getRdsale().getRedistributorSale().setCustomer_id(customer_id);
				String CustomerName = redistributorJson.isNull("customer_name") ? ""	: redistributorJson.getString("customer_name");
				aq.id(R.id.buttonCustomer).text(CustomerName); 
				
	            String SaleDate = redistributorJson.isNull("sale_date") ? ""	: redistributorJson.getString("sale_date");	
				aq.id(R.id.editTextSalesDate).text(SaleDate);
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
}
