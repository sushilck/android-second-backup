package com.smalution.y3distributiontg1;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;

import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.smalution.y3distributiontg1.R;
import com.smalution.y3distributiontg1.utils.AppConstant;

public class SendDataToServerAsyncTask<T> extends AsyncTask<Void, Void, Integer>
{
	FragmentActivity context;
	String jsonStr;
	String imagePath;
	String url;
	String Opcode;
	String successMessage;
	boolean isPopFragment;
	ArrayAdapter<T> adapter;
	ArrayList<T> list;
	int position;
	String operationCode;
	public SendDataToServerAsyncTask(
			FragmentActivity context, 
			String jsonStr,
			String imagePath, 
			String url,
			String successMessage,
			boolean isPopFragment,
			ArrayAdapter<T> adapter,
			ArrayList<T> list,
			int position,
			String Opcode)
	{
		this.context=context;
		this.jsonStr=jsonStr;
		this.imagePath=imagePath;
		this.url=url;
		this.successMessage=successMessage;
		this.isPopFragment=isPopFragment;
		this.adapter=adapter;
		this.list=list;
		this.position=position;
		this.operationCode=Opcode;
	}
	ProgressDialog progressDialog;
	@Override
	protected void onPreExecute() 
	{
		super.onPreExecute();
		progressDialog = new ProgressDialog(context);
        progressDialog.setMessage(context.getString(R.string.wait_progress));
        progressDialog.setCancelable(false);
        progressDialog.setIndeterminate(true);
        progressDialog.show();
        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
        {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
            {
                return false;
            }
        });
	}
	@Override
	protected Integer doInBackground(Void... params) 
	{
		try
		{
			if(AppManager.getInstance().isOnline(context))
			{
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", jsonStr);
				Hashtable<String,File> fileParams=null;
	    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
	    		{
	    			fileParams=new Hashtable<String,File>();
		    		fileParams.put("image", new File(imagePath));
	    		}
			    String response = Utils.post(context, url, parameters, fileParams);
	    		Log.d("MTK", "server response: "+response);
	    		if(response!=null)
	    		{
	    			int error = new JSONObject(response).getInt("error");
	    			if(error==0)
	    			{
	    				return 0;
	    			}
	    			else if(error==3)//invalid token
	    			{
	    				return 3;
	    			}
	    			else
	    			{
	    				return 2;
	    			}
	    		}
			}
			else
			{
				return 1;
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return 2;
	}
	@Override
	protected void onPostExecute(Integer result) 
	{
		super.onPostExecute(result);
		if(result==0)
		{
		
			if(AppConstant.CUSTOMER_EDIT_OPCODE.equals(operationCode))
			{
				showDialog(successMessage);
				
			}
			else if(AppConstant.CUSTOMER_VISIT_EDIT.equals(operationCode)){
				showDialog(successMessage);
			}
			else if(AppConstant.INCENTIVE_EDIT.equals(operationCode)){
				showDialog(successMessage);
			}
			else if(AppConstant.PAYMENT_EDIT.equals(operationCode)){
				showDialog(successMessage);
			}
			else{			
			Toast.makeText(context, successMessage, Toast.LENGTH_SHORT).show();
			position=position-1;
			if(isPopFragment)
				context.getSupportFragmentManager().popBackStack();
			if(adapter!=null)
			{
				adapter.notifyDataSetChanged();
				list.remove(position);
			}
			}
		}
		else if(result==1)//network not available
		{
			Toast.makeText(context, R.string.network_not_available, Toast.LENGTH_SHORT).show();
		}
		else if(result==2)//server error
		{
			Toast.makeText(context, R.string.something_wrong, Toast.LENGTH_SHORT).show();
		}
		else if(result==3)//invalid token
		{
			Toast.makeText(context, R.string.login_expire, Toast.LENGTH_LONG).show();
		}
		progressDialog.dismiss();
	}
	private void showDialog(String message){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				context);
		alertDialogBuilder.setTitle(R.string.confirm);
		alertDialogBuilder
				.setMessage(message)
				.setCancelable(false)
				.setPositiveButton(
						R.string.OK,
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								context.getSupportFragmentManager().popBackStack();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
}
