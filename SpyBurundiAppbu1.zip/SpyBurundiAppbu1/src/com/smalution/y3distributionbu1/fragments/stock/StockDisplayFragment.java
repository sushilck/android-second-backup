package com.smalution.y3distributionbu1.fragments.stock;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.database.DataSetObserver;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;

import com.androidquery.AQuery;
import com.smalution.y3distributionbu1.AppManager;
import com.smalution.y3distributionbu1.R;
import com.smalution.y3distributionbu1.fragments.SuperFragment;
import com.smalution.y3distributionbu1.fragments.payments.PaymentsAddFragment.UIHandler;

public class StockDisplayFragment extends SuperFragment {
	View rootView;
	AQuery aq; 
	AQuery aqf;
	UIHandler uiHandler;
	ArrayAdapter<String> stockAdapter;
	ArrayAdapter<String> stockStatusAdapter;
	ArrayList<String> stockList = new ArrayList<String>();
	ArrayList<String> stockStatusList = new ArrayList<String>();
	int pageCount = 1;
	String opt = "csts";
	View footer;
	boolean hasNextPage = false;
	
	  public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
		{
	        rootView = inflater.inflate(R.layout.stock_display_fragment, container, false);
	       // uiHandler=new UIHandler();
	        aq=new AQuery(rootView);
	        
	        appInit();
	        return rootView;
	    }
	  
	  public void appInit(){ 
		  
		  if (AppManager.isOnline(getActivity())){
			  initUI();
			  new StockListAsyncTask(aq).execute();
		  }else{
			  //TODO
			  aq.id(R.id.offlineLayout).visible();			  
			  aq.id(R.id.stockStatus).invisible();
			  aq.id(R.id.stockInHeader).invisible();
			  aq.id(R.id.stockOutHeader).invisible();
		  }
	  }
	  
	  public void initUI(){
		
		  aq.id(R.id.buttonRefresh).clicked(new OnClickListener() 
		  {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				pageCount = 1;
				stockList.clear();
				stockStatusList.clear();
				stockAdapter.notifyDataSetChanged();
				stockStatusAdapter.notifyDataSetChanged();
				if(opt.equals("csts")){
					aqf.id(R.id.buttonLoadMoreListItems).invisible();
				}
				doinbackground();
			}		  
		  });
		  aq.id(R.id.buttonStockStatus).clicked(new OnClickListener(){
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				opt = "csts";
				aq.id(R.id.stockViewTitle).text(getString(R.string.stockStatus));
				aqf.id(R.id.buttonLoadMoreListItems).invisible();
				pageCount = 1;
				stockList.clear();
				stockAdapter.notifyDataSetChanged();
				stockStatusList.clear();
				stockStatusAdapter.notifyDataSetChanged();
				
				aq.id(R.id.stockStatus).visible();
				aq.id(R.id.stockInHeader).invisible();
				aq.id(R.id.stockOutHeader).invisible();
				doinbackground();
			}			  
		  });
			  
		  aq.id(R.id.buttonStockIn).clicked(new OnClickListener(){
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub				
				
				opt = "stockIn";
				aq.id(R.id.stockViewTitle).text(getString(R.string.stockIn));
				
				pageCount = 1;
				
				stockList.clear();
				stockAdapter.notifyDataSetChanged();
				
				stockStatusList.clear();
				stockStatusAdapter.notifyDataSetChanged();
				
				aq.id(R.id.stockStatus).invisible();
				aq.id(R.id.stockInHeader).visible();
				aq.id(R.id.stockOutHeader).invisible();
				doinbackground();
			}			  
		  });
		  
		  aq.id(R.id.buttonStockOut).clicked(new OnClickListener(){

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					opt = "stockOut";
					aq.id(R.id.stockViewTitle).text(getString(R.string.stockOut));
					pageCount = 1;
					stockStatusList.clear();
					stockStatusAdapter.notifyDataSetChanged();
					
					stockList.clear();
					stockAdapter.notifyDataSetChanged();
					
					aq.id(R.id.stockStatus).invisible();
					aq.id(R.id.stockInHeader).invisible();
					aq.id(R.id.stockOutHeader).visible();
					doinbackground();					
				}
		 });
		 
		 aq.id(R.id.buttonStockAdd).clicked(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
				FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
				Fragment fragment = fragmentManager.findFragmentByTag("StockAddFragment");
				Bundle bundle = new Bundle();
				// bundle.putParcelable("CUSTOMER", customer);
				if (fragment == null) {
					fragment = new StockAddFragment();
					fragment.setArguments(bundle);
					fragmentTransaction.addToBackStack("StockAddFragment");
				} else {
					((StockAddFragment) fragment).setUIArguments(bundle);
				}
				fragmentTransaction.replace(R.id.frame_container, fragment,"StockAddFragment");
				fragmentTransaction.addToBackStack(null);
				fragmentTransaction.commit();
				
			}
			 
		 });
		  
	  stockStatusAdapter = new ArrayAdapter<String>(aq.getContext(), R.layout.stock_statusitem, stockStatusList){
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.stock_statusitem, parent, false);
	            }
	           
	            final AQuery aql = new AQuery(convertView);		           
	            String stockItem = getItem(position);
	            
	            JSONObject stockItemObj;
				try {
					stockItemObj = new JSONObject(stockItem);
					String brand = stockItemObj.isNull("brand")?"":stockItemObj.getString("brand");
					aql.id(R.id.textBrand).text(brand);
					
					String openingStock = stockItemObj.isNull("opening_stock")?"":stockItemObj.getString("opening_stock"); 
					aql.id(R.id.textOpStock).text(openingStock);
					
					String recievedStock = stockItemObj.isNull("recieved_stock")?"":stockItemObj.getString("recieved_stock"); 
					aql.id(R.id.textRcStock).text(recievedStock);						
					String stockIn = stockItemObj.isNull("stock_in")?"":stockItemObj.getString("stock_in"); 
					aql.id(R.id.textStockIn).text(stockIn);
					
					String totStockOut = stockItemObj.isNull("total_out_stock")?"":stockItemObj.getString("total_out_stock"); 
					aql.id(R.id.textStockOut).text(totStockOut);
					
					String closingStock1 = stockItemObj.isNull("closing_stock")?"":stockItemObj.getString("closing_stock"); 
					aql.id(R.id.textClosingStock).text(closingStock1);
					
					//System.out.println(brand+"::"+closingStock1+"::"+openingStock);
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
	            return convertView;
	        }
		};
		
		 //ListView stockStatusView = aq.id(R.id.stockStatusList).getListView();
		// stockStatusView.setAdapter(stockStatusAdapter);
		 
		 aq.id(R.id.stockStatusList).getListView().setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
		 aq.id(R.id.stockStatusList).getListView().setAdapter(stockStatusAdapter);
		 stockStatusAdapter.registerDataSetObserver(new DataSetObserver() 
		 {
		    @Override
		    public void onChanged() 
		    {
		        super.onChanged();
		        aq.id(R.id.stockStatusList).getListView().setSelection(0);		        
		    }
		 });
		 
		 
		 stockAdapter = new ArrayAdapter<String>(aq.getContext(), R.layout.stock_listitem, stockList){
				public View getView(int position, View convertView, ViewGroup parent) 
		        {
		            if(convertView == null)
		            {
	                     convertView = getActivity().getLayoutInflater().inflate(R.layout.stock_listitem, parent, false);
		            }
		           
		            final AQuery aql = new AQuery(convertView);		           
		            String stockItem = getItem(position);
		            
		            JSONObject stockItemObj;
					try {
						stockItemObj = new JSONObject(stockItem);
						//textViewSerialNo
						String sno = stockItemObj.isNull("sno")?"0":stockItemObj.getString("sno");
						aql.id(R.id.textViewSerialNo).text(sno);
						
						String brand = stockItemObj.isNull("brand")?"":stockItemObj.getString("brand");
						aql.id(R.id.textViewBrand).text(brand);
						
						String qty = stockItemObj.isNull("qty")?"":stockItemObj.getString("qty"); 
						aql.id(R.id.textViewQty).text(qty);
						
						String recieved_date = stockItemObj.isNull("recieved_date")?"":stockItemObj.getString("recieved_date"); 
						aql.id(R.id.textViewRecievedDate).text(recieved_date);
						
						String source = stockItemObj.isNull("source")?"":stockItemObj.getString("source"); 
						String destination = stockItemObj.isNull("destination")?"":stockItemObj.getString("destination"); 
						if(opt.equals("stockIn")){
							aql.id(R.id.textViewSource).text(source);
						}else{
							aql.id(R.id.textViewSource).text(destination);
						}
							
						
						String added_by = stockItemObj.isNull("added_by")?"":stockItemObj.getString("added_by"); 
						aql.id(R.id.textViewSendBy).text(added_by);
						
						//System.out.println(brand+"::"+closingStock1+"::"+openingStock);
						
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
					
		            return convertView;
		        }
			};
			
			 stockAdapter.registerDataSetObserver(new DataSetObserver() 
			 {
			    @Override
			    public void onChanged() 
			    {
			        super.onChanged();
			        if(pageCount==1)
			        {
			        	aq.id(R.id.stockStatusList).getListView().setSelection(0);
			        }
			        else
			        {
			        	aq.id(R.id.stockStatusList).getListView().setSelection(stockAdapter.getCount() - 1);
			        }    
			     	        
			    }
			 });
			 
		
		 if ( pageCount == 1 ) {
				footer = LayoutInflater.from(getActivity()).inflate(R.layout.load_more_list_footer, null);
				aqf = new AQuery(footer);
				
				aqf.id(R.id.buttonLoadMoreListItems).clicked(new OnClickListener() {
					@Override
					public void onClick(View v) {
						new StockListAsyncTask(aq).execute();
					}
				});
				aq.id(R.id.stockStatusList).getListView().addFooterView(footer, null, true);
				if(opt.equals("csts")){
					aqf.id(R.id.buttonLoadMoreListItems).invisible();
				}
		 }
		 
	  }
	  
	 public void doinbackground(){
		 
		 if (AppManager.isOnline(getActivity())){
			  new StockListAsyncTask(aq).execute();
		  }else{
			  //TODO
			  aq.id(R.id.offlineLayout).visible();
			  
			  aq.id(R.id.stockStatus).invisible();
			  aq.id(R.id.stockInHeader).invisible();
			  aq.id(R.id.stockOutHeader).invisible();
		  }
		 
	 }
	  
	  private class StockListAsyncTask extends AsyncTask<Void, Void, String>{
		AQuery aq;
		ProgressDialog progressDialog;
		public StockListAsyncTask(AQuery aq){
			this.aq=aq;
			//pageCount=pageCount+1;
		}
		@Override
		protected void onPreExecute(){
			super.onPreExecute();
			if(getActivity()==null){
				progressDialog = new ProgressDialog(aq.getContext());
			}else{
				progressDialog = new ProgressDialog(getActivity());
				
			}
			if(opt.equals("csts")){
				//aqf.id(R.id.buttonLoadMoreListItems).invisible();
			}
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected String doInBackground(Void... params) {
			AppManager.getInstance();
			// TODO Auto-generated method stub
			if(AppManager.isOnline(aq.getContext()))
			{
				return AppManager.getInstance().getStockList(aq,pageCount,opt);
			}
			return null;
		}
		
		protected void onPostExecute(String result){
			super.onPostExecute(result);
			if(result!=null){
				if(opt.equals("csts")){
					displayStockStatus(result);
					
				}else{
					displayStockView(result);
				}
			}
			progressDialog.dismiss();
		}
	}
	  
	  public void displayStockStatus(String result){
		  JSONObject resultData = null;
		  String errorCode = null;
		  String stockStr = null;
		 
		try {
			resultData = new JSONObject(result);
			errorCode = resultData.isNull("error") ? "0" : resultData.getString("error");
			stockStr = resultData.isNull("stocks") ? "[]" : resultData.getJSONArray("stocks").toString();
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(errorCode.equals("0") && stockStatusAdapter != null){
			JSONArray stocksArr;
			try {
				stocksArr = new JSONArray(stockStr);
				System.out.println("Arrat length :"+stocksArr.length());
				
				stockStatusList.clear();
				for(int i=0; i < stocksArr.length();i++){
					stockStatusList.add(stocksArr.getJSONObject(i).toString());
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			aq.id(R.id.stockStatusList).getListView().setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
			aq.id(R.id.stockStatusList).getListView().setAdapter(stockStatusAdapter);
			stockStatusAdapter.notifyDataSetChanged();
		}else{
			System.out.println("Error Code: "+errorCode);
		}
	    return;
	    
	  }
	  
	  
	  public void displayStockView(String result){
		  JSONObject resultData = null;
		  String errorCode = null;
		  String stockStr = null;
		  JSONObject pagingObject = null;
		  
		try {
			resultData = new JSONObject(result);
			errorCode = resultData.isNull("error") ? "0" : resultData.getString("error");
			stockStr = resultData.isNull("stocks") ? "[]" : resultData.getJSONArray("stocks").toString();
			pagingObject = resultData.isNull("paging") ? null : resultData.getJSONObject("paging");
			String nextPage = pagingObject.getString("nextPage").toString();
			if(!nextPage.equals("null")){
				pageCount = Integer.parseInt(nextPage);
				aqf.id(R.id.buttonLoadMoreListItems).visible();
			}else{
				aqf.id(R.id.buttonLoadMoreListItems).invisible();
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(errorCode.equals("0") ){
			JSONArray stocksArr;
			try {
				stocksArr = new JSONArray(stockStr);
				for(int i=0; i < stocksArr.length();i++){
					stockList.add(stocksArr.getJSONObject(i).toString());
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println(stockStr);
			aq.id(R.id.stockStatusList).getListView().setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
			aq.id(R.id.stockStatusList).getListView().setAdapter(stockAdapter);
			stockAdapter.notifyDataSetChanged();
			
		}else{
			System.out.println("Error Code: "+errorCode);
		}
		
		if(opt.equals("stockOut")){
        	aq.id(R.id.stockViewTitle).text(getString(R.string.stockOut));			
			aq.id(R.id.stockStatus).invisible();
			aq.id(R.id.stockInHeader).invisible();
			aq.id(R.id.stockOutHeader).visible();
    	}
		
		return;
	  }

	public void setUIArguments(Bundle bundle) {
		// TODO Auto-generated method stub
		//Bundle arg = getArguments();
        if(bundle != null){
        	opt = bundle.getString("opt", "csts");
        	pageCount = 1;
			stockStatusList.clear();
			stockStatusAdapter.notifyDataSetChanged();
			
			stockList.clear();
			stockAdapter.notifyDataSetChanged();
        	
        }
    
	}

	
}
