package com.smalution.y3distributionbu1.fragments.incentive;

import com.smalution.y3distributionbu1.AppManager;
import com.smalution.y3distributionbu1.R;
import com.smalution.y3distributionbu1.SendDataToServerAsyncTask;
import com.smalution.y3distributionbu1.database.Y3QueryDataSource;
import com.smalution.y3distributionbu1.entities.customer.SearchCutomer;
import com.smalution.y3distributionbu1.entities.incentive.IncentiveItem;
import com.smalution.y3distributionbu1.entities.settings.Brands;
import com.smalution.y3distributionbu1.entities.settings.Customers;
import com.smalution.y3distributionbu1.entities.settings.Depots;
import com.smalution.y3distributionbu1.entities.settings.SelectionButtonItem;
import com.smalution.y3distributionbu1.fragments.SuperFragment;
import com.smalution.y3distributionbu1.utils.AppConstant;
import com.smalution.y3distributionbu1.utils.DatePickerFragment;

import java.util.Calendar;
import java.util.Hashtable;
import java.util.Set;

import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.Toast;

import com.androidquery.AQuery;

public class IncentiveEditFragment extends SuperFragment 
{
	boolean isOnlineCustomerSelectionModeOn=true;
	IncentiveItem incentiveItem;
	View rootView;
	AQuery aq; 
	Hashtable<String, String> offlineCustomers;
	public static final int FLAG_SELECT_CUSTOMER=101;
	public static final int FLAG_SELECT_BRAND=102;
	public static final int FLAG_SELECT_DEPOT=103;
	public static final int FLAG_SELECT_INCENTIVETYPE=104;
	public static final int FLAG_SELECT_UNIT=105;
	UIHandler uiHandler;
	public static String jsonString;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		case FLAG_SELECT_CUSTOMER:
        		{
        			
        			if(isOnlineCustomerSelectionModeOn)
        			{
        				//Customers customers= AppManager.getInstance().getCustomers(aq);
        				SelectionButtonItem itm = (SelectionButtonItem) msg.obj;
        				if(msg.arg2 != 0)
        				{
        					incentiveItem.getCustomer().setId(itm.getId());
    						incentiveItem.getCustomer().setFname(itm.getTitle());
    						incentiveItem.getCustomer().setLname("");
        				}
        				/*if(customers!=null)
        				{
        					SelectionButtonItem itm = customers.getItem(msg.arg2);
        					if(itm!=null)
        					{
        						incentiveItem.getCustomer().setId(itm.getId());
        						incentiveItem.getCustomer().setFname(itm.getTitle());
        						incentiveItem.getCustomer().setLname("");
        					}
        				}*/
        				aq.id(R.id.buttonCustomer).text(itm.getTitle());
            			aq.id(R.id.buttonOfflineCustomer).text(getString(R.string.select_offline_customer));
        			}
        			else
        			{
        				String selectedValue=(String)msg.obj;
        				aq.id(R.id.buttonCustomer).text(getString(R.string.select_customer));
        				aq.id(R.id.buttonOfflineCustomer).text(selectedValue);
        			}
        			break;
				}
        		case FLAG_SELECT_BRAND:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonBrand).text(selectedValue);
        			Brands brands= AppManager.getInstance().getBrands(aq);
        			if(brands!=null)
        			{
        				incentiveItem.getBrand().setId(brands.getItem(msg.arg2).getId());
        			}
        			break;
        		}
        		case FLAG_SELECT_DEPOT:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonDepot).text(selectedValue);
        			Depots depots= AppManager.getInstance().getDepots(aq);
        			if(depots!=null)
        			{
        				String id = depots.getItem(msg.arg2).getId();
        				if(id!=null)
        				{
        					incentiveItem.getDepot().setId(id);
        					
        				}
        			}
        			break;
        		}
        		case FLAG_SELECT_INCENTIVETYPE:
	    		{
	    			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonIncentiveType).text(selectedValue);
        			break;
	    		}
        		case FLAG_SELECT_UNIT:
	    		{
	    			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonUnit).text(selectedValue);
        			break;
	    		}
	    	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	incentiveItem = args.getParcelable("PAYMENT");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		incentiveItem = getArguments().getParcelable("PAYMENT");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.incentive_edit_fragment, container, false);
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        initUI();
        return rootView;
    }
	private void initUI() 
	{
		aq.id(R.id.buttonCustomer).text(incentiveItem.getCustomer().getFname()+" "+incentiveItem.getCustomer().getLname());
		aq.id(R.id.editTextDateOfIncentive).text(incentiveItem.getIncentive().getIncentive_date());
		aq.id(R.id.buttonBrand).text(incentiveItem.getBrand().getName());
		aq.id(R.id.buttonDepot).text(incentiveItem.getDepot().getTitle());
		aq.id(R.id.buttonIncentiveType).text(incentiveItem.getIncentive().getIncentive_type());
		aq.id(R.id.buttonUnit).text(incentiveItem.getIncentive().getUnit());
		aq.id(R.id.editTextQuantity).text(incentiveItem.getIncentive().getQuantity());
		
		aq.id(R.id.buttonCustomer).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				aq.id(R.id.buttonOfflineCustomer).text(getString(R.string.select_offline_customer));
				isOnlineCustomerSelectionModeOn=true;
				
				SearchCutomer.showAutosearchAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER);
				
				/*boolean flag=false;
				final Customers customers= AppManager.getInstance().getCustomers(aq);
				if(customers!=null)
				{
					String[] arr=customers.getCustomerNamesArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.customer_required_mess), Toast.LENGTH_SHORT).show();
				}*/
			}
		});
		aq.id(R.id.buttonOfflineCustomer).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				isOnlineCustomerSelectionModeOn=false;
				aq.id(R.id.buttonCustomer).text(getString(R.string.select_customer));
				new GetOfflineCustomersAsyncTask(aq).execute();
			}
		});
		aq.id(R.id.editTextDateOfIncentive).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				showDatePicker();
			}
		});
		
		aq.id(R.id.buttonBrand).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				Brands brands = AppManager.getInstance().getBrands(aq);
				boolean flag=false;
				if(brands!=null)
				{
					String[] arr=brands.getBrandsNames();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_BRAND, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.brand_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		aq.id(R.id.buttonDepot).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				Depots depots= AppManager.getInstance().getDepots(aq);
				boolean flag=false;
				if(depots!=null)
				{
					String[] arr=depots.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DEPOT, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.depot_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		aq.id(R.id.buttonIncentiveType).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				String[] arr= AppManager.incetiveTypes;
				if(arr.length>0)
				{
					AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_INCENTIVETYPE, arr);
					flag=true;
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.incentive_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		aq.id(R.id.buttonUnit).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				String[] arr= AppManager.units;
				if(arr.length>0)
				{
					AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_UNIT, arr);
					flag=true;
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.unit_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(validateInput())
				{
					
					if(AppManager.isOnline(getActivity())){
						String jsonString = incentiveItem.createJson(aq, true,isOnlineCustomerSelectionModeOn);
						new SendDataToServerAsyncTask<IncentiveItem>(
					    		getActivity(), 
					    		jsonString,
					    		null, 
					    		AppManager.getInstance().URL_UPDATE_INCENTIVE,
					    		getString(R.string.incentive_updated),
					    		true,
					    		null,
					    		null,
					    		-1,AppConstant.INCENTIVE_EDIT).execute();
					}else{
						
						Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
					    datasource.open();					   
					    incentiveItem.getOfflineCustomerJSON();
					    datasource.updateIncentive(incentiveItem, incentiveItem.getIncentive().getId(), jsonString);
					    showEditDialog();
					    // Toast.makeText(getActivity(), "Incentive update successfully.", Toast.LENGTH_SHORT).show();
				    	//getActivity().getSupportFragmentManager().popBackStack();
						
						
						
					}
					
					
					
					
					
					
				}
			}
		});
	}
	private boolean validateInput()
	{
		if(
		validateCustomerName()&&
		validateDateOfIncentive()&&
		validateBrand()&&
		validateDepot()&&
		validateIncentiveType()&&
		validateUnit()&&
		validateQuantity()
		)
		{
			return true;
		}
		return false;
	}
	private boolean validateCustomerName()
	{
		boolean flag=false;
		if(isOnlineCustomerSelectionModeOn)
		{
			String customerName = aq.id(R.id.buttonCustomer).getText().toString();
			if(incentiveItem.getCustomer()!=null && incentiveItem.getCustomer().getId()!=null)
			{
				flag=true;
			}
		}
		else
		{
			String customerName = aq.id(R.id.buttonOfflineCustomer).getText().toString();
			if(customerName!=null && customerName.length()>0)
			{
				jsonString = offlineCustomers.get(customerName);
				try{
				JSONObject jsonojb=new JSONObject(jsonString);				
				incentiveItem.getCustomer().setFname(jsonojb.getString("first_name"));
				incentiveItem.getCustomer().setLname(jsonojb.getString("last_name"));
				}
				catch(Exception e){
					e.printStackTrace();
				}
						
				incentiveItem.setOfflineCustomerJSON(jsonString);
				return true;
			}
		}
		
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.select_customer), Toast.LENGTH_SHORT).show();
		}
		return flag;
	}
	private boolean validateDateOfIncentive()
	{
		boolean flag=false;
		String DateOfIncentive = aq.id(R.id.editTextDateOfIncentive).getText().toString();
		if(DateOfIncentive!=null && DateOfIncentive.length()>0)
		{
			incentiveItem.getIncentive().setIncentive_date(DateOfIncentive);
			flag=true;
		}
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.incentive_date), Toast.LENGTH_SHORT).show();
		}
		return flag;
	}
	private boolean validateBrand()
	{
		boolean flag=false;
		String brandName = aq.id(R.id.buttonBrand).getText().toString();
		if(brandName!=null && brandName.length()>0)
		{
			flag=true;
			incentiveItem.getBrand().setName(brandName);
		}
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.select_brand), Toast.LENGTH_SHORT).show();
		}
		return flag;
	}
	private boolean validateDepot()
	{
		boolean flag=false;
		String depotName = aq.id(R.id.buttonDepot).getText().toString();
		if(depotName!=null && depotName.length()>0 && incentiveItem.getDepot().getId()!=null && incentiveItem.getDepot().getId().length()>0)
		{
			flag=true;
			incentiveItem.getDepot().setTitle(depotName);
		}
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.select_depot), Toast.LENGTH_SHORT).show();
		}
		return flag;
	}
	private boolean validateIncentiveType()
	{
		boolean flag=false;
		String incentiveType = aq.id(R.id.buttonIncentiveType).getText().toString();
		if(incentiveType!=null && incentiveType.length()>0)
		{
			incentiveItem.getIncentive().setIncentive_type(incentiveType);
			flag=true;
		}
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.Incentive_Type), Toast.LENGTH_SHORT).show();
		}
		return flag;
	}
	private boolean validateUnit()
	{
		boolean flag=false;
		String unitName = aq.id(R.id.buttonUnit).getText().toString();
		if(unitName!=null && unitName.length()>0)
		{
			incentiveItem.getIncentive().setUnit(unitName);
			flag=true;
		}
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.select_unit), Toast.LENGTH_SHORT).show();
		}
		return flag;
	}
	private boolean validateQuantity()
	{
		boolean flag=false;
		String quantity = aq.id(R.id.editTextQuantity).getText().toString();
		if(quantity!=null && quantity.length()>0
				&& AppManager.getInstance().isValidNumber(quantity))
		{
			try
			{
				Float.parseFloat(quantity);
				incentiveItem.getIncentive().setQuantity(quantity);
				flag=true;
			}catch(Exception ex){}
		}
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.valid_qty_mess), Toast.LENGTH_SHORT).show();
		}
		return flag;
	}
	
	private void showDatePicker() 
	{
		  DatePickerFragment date = new DatePickerFragment();
		  Calendar calender = Calendar.getInstance();
		  Bundle args = new Bundle();
		  args.putInt("year", calender.get(Calendar.YEAR));
		  args.putInt("month", calender.get(Calendar.MONTH));
		  args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
		  date.setArguments(args);
		  date.setCallBack(ondate);
		  date.show(getActivity().getSupportFragmentManager(), getString(R.string.date_picker));
	}
	OnDateSetListener ondate = new OnDateSetListener() 
	{
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth) 
		{
			String dateStr=String.valueOf(year) + "-" + String.valueOf(monthOfYear+1)+ "-" + String.valueOf(dayOfMonth);
			aq.id(R.id.editTextDateOfIncentive).text(dateStr);
			incentiveItem.getIncentive().setIncentive_date(dateStr);
		}
	};
	private class GetOfflineCustomersAsyncTask extends AsyncTask<Void, Void,String[]>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		boolean flag=false;
		public GetOfflineCustomersAsyncTask(AQuery aq)
		{
			this.aq=aq;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected String[] doInBackground(Void... params) 
		{
			Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		    datasource.open();		    
		    SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
			String token = prefs.getString("token", null);
		    offlineCustomers = datasource.getOfflineCustomeData(token);		    
		    datasource.close();
		    
		    if(offlineCustomers!=null)
			{
		    	Set<String> keys = offlineCustomers.keySet();
			    String[] arr=new String[keys.size()];
			    keys.toArray(arr);
			    return arr;
			}
			return null;
		}
		@Override
		protected void onPostExecute(String[] result) 
		{
			super.onPostExecute(result);
			if(result!=null)
			{
		    	if(result.length>0)
				{
					AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER, result);
					flag=true;
				}
			}
			if(!flag)
			{
				Toast.makeText(getActivity(), getString(R.string.offline_customer_mess), Toast.LENGTH_SHORT).show();
			}
			progressDialog.dismiss();
		}
	}
	private void showEditDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(getString(R.string.confirm));
		alertDialogBuilder
				.setMessage(getString(R.string.incentive_updated))
				.setCancelable(false)
				.setPositiveButton(
						getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								getActivity().getSupportFragmentManager().popBackStack();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
}
