package com.smalution.y3distributionbu1;

import org.json.JSONException;
import org.json.JSONObject;


import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;

import com.google.android.gcm.GCMBaseIntentService;
import com.smalution.y3distributionbu1.R;
import com.smalution.y3distributionbu1.database.Y3QueryDataSource;

public class GCMIntentService extends GCMBaseIntentService {
	private static final String TAG = "GCMIntentService";

    public GCMIntentService() {
        super(AppManager.getInstance().app_sid);
        System.out.println("This is Backend GCMIntentService is working all the time...");
    } 
    
    @Override
    public void onStart(Intent intent, int startId) {
      if (intent != null) {
        super.onStart(intent, startId);
      }
    }
    /**
     * Method called on device registered
     **/
    @Override
    protected void onRegistered(Context context, String registrationId) {
        Log.i(TAG, "Device registered: regId = " + registrationId);
        //displayMessage(context, "Your device registred with GCM");
        //Log.d("NAME", MainActivity.name);
        //ServerUtilities.register(context, MainActivity.name, MainActivity.email, registrationId);
    }

    /**
     * Method called on device un registred
     * */
    @Override
    protected void onUnregistered(Context context, String registrationId) {
        Log.i(TAG, "Device unregistered");
       // displayMessage(context, "ddsfsdfsdf");
        //ServerUtilities.unregister(context, registrationId);
    }

    /**
     * Method called on Receiving a new message
     * */
    @Override
    protected void onMessage(Context context, Intent intent) {
       
        String message = intent.getExtras().getString("message");
        if(message != null){
        	messageoperation(context, message);
        }
    
    }

    /**
     * Method called on receiving a deleted message
     * */
    @Override
    protected void onDeletedMessages(Context context, int total) {
        Log.i(TAG, "Received deleted messages notification");
        String message = "Message deleted"; //getString(R.string.gcm_deleted, total);
        //displayMessage(context, message);
        //notifies user
        //generateNotification(context, message);
    }

    /**
     * Method called on Error
     * */
    @Override
    public void onError(Context context, String errorId) {
        Log.i(TAG, "Received error: " + errorId);
       // displayMessage(context, getString(R.string.gcm_error, errorId));
    }

    @Override
    protected boolean onRecoverableError(Context context, String errorId) {
        // log message
        Log.i(TAG, "Received recoverable error: " + errorId);
        //displayMessage(context, getString(R.string.gcm_recoverable_error,   errorId));
        return super.onRecoverableError(context, errorId);
    }

    /**
     * Issues a notification to inform the user that server has sent a message.
     */
    private static void generateNotification(Context context, String message, String notifyDate) {
        int icon = R.drawable.ic_burundi;
        long when = System.currentTimeMillis();
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Notification notification = new Notification(icon, message, when);
        
        String title = context.getString(R.string.app_name);
       
        Intent notificationIntent = new Intent(context, LoginActivity.class);
        notificationIntent.putExtra("message", message);
        notificationIntent.putExtra("notify", "1");
        //Insert into database
        Y3QueryDataSource dataSource = new Y3QueryDataSource(context);
        dataSource.open();
        long insertId = dataSource.addNotification(message, notifyDate);
        System.out.println("Last notification insertID : "+insertId);
        dataSource.close();
        // set intent so it does not start a new activity
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent intent = PendingIntent.getActivity(context, 0, notificationIntent, 0);
        notification.setLatestEventInfo(context, title, message, intent);
        notification.flags |= Notification.FLAG_AUTO_CANCEL;
       
        // Play default notification sound
        notification.defaults |= Notification.DEFAULT_SOUND;
        
        //notification.sound = Uri.parse("android.resource://" + context.getPackageName() + "your_sound_file_name.mp3");
        
        // Vibrate if vibrate is enabled
        notification.defaults |= Notification.DEFAULT_VIBRATE;
        notificationManager.notify(0, notification);      

    }
    
    private static void messageoperation(Context context, String message){
    	try {
			JSONObject msgJson = new JSONObject(message);
			String msgData = msgJson.isNull("msgData")?"":msgJson.getString("msgData");
			String opr = msgJson.isNull("opr")?"":msgJson.getString("opr");
			
			if(! opr.equals("")){
				if (opr.equalsIgnoreCase("notification")){
					String notifyDate = msgJson.isNull("notify_time")?"":msgJson.getString("notify_time");
					generateNotification(context, msgData, notifyDate);
				} else if(opr.equalsIgnoreCase("changepwd")){
					changePassword(context, msgData);
				} else if(opr.equalsIgnoreCase("dataclean")){
					wipedData(context, msgData);
				} else if(opr.equalsIgnoreCase("blockphone")){
				} else if(opr.equalsIgnoreCase("ring")){
					generateRing(context, msgData);
				}
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
    
    private static void generateRing(Context context, String message) {
    	try {
    	  //Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
    	  // final Ringtone r = RingtoneManager.getRingtone(context, notification);    	   
    	  // r.play();
    	       	 
    	    System.out.println("Ringing....");
    	    final MediaPlayer mp = new MediaPlayer();
    	    Uri uri = RingtoneManager.getDefaultUri( RingtoneManager.TYPE_RINGTONE );
    	    mp.setDataSource(context, uri);
    	    mp.prepare();
    	    mp.getDuration();
    	    mp.start();
    	    //r.sot();
    	   // notification.
    	    final Handler handler = new Handler();
    	    handler.postDelayed(new Runnable() {
    	        @Override
    	        public void run() {
    	            if (mp.isPlaying())
    	            	mp.stop();
    	        	//r.stop();
    	        	System.out.println("Stop Ringing....");
    	        
    	        }
    	    }, 10000);
    	    
    	} catch (Exception e) {
    	    e.printStackTrace();
    	}
    }
    
    private static void wipedData(Context context, String message){
    	DevicePolicyManager mDPM =
    		    (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
    	ComponentName mAdminName = new ComponentName(context, DeviceAdmin.class);
    	if(mDPM.isAdminActive(mAdminName)){
    		mDPM.wipeData(0);
    	}
    	
    }
    
    private static void changePassword(Context context, String passwd){
    	DevicePolicyManager mDPM = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
    	ComponentName mAdminName = new ComponentName(context, DeviceAdmin.class);
    	if(mDPM.isAdminActive(mAdminName) ){
    		mDPM.resetPassword(passwd, 1);
    	}
    }
    
    /*static void displayMessage(Context context, String message) {
        Intent intent = new Intent(DISPLAY_MESSAGE_ACTION);
       // intent.putExtra(EXTRA_MESSAGE, message);
        context.sendBroadcast(intent);
    }*/
    
   
}
