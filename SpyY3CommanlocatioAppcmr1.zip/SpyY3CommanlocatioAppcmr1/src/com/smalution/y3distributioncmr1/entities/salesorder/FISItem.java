package com.smalution.y3distributioncmr1.entities.salesorder;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class FISItem implements Parcelable 
{
	private String id;
	private String unit;
	private String created;
	private String depot_id;
	private String brand_id;
	private String quantity;
	private String order_id;
	private String compaign_id;
	private String sale_date;
	private String cal_qty;
	private String modified;
    public FISItem(){}
	public FISItem(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			unit=jsonObect.isNull("unit")?"":jsonObect.getString("unit");
			created=jsonObect.isNull("created")?"":jsonObect.getString("created");
			depot_id=jsonObect.isNull("depot_id")?"":jsonObect.getString("depot_id");
			brand_id=jsonObect.isNull("brand_id")?"":jsonObect.getString("brand_id");
			quantity=jsonObect.isNull("quantity")?"":jsonObect.getString("quantity");
			order_id=jsonObect.isNull("name")?"":jsonObect.getString("name");
			compaign_id=jsonObect.isNull("compaign_id")?"":jsonObect.getString("compaign_id");
			sale_date=jsonObect.isNull("sale_date")?"":jsonObect.getString("sale_date");
			cal_qty=jsonObect.isNull("cal_qty")?"":jsonObect.getString("cal_qty");
			modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public FISItem(Parcel in)
 	{
		id = in.readString();
		unit = in.readString();
		created = in.readString();
		depot_id = in.readString();
		brand_id = in.readString();
		quantity = in.readString();
		order_id = in.readString();
		compaign_id = in.readString();
		sale_date = in.readString();
		cal_qty = in.readString();
		modified = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(unit);
 		dest.writeString(created);
 		dest.writeString(depot_id);
 		dest.writeString(brand_id);
 		dest.writeString(quantity);
 		dest.writeString(order_id);
 		dest.writeString(compaign_id);
 		dest.writeString(sale_date);
 		dest.writeString(cal_qty);
 		dest.writeString(modified);
 	}
 	public static final Parcelable.Creator<FISItem> CREATOR = new Parcelable.Creator<FISItem>() 
 	{
 		public FISItem createFromParcel(Parcel in) 
 		{
 			return new FISItem(in);
 		}
 	
 		public FISItem[] newArray (int size) 
 		{
 			return new FISItem[size];
 		}
 	};
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getDepot_id() {
		return depot_id;
	}
	public void setDepot_id(String depot_id) {
		this.depot_id = depot_id;
	}
	public String getBrand_id() {
		return brand_id;
	}
	public void setBrand_id(String brand_id) {
		this.brand_id = brand_id;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	public String getCompaign_id() {
		return compaign_id;
	}
	public void setCompaign_id(String compaign_id) {
		this.compaign_id = compaign_id;
	}
	public String getSale_date() {
		return sale_date;
	}
	public void setSale_date(String sale_date) {
		this.sale_date = sale_date;
	}
	public String getCal_qty() {
		return cal_qty;
	}
	public void setCal_qty(String cal_qty) {
		this.cal_qty = cal_qty;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	
}
