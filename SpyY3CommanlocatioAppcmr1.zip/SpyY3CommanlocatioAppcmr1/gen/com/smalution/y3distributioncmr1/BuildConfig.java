/** Automatically generated file. DO NOT MODIFY */
package com.smalution.y3distributioncmr1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}