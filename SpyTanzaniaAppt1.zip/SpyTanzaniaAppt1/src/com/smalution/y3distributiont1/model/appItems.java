package com.smalution.y3distributiont1.model;

import java.io.Serializable;

public class appItems implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String packageName;
	private boolean isChecked;
	private byte[] imgedata;

	private String app_pack;
	private long hour;
	private long minute;
	private long seconds;

	/**
	 * @return hour
	 */
	public long getHour() {
		return hour;
	}

	/**
	 * @param hour
	 */
	public void setHour(long hour) {
		this.hour = hour;
	}

	/**
	 * @return minute
	 */
	public long getMinute() {
		return minute;
	}

	/**
	 * @param minute
	 */
	public void setMinute(long minute) {
		this.minute = minute;
	}

	/**
	 * @return seconds
	 */
	public long getSeconds() {
		return seconds;
	}

	/**
	 * @param seconds
	 */
	public void setSeconds(long seconds) {
		this.seconds = seconds;
	}

	public String getApp_pack() {
		return app_pack;
	}

	public void setApp_pack(String app_pack) {
		this.app_pack = app_pack;
	}

	/**
	 * @return imagedata
	 */
	public byte[] getImgedata() {
		return imgedata;
	}

	/**
	 * @param imgedata
	 */
	public void setImgedata(byte[] imgedata) {
		this.imgedata = imgedata;
	}

	/**
	 * @return packageName
	 */
	public String getPackageName() {
		return packageName;
	}

	/**
	 * @param packageName
	 */
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	/**
	 * @return true if the running app is existed
	 */
	public boolean isCheked() {
		return isChecked;
	}

	public void setChesked(boolean isCheked) {
		this.isChecked = isCheked;
	}
}
