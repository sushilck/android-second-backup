package com.smalution.y3distributiont1.geolocatorservice;

import com.smalution.y3distributiont1.R;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;

import com.androidquery.AQuery;

public class GPSAlertDialogActivity extends Activity 
{
	AQuery aq;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.dialog_layout);
		aq=new AQuery(this);
		aq.id(R.id.ButtonOk).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
	            startActivity(intent);
	            isDialogShouldClose();
	        }
		});
		aq.id(R.id.ButtonCancel).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				finish();
			}
		});
	}
	private void isDialogShouldClose()
	{
		LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		boolean isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
		if(isGPSEnabled)
		{
			finish();
		}
		new Handler().postDelayed(new Runnable() 
		{
			@Override
			public void run() 
			{
				isDialogShouldClose();
			}
		}, 5000);
	}
}
