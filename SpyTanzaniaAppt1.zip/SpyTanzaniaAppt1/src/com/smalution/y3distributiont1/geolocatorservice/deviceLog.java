package com.smalution.y3distributiont1.geolocatorservice;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.IntentService;
import android.app.PendingIntent;
//import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ActivityManager.RunningTaskInfo;
//import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.IBinder;
import android.provider.CallLog;
import android.provider.CallLog.Calls;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Gravity;
import android.widget.Toast;

import com.androidquery.AQuery;
import com.smalution.y3distributiont1.AppManager;
import com.smalution.y3distributiont1.database.MySQLiteHelper;
import com.smalution.y3distributiont1.model.appItems;
import com.smalution.y3distributiont1.utils.AppConstant;


public class deviceLog extends IntentService {
	AQuery aq;
	private static SQLiteDatabase database;
 	private static MySQLiteHelper dbHelper;
 	
	public deviceLog() {
		super("deviceLog");
		//System.out.println("This is Backend Services for deviceLog is working all the time...");
	}

	AppManager appManager;
	private ActivityManager activityManager;
	private appItems appItems;
	ApplicationInfo applicationInfo = null;
	private Runnable mRunnable;
	private long appStartTime;
	long data1 = 0, id, maxID;
	double seconds;
	private ArrayList<appItems> trackAppList;	
	private ArrayList<appItems> otherAppList;
	ArrayList<String> phone_number, list1, list2, list3, list4, list5, titleArr;
	private String previousApplicationName = null;
	String androidId, data, dir = null, message, currentActivityName, callType, time,  actName, Css, title, phNumber, PREFS = "myPrefs", lastDate=null, dateString, isCallNew, dateString1, dateString11;
	
	SharedPreferences mPrefs;
	SharedPreferences.Editor login_editor;
	int callDayTime, dur;
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public void onCreate(){
		super.onCreate();
		//System.out.println("This is DeviceLog (within onCreate) Backend Services is working all the time...");
		activityManager = (ActivityManager) this.getSystemService(Context.ACTIVITY_SERVICE);
		trackAppList = new ArrayList<appItems>();
		otherAppList = new ArrayList<appItems>();
		getInstalledAppsData();
		
		titleArr = new ArrayList<String>();
	}
	
	
/**
 * This method will start whenever start service method called and register
 * the sensor manager receiver
 */

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {

		runBackground();
		return START_STICKY;
	}
	
/**
  * running continuously in the background
 */
	private void runBackground() {
		
		final Handler handler = new Handler();
		mRunnable = new Runnable() {
			public void run() {
				trackApplication();
				new ReadCallLogs().execute();
				
				new SendLogsData().execute();
				handler.postDelayed(mRunnable, 10000);
			}
		};
		handler.postDelayed(mRunnable, 10000);
	}
	
	public void onDestroy(){
		super.onDestroy();
	}
	
	public void onRebind(Intent intent){
		super.onRebind(intent);
	}

/**
 * getting all installed applications from device
 */
	private void getInstalledAppsData() {
		System.out.print("Calling getInstalledAppData function");
		List<PackageInfo> list = getPackageManager().getInstalledPackages(0);
		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				PackageInfo pack = list.get(i);
				if (pack.versionCode != 0) {
					if (!pack.applicationInfo.packageName.equals("com.smalution.lockscreen")) {
						
						appItems = new appItems();
						appItems.setChesked(false);
						// add installed applications title
						appItems.setPackageName(pack.applicationInfo.loadLabel(getPackageManager()).toString());
						Css = pack.applicationInfo.loadLabel(getPackageManager()).toString();
						//appItems.setImgedata(getImageByBytes(pack.applicationInfo.loadIcon(getPackageManager())));
						// add installed applications package name
						appItems.setApp_pack(pack.applicationInfo.packageName);
						otherAppList.add(appItems);
						
					}
				}
			}
		}
	}
/**
 * getting running application information
 * 
 * based on application getting all the details like packagename and
 * application icons
 */

	private void trackApplication() {

				
		List<ActivityManager.RunningTaskInfo> taskInfo = activityManager.getRunningTasks(1);
		
		// get current application package name
		String currentRunningActivityName = taskInfo.get(0).topActivity.getPackageName();
		
		//Need to check
		if (!(currentRunningActivityName.equals("com.android.launcher") || currentRunningActivityName.contains("launcher")) ) {
			appItems = new appItems();
			if (trackAppList.size() == 0) {
				trackAppList.add(getValidPackage(currentRunningActivityName));
			} else {
				if (!isExisted(currentRunningActivityName)) {
					appItems.setPackageName(currentRunningActivityName);
					trackAppList.add(getValidPackage(currentRunningActivityName));
				}
			}
		}
		

		//System.out.println("Current Running App: " +currentRunningActivityName);
		calculateTime(currentRunningActivityName);
		
	}
	
	 
	 
/**
 * calculate other applications running time
 * 
 * @param appName
 */
	private void calculateTime(String appName) {

		/*
		 * checks the any app is currently running or not if any application is
		 * running then start the time
		 */
		
		if (previousApplicationName == null && !appName.contains("launcher") ) {
			previousApplicationName = appName;
			
			System.currentTimeMillis();
			appStartTime = System.currentTimeMillis();
			Timestamp original = new Timestamp(appStartTime);
			dateString = original.toString();
			//System.out.println("App Start Time: " + appStartTime);
			//System.out.println("App Start dateString: " + dateString);
			
		} 
		
		if ( appName.equals(previousApplicationName) && !appName.contains("launcher") ){
			
		}
		
		if (previousApplicationName != null) {
			if ( !appName.equals(previousApplicationName) || appName.contains("launcher") ){
				
				appItems appItems = getValidPackage(previousApplicationName);
				//long time = appItems.getSeconds() + (System.currentTimeMillis() - appStartTime);
				long appTimeDuration = appItems.getSeconds() + (System.currentTimeMillis() - appStartTime);
				Timestamp original = new Timestamp(appStartTime);
				dateString = original.toString();
				int valAsInt = (int) appTimeDuration;
				seconds = valAsInt / 1000.0;
				
				
				ActivityManager activityManager = (ActivityManager) getApplicationContext()
						.getSystemService(Context.ACTIVITY_SERVICE);
				List<RunningTaskInfo> runningTaskInfo = activityManager
						.getRunningTasks(Integer.MAX_VALUE);
				for (int ii = 0; ii < runningTaskInfo.size(); ii++) {
					String taskName = runningTaskInfo.get(1).baseActivity
							.toShortString();
					int lastIndex = taskName.indexOf("/");
					if (-1 != lastIndex) {
						taskName = taskName.substring(1, lastIndex);
					}
					PackageManager packageManager = getPackageManager();
					try {
						applicationInfo = packageManager.getApplicationInfo(taskName, 0);
					} catch (final NameNotFoundException e) {
					}
					title = (String) ((applicationInfo != null) ? packageManager.getApplicationLabel(applicationInfo) : null);
					
					if (title != null ){
						titleArr.add(0, title);
						
						//System.out.println("AppName:"+title+ " Duration :  " + seconds);
						if(titleArr.size() > 0){	
						    if(titleArr.get(0) != null && seconds >= 1){
						    	new UpdateAppLogs().execute();
						    }else{						    	
						    	Log.d("App Title", "Application Title were not found");
						    }
						}
					}
				}
				
			}
		}
		
		
	}
	
	private class UpdateAppLogs extends AsyncTask<Void, Void, Void> {
		GPSTracker gpsTracker = new GPSTracker(deviceLog.this);
		protected Void doInBackground(Void... params) {
			mPrefs = deviceLog.this.getSharedPreferences("BGGeoCollector", MODE_PRIVATE);
			String startTime = dateString;
			double duration = seconds;
			
			if ( !(title.equals("Launcher") || title.equals("TouchWiz Home") ) && !(title.equals("Dialler") || title.equals("Contacts") ) && duration >= 1 ){
				//Insert logs into database
				dbHelper = new MySQLiteHelper(deviceLog.this);
				database = dbHelper.getWritableDatabase();
		
				String activityName = title; // titleArr.get(0);
				String message = "User used: " + activityName;
			
				Cursor cursor = database.rawQuery("SELECT * FROM  "+MySQLiteHelper.DEVICELOGS_TABLE_NAME+" " +
						"WHERE "+MySQLiteHelper.ACTIVITY+ "= ?"+
						" AND " + MySQLiteHelper.START_TIME+"= ?"+
						" AND " + MySQLiteHelper.DURATION+ " = ?"				
						 , new String[] {activityName, startTime, Double.toString(duration)});
				
				if(cursor.getCount() > 0 ){
					//System.out.println("Already added (Non call log)");
				}else{
					
					ContentValues values = new ContentValues();
					
					values.put(MySQLiteHelper.START_TIME, dateString);
					values.put(MySQLiteHelper.END_TIME, dateString);
					values.put(MySQLiteHelper.CURR_DATE, AppConstant.getCurrentDate() );
					values.put(MySQLiteHelper.DURATION,  Double.toString(duration));
					values.put(MySQLiteHelper.USERID, mPrefs.getString("user_id", ""));
					values.put(MySQLiteHelper.ACTIVITY, activityName);
					values.put(MySQLiteHelper.MESSAGE, message );
					values.put(MySQLiteHelper.LATITUDE, gpsTracker.getLatitude() );
					values.put(MySQLiteHelper.LONGITUDE, gpsTracker.getLongitude() );
					values.put(MySQLiteHelper.CREATED, AppConstant.getCurrentDateAndTime());
					values.put(MySQLiteHelper.LOG_STATUS, "0");
					long insertId = database.insert(MySQLiteHelper.DEVICELOGS_TABLE_NAME, null, values);
					Log.d("Last Insert ID", "(APPS):= "+insertId);
					
				}
				database.close();

		
			}
		System.currentTimeMillis();
			appStartTime = System.currentTimeMillis();
			
			previousApplicationName = null;
			
			titleArr.clear();
		//Log.d("hello#####", "" + list5.size());
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			titleArr.clear();
			appStartTime = System.currentTimeMillis();
			
			previousApplicationName = null;
			
		}

	}
	
		
/**
 * @param appPackage
 * @return bean contains packgename,application name
 */
	private appItems getValidPackage(String appPackage) {

		for (appItems appItems : otherAppList) {

			if (appItems.getApp_pack().equals(appPackage)) {
				return appItems;
			}
		}
		return null;
	}
	

	
/**
 * @param package_name
 * @return true if already the app is added other wise return false
 */
	private boolean isExisted(String package_name) {
		for (appItems appItems : trackAppList) {
			if (appItems.getApp_pack().equals(package_name)) {
				return true;
			}
		}
		return false;
	}
	
	
	private class ReadCallLogs extends AsyncTask<Void, Void, Void> {
		
		GPSTracker gpsTracker = new GPSTracker(deviceLog.this);

		/*
		 * Function name: onPreExecute Parameters: Void params Return: void
		 */
		protected void onPreExecute() {

			// TODO Auto-generated method stub
			super.onPreExecute();

		}

		/*
		 * Function name: doInBackground Parameters: Void params Return: void
		 */
		protected Void doInBackground(Void... params) {
			androidId = Secure.getString(getApplicationContext().getContentResolver(), Secure.ANDROID_ID);
			
			List<ActivityManager.RunningTaskInfo> taskInfo = activityManager.getRunningTasks(1);
			
			//ComponentName componentInfo = taskInfo.get(0).topActivity;
			currentActivityName = taskInfo.get(0).topActivity.getPackageName();
			
			//List<RunningAppProcessInfo> procInfos = activityManager.getRunningAppProcesses();
			
			if (currentActivityName.equals("com.android.dialer") || currentActivityName.contains("contacts")) {
				String hello1[] = currentActivityName.split("\\.");
				actName = hello1[2];

				readCallLogs(gpsTracker);

			}
			
			return null;

		}

		/*
		 * Function name: onPostExecute Parameters: Void result Return: void
		 */
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			// db1.execSQL("delete from CallLogs");

		}
	}
	 
	
	
	
	
	public void readCallLogs(GPSTracker gpsTracker) {// TODO Auto-generated method stub
		androidId = Secure.getString(this.getContentResolver(), Secure.ANDROID_ID);
		
		
		StringBuffer sb = new StringBuffer();
		String strOrder = android.provider.CallLog.Calls.DATE + " DESC";
		ContentResolver cR = getContentResolver();
		Cursor managedCursor = cR.query(CallLog.Calls.CONTENT_URI, null, null, null, strOrder);
		
		if (managedCursor.moveToNext()) {
			//System.out.println("Lat long in call logs: " + gpsTracker.getLatitude()+"= Long: "+gpsTracker.getLongitude());
			int number = managedCursor.getColumnIndex(CallLog.Calls.NUMBER);
			
			SharedPreferences myPrefs = deviceLog.this.getSharedPreferences("BGGeoCollector", MODE_PRIVATE);
			
			
			int type = managedCursor.getColumnIndex(CallLog.Calls.TYPE);
			//int date = managedCursor.getColumnIndex(CallLog.Calls.DATE);
			int duration = managedCursor.getColumnIndex(CallLog.Calls.DURATION);
			sb.append("Call Log :");
			// if (managedCursor != null && managedCursor.getCount() > 0) {
			while (managedCursor.moveToNext() == true) {
				phNumber = managedCursor.getString(number);
				//phone_number.add(phNumber);
				id = managedCursor.getLong(managedCursor.getColumnIndexOrThrow(Calls._ID));
				
				
				maxID = managedCursor.getCount();
				
				//Log.e("queryString@@", "" + maxID);
				
				mPrefs = deviceLog.this.getSharedPreferences(PREFS, MODE_PRIVATE);
				login_editor = mPrefs.edit();
				login_editor.putString("dateString1", dateString1);
				login_editor.commit();
				data = mPrefs.getString("dateString1", dateString1);
				//Log.e("editor@@@", "" + data);
				
				lastDate = dateString1;
				// Log.e("editor####", ""+data1);
				
				callType = managedCursor.getString(type);
				callDayTime = managedCursor.getColumnIndex(Calls.DATE);
				long seconds = managedCursor.getLong(callDayTime);
				Timestamp original = new Timestamp(seconds);
				
				SimpleDateFormat simYYYYMMDD = new SimpleDateFormat("yyyy-MM-dd");
				String callDate = simYYYYMMDD.format(original);
				
				dateString = original.toString();
				dur = managedCursor.getInt(duration);
				
				Calendar cal = Calendar.getInstance();
				cal.setTimeInMillis(original.getTime());
				cal.add(Calendar.SECOND, dur);
				Timestamp later = new Timestamp(cal.getTime().getTime());
				
				
				dateString1 = later.toString();
				int dircode = Integer.parseInt(callType);
				
				String currDate = AppConstant.getCurrentDate();
				
				
			 if (currDate.equals(callDate) ){
					
					
				switch (dircode) {
					case CallLog.Calls.OUTGOING_TYPE:
						dir = "Dialled call to ";
						break;
					case CallLog.Calls.INCOMING_TYPE:
						dir = "Received call from ";
						break;
					case CallLog.Calls.MISSED_TYPE:
						dir = "Have got miss call from ";
						break;
				}
					
				
				//Insert logs into database
				dbHelper = new MySQLiteHelper(deviceLog.this);
				database = dbHelper.getWritableDatabase();

				String activity =  "Dialer";
				String startTime = dateString;
				String endTime = dateString1;
				String message = dir + phNumber;
				double duration2 = dur;
				//System.out.println(message);
				String qryStr = "SELECT * FROM  "+MySQLiteHelper.DEVICELOGS_TABLE_NAME+" " +
						"WHERE "+MySQLiteHelper.ACTIVITY+ "=? "+
						" AND " + MySQLiteHelper.START_TIME+ " = ?"+
						" AND " + MySQLiteHelper.END_TIME+ " = ?"+
						" AND " + MySQLiteHelper.DURATION+ " = ?";
				//System.out.println(qryStr);
				Cursor cursor = database.rawQuery(qryStr , new String[]{activity, startTime, endTime, Double.toString(duration2) } );
					
				if(cursor.getCount() > 0  ){
					//System.out.println("Already added (Call Log) ");
				}else{
				
					ContentValues values = new ContentValues();
					
					values.put(MySQLiteHelper.START_TIME, dateString);
					values.put(MySQLiteHelper.END_TIME, dateString1);
					values.put(MySQLiteHelper.CURR_DATE, AppConstant.getCurrentDate() );
					values.put(MySQLiteHelper.DURATION,  Double.toString(duration2));
					values.put(MySQLiteHelper.ACTIVITY, activity);
					values.put(MySQLiteHelper.MESSAGE, message );
					values.put(MySQLiteHelper.LATITUDE, gpsTracker.getLatitude() );
					values.put(MySQLiteHelper.LONGITUDE, gpsTracker.getLongitude() );
					values.put(MySQLiteHelper.USERID, myPrefs.getString("user_id", ""));
					values.put(MySQLiteHelper.CREATED, AppConstant.getCurrentDateAndTime());
					values.put(MySQLiteHelper.LOG_STATUS, "0");
					database.insert(MySQLiteHelper.DEVICELOGS_TABLE_NAME, null, values);
					//System.out.print("Last Insert ID (Call Log) := "+insertId);
				}
			
				database.close();
			}
				
				}
			}

			managedCursor.close();
		}

	@SuppressWarnings("static-access")
	@Override
	protected void onHandleIntent(Intent intent) {
		// TODO Auto-generated method stub
		
		appManager = AppManager.getInstance();
		long currentTime = System.currentTimeMillis();
		SharedPreferences prefs = getSharedPreferences("BGDeviceLog", MODE_PRIVATE);
		Editor edt = prefs.edit();
		edt.putLong("LAST_LOG_TIME", currentTime);
		edt.commit();
		
		boolean isDlRunService = prefs.getBoolean("isDlRunService", false);
		long dlTimeSlice = prefs.getLong("timeSlice", 0l);
		
		if(isDlRunService)
		{
			if(appManager.isOnline(getApplicationContext()))
			{
				try
				{
				
					new SendLogsData().execute();
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
				
			}
		
		
			Calendar cal = Calendar.getInstance();
	        cal.add(Calendar.SECOND, 10);
	        Intent dlServiceIntent = new Intent(this, deviceLog.class);
	        PendingIntent pintent = PendingIntent.getService(this, 0, dlServiceIntent, 0);
	        AlarmManager alarm = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
	        //every 2 min
	        alarm.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), dlTimeSlice, pintent);
		}
		else
		{
			//Log.d("MTK", "isRunService: "+isDlRunService);
		}
		
		Calendar cal = Calendar.getInstance();
        cal.add(Calendar.SECOND, 10);
        Intent dlServiceIntent = new Intent(this, deviceLog.class);
        PendingIntent pintent = PendingIntent.getService(this, 0, dlServiceIntent, 0);
        AlarmManager alarm = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        //every 2 min
        alarm.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), dlTimeSlice, pintent);
	}
	
	private class SendLogsData extends AsyncTask<Void, Void, Void> {
		
		protected Void doInBackground(Void... params) {
	
	//public void sendLogsData() {
		
		//Insert logs into database
		dbHelper = new MySQLiteHelper(deviceLog.this);
		database = dbHelper.getWritableDatabase();
		
		
		SharedPreferences myPrefs = deviceLog.this.getSharedPreferences("BGGeoCollector", MODE_PRIVATE);
		long currentTime = System.currentTimeMillis();
		
		String token = myPrefs.getString("token", null);
		long lastLogsRequest = myPrefs.getLong("LAST_LOG_REQUEST", currentTime);
		Boolean isLogPosted  = myPrefs.getBoolean("isLogPosted", false );
		long reqTimeDiff = 5*60*1000; //Post data Request time difference 
		boolean isData = false;
				
		if( (currentTime - lastLogsRequest) >= reqTimeDiff ||  isLogPosted == false){
		
			//System.out.println("Time Differnce LIMIT: "+ reqTimeDiff +" == Current Time :"+ currentTime + "== Last log Time :"+ lastLogsRequest );
			String qryStr = "SELECT * FROM  "+MySQLiteHelper.DEVICELOGS_TABLE_NAME+" " +
					"WHERE "+MySQLiteHelper.LOG_STATUS+ "=? ORDER BY "+MySQLiteHelper.ID+" ASC LIMIT 20"	;
			System.out.println(qryStr);
			
			Cursor cursor = database.rawQuery(qryStr , new String[]{"0"} );
			System.out.println("Total Rows : " +  cursor.getCount() );
			cursor.moveToFirst();
			
			JSONArray postjsonArr = new JSONArray();
			
			JSONObject postJson = new JSONObject();
			
			while (!cursor.isAfterLast()) {	
				
				JSONObject object = new JSONObject();
				try {
					
					object.put("_id", cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ID)) );
					object.put("user_id", cursor.getString(cursor.getColumnIndex(MySQLiteHelper.USERID)) );
					object.put("start_time", cursor.getString(cursor.getColumnIndex(MySQLiteHelper.START_TIME)) );
					//object.put("end_time", cursor.getString(cursor.getColumnIndex(MySQLiteHelper.END_TIME)));
					object.put("duration", cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DURATION)) );
					object.put("activity", cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ACTIVITY)) );
					object.put("message", cursor.getString(cursor.getColumnIndex(MySQLiteHelper.MESSAGE)) );
					object.put("latitude", cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LATITUDE)) );
					object.put("longitude", cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LONGITUDE)) );
					object.put("created", cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CREATED)) );
				} catch (JSONException e1) {
					// // TODO Auto-generated catch block
					e1.printStackTrace();
				}
				postjsonArr.put(object);
				
				
				
				/*
				try{
					ContentValues values2 = new ContentValues();
					values2.put(MySQLiteHelper.LOG_STATUS, "1");
					String logId = cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ID));
					
					database.update(MySQLiteHelper.DEVICELOGS_TABLE_NAME, values2, MySQLiteHelper.ID + "=" + logId, null);					
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}*/
				
				cursor.moveToNext();
				isData = true;
			}
			
			TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
			String deviceId = telephonyManager.getDeviceId();
			
			try {
				postJson.putOpt("token", token);
				postJson.putOpt("deviceId", deviceId);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				postJson.putOpt("logData", postjsonArr);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//Log.d("Posted json", " : " + postJson.toString() );
			// Create a new HttpClient and Post Header
			if(isData && AppManager.isOnline(deviceLog.this)){			
				try
				{
					HttpClient httpclient = new DefaultHttpClient();
					HttpContext httpContext = new BasicHttpContext();
					HttpPost httppost = new HttpPost(AppManager.getInstance().URL_DEVICELOG_ADD);
					httppost.setHeader("jsonString", postJson.toString());
					httppost.getParams().setParameter("jsonString", postJson);
					
					StringEntity se = new StringEntity("jsonString="+ postJson.toString());
					httppost.addHeader("content-type",	"application/x-www-form-urlencoded");
					httppost.setEntity(se);
					//System.out.println("Post JSON data String: " + postJson.toString());
					
					HttpResponse response = httpclient.execute(httppost,httpContext);
					
					if (response.getStatusLine().getStatusCode() == 200) {
						HttpEntity entity = response.getEntity();
						String json = EntityUtils.toString(entity);
						try {
							JSONObject responseData = new JSONObject(json);
							String errorCode = responseData.isNull("error") ? "0" : responseData.getString("error");
							if (errorCode.equals("0")){
								String ids = responseData.isNull("deviceLogsIds") ? null : responseData.getString("deviceLogsIds");
								if (ids != null){
									System.out.println("Logs IDS: " + ids);
									database.delete(MySQLiteHelper.DEVICELOGS_TABLE_NAME, MySQLiteHelper.ID + " IN (" + ids + ")" +
											" AND "+MySQLiteHelper.ACTIVITY+ "!='Dialer'", null);
									
									ContentValues values2 = new ContentValues();
									values2.put(MySQLiteHelper.LOG_STATUS, "1");
									database.update(MySQLiteHelper.DEVICELOGS_TABLE_NAME, values2, MySQLiteHelper.ID + " IN (" + ids + ") AND "+MySQLiteHelper.ACTIVITY+ " = 'Dialer'", null);
									//System.out.println("Response:: " + json);
								}
							}
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}	
						
						database.delete(MySQLiteHelper.DEVICELOGS_TABLE_NAME, MySQLiteHelper.CURR_DATE + " = '" + AppConstant.getBackDate(1) +"'" +
						" AND "+MySQLiteHelper.LOG_STATUS+ " = 1 AND "+MySQLiteHelper.ACTIVITY+ " ='Dialer'", null);
					}
				
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
				} catch (IOException e) {
					// // TODO Auto-generated catch block
				}
			}
			
				//Delete last day logs
			 
				//database.delete(MySQLiteHelper.DEVICELOGS_TABLE_NAME, MySQLiteHelper.CURR_DATE + " = '" + AppConstant.getBackDate(1) +"'" +
						//" AND "+MySQLiteHelper.LOG_STATUS+ " = 1", null);
				database.close();
				
				
				Editor edt = myPrefs.edit();
				edt.putLong("LAST_LOG_REQUEST", currentTime);
				edt.putBoolean("isLogPosted", true);
				edt.commit();
			}
			return null;
		}
		@Override
		protected void onPostExecute(Void result) {
			
		}
	}
	
}
