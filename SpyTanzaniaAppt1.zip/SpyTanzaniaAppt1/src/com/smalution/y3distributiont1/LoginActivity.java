package com.smalution.y3distributiont1;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import com.androidquery.AQuery;
import com.google.android.gcm.GCMRegistrar;
import com.smalution.y3distributiont1.R;
import com.smalution.y3distributiont1.geolocatorservice.GPSTrackerService;
import com.smalution.y3distributiont1.geolocatorservice.deviceLog;
import com.smalution.y3distributiont1.utils.AppConstant;

public class LoginActivity extends Activity 
{
	AQuery aq;
	private static final int REQUEST_CODE = 0;
	private DevicePolicyManager mDPM;
	private ComponentName mAdminName;
	public String regId = "";
	public String notify="0";
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
				
		setContentView(R.layout.login_activity);
		aq=new AQuery(this);
		
		long currentTime = System.currentTimeMillis();
		SharedPreferences prefs=getSharedPreferences("BGGeoCollector", MODE_PRIVATE);
		long previousServeTime = prefs.getLong("LAST_SERVE_TIME", 0l);
		long timeSlice = prefs.getLong("timeSlice", 0l);
		
		Bundle extras = getIntent().getExtras();
	    if(extras != null){
	    	notify = extras.getString("notify");
	    }
		
		GCMRegistrar.checkDevice(this);
		GCMRegistrar.checkManifest(this);
		// Get GCM registration id
		regId = GCMRegistrar.getRegistrationId(this);
		//System.out.println( "Already regId : " + regId);
		// Check if regid already presents
		if (regId.equals("")) {
			// Registration is not present, register now with GCM			
			GCMRegistrar.register(this, AppManager.getInstance().app_sid);
			regId = GCMRegistrar.getRegistrationId(this);
		}
		
		//Device Admin disable force to stop
		try 
        {
        	// Initiate DevicePolicyManager.
        	mDPM = (DevicePolicyManager)getSystemService(Context.DEVICE_POLICY_SERVICE);
        	// Set DeviceAdminDemo Receiver for active the component with different option
        	mAdminName = new ComponentName(this, DeviceAdmin.class);
        	
        	if (!mDPM.isAdminActive(mAdminName)) {
        		// try to become active
        		Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        		intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, mAdminName);
        		intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, R.string.must_click);
        		startActivityForResult(intent, REQUEST_CODE);
        	}
        	else 
        	{
        		// Already is a device administrator, can do security operations now.
        		mDPM.lockNow();
        	}
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
		if(AppConstant.isLogin)//check for 3 min
		{
			showUserDetail();
			//showUserLogin();
    	}
		else
		{
			// some change in login and showUserLogin.
			//showUserDetail();
			showUserLogin();
		}
		Intent intent1 = new Intent(LoginActivity.this, GPSTrackerService.class);
		startService(intent1);
		Intent intent2 = new Intent(LoginActivity.this, deviceLog.class);
		startService(intent2);
	}

	private void showUserLogin() 
	{
		aq.id(R.id.loginParent).visible();		
		aq.id(R.id.userDetailParent).gone();
		aq.id(R.id.Button_submit).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(AppManager.getInstance().isOnline(LoginActivity.this))
				{
					InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
					imm.hideSoftInputFromWindow(aq.id(R.id.EditText_password).getEditText().getWindowToken(), 0);
					submit();
				}
				else
				{
					
					
					SharedPreferences prefs=getSharedPreferences("BGGeoCollector", MODE_PRIVATE);
					//System.out.println(prefs.getString(AppConstant.USERNAME, null));
		    		if(isValidEntry()){
		    		
		    		if(aq.id(R.id.EditText_username).getText().toString().equals(prefs.getString(AppConstant.USERNAME, null)) && aq.id(R.id.EditText_password).getText().toString().equals(prefs.getString(AppConstant.PASSWORD, null))) 
		    		{
		    			finish();
		    			Intent intent =new Intent(LoginActivity.this, MainActivity.class);
		    			intent.putExtra("notify", notify);
		    			startActivity(intent);
		    		}
		    		else{
		    			Toast toast = Toast.makeText(LoginActivity.this, R.string.invalid_username_pass, Toast.LENGTH_SHORT);
						toast.setGravity(Gravity.CENTER, 0, 0);
						toast.show();
		    		}
		    		
		    		}
		    		else{
		    			Toast toast = Toast.makeText(LoginActivity.this, getString(R.string.missing_credential_toast), Toast.LENGTH_SHORT);
		    			toast.setGravity(Gravity.CENTER, 0, 0);
		    			toast.show();
		    		}		    		
		    	
				}
			}
		});
		aq.id(R.id.EditText_password).getEditText().setOnEditorActionListener(new OnEditorActionListener()
		{  
		    @Override 
		    public boolean onEditorAction(TextView arg0, int arg1, KeyEvent arg2) 
		    { 
		        if(arg1 == EditorInfo.IME_ACTION_GO)  
		        { 
		        	submit();
		        }
		        return false; 
		    }
		}); 
	}
	private void showUserDetail() 
	{
		new AppSettingsDataAsyncTask(aq).execute();
	}
	private void submit() 
	{
		if(isValidEntry())
		{
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("username", aq.id(R.id.EditText_username).getText());
			params.put("password", aq.id(R.id.EditText_password).getText());//CREATED_DATE
			TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
			String deviceId = telephonyManager.getDeviceId();
			AppConstant.ANDROIDDEVICEID=deviceId;
			//params.put("imei", "'"+deviceId+"'");
			params.put("imei", deviceId);
			// Get GCM registration id
			regId = GCMRegistrar.getRegistrationId(this);
			System.out.println( "Already regId : " + regId);
			// Check if regid already presents
			if (regId.equals("")) {
				// Registration is not present, register now with GCM			
				GCMRegistrar.register(this, AppManager.getInstance().app_sid);
				regId = GCMRegistrar.getRegistrationId(this);
			}
			params.put("regId", regId);
			System.out.println( "regId : " + regId);
			//{password=123456, username=vijay, imei=354905050190398}
			new LoginAsyncTask(aq, params).execute();
		}
		else
		{
			Toast toast = Toast.makeText(LoginActivity.this, getString(R.string.missing_credential_toast), Toast.LENGTH_SHORT);
			toast.setGravity(Gravity.CENTER, 0, 0);
			toast.show();
		}
	}
	private boolean isValidEntry()
	{
		return aq.id(R.id.EditText_username).getText().length()>0 && aq.id(R.id.EditText_password).getText().length()>0;
	}
	private class LoginAsyncTask extends AsyncTask<Void, Void, String>
	{
		AQuery aql;
		Map<String, Object> loginParams;
		public LoginAsyncTask(AQuery aql, Map<String, Object> loginParams)
		{
			this.aql=aql;
			this.loginParams=loginParams;
		}
		ProgressDialog progressDialog;
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(LoginActivity.this);
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		String token="";
		@Override
		protected String doInBackground(Void... params) 
		{
			//AppManager.getInstance().sendNotification(aql, loginParams);
			//{"message":"Please contact administrator to authorize your device","baseUrl":"http:\/\/projects.smalution.net\/y3dev\/","timeSlice":"600000","error":3}
			try
			{
				JSONObject json = AppManager.getInstance().loginUser(aql, loginParams);
				if(json!=null)
				{
					if(json.getInt("error")==0)
					{
						SharedPreferences prefs=getSharedPreferences("BGGeoCollector", MODE_PRIVATE);
			    		Editor edt = prefs.edit();
			    		edt.putString("user_id", json.getJSONObject("data").getJSONObject("User").getString("id"));
			    		edt.putString("region_id", json.getJSONObject("data").getJSONObject("User").getString("region_id"));
			    		edt.putString("depot_id", json.getJSONObject("data").getJSONObject("User").getString("depot_id"));
			    		edt.putInt("grade", json.getJSONObject("data").getJSONObject("Role").getInt("grade"));
			    		
			    		String allow_uninstall_app = json.getJSONObject("data").getJSONObject("User").isNull("allow_uninstall_app") ? "0" : json.getJSONObject("data").getJSONObject("User").getString("allow_uninstall_app");			    		
			    		edt.putString("allow_uninstall_app", allow_uninstall_app);
			    		
			    		token=json.getString("token");
			    		edt.putString("token", token);
			    		long timeSlice=json.getLong("timeSlice");
			    		edt.putLong("timeSlice", timeSlice);
			    		edt.putBoolean("isRunService", true);
			    		edt.putString("user_object", json.getJSONObject("data").getJSONObject("User").toString());
			    		edt.putString(AppConstant.USERNAME,  aq.id(R.id.EditText_username).getText().toString());
			    		edt.putString(AppConstant.PASSWORD, aq.id(R.id.EditText_password).getText().toString());
			    		edt.commit();
						return "OK";
					}
					else
					{
						return json.getString("message"); 
					}
				}
				return null;
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			return getString(R.string.network_problem_toast);
		}
		@Override
		protected void onPostExecute(String result) 
		{
			super.onPostExecute(result);
			if(result!=null)
			{
				if(result.equals("OK"))
				{
					//login success
					Intent intent1 = new Intent(LoginActivity.this, GPSTrackerService.class);
					startService(intent1);					
					showUserDetail();
					
					Intent intent2 = new Intent(LoginActivity.this, deviceLog.class);
					startService(intent2);
			        
			        //finish();
				}
				else
				{
					Toast toast = Toast.makeText(aql.getContext(), result, Toast.LENGTH_SHORT);
					toast.setGravity(Gravity.CENTER, 0, 0);
					toast.show();
				}
		    }
			progressDialog.dismiss();
		}
	}
	private class AppSettingsDataAsyncTask extends AsyncTask<Void, Void, Boolean>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		public AppSettingsDataAsyncTask(AQuery aq)
		{
			this.aq=aq;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(LoginActivity.this);
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected Boolean doInBackground(Void... params) 
		{
			return AppManager.getInstance().getAppSettingData(aq);
		}
		@Override
		protected void onPostExecute(Boolean result) 
		{
			super.onPostExecute(result);
			progressDialog.dismiss();
			super.onPostExecute(result);
			progressDialog.dismiss();
			finish();
			Intent intent =new Intent(LoginActivity.this, MainActivity.class);
			intent.putExtra("notify", notify);
			startActivity(intent);
			/*else
			{
				Toast.makeText(aq.getContext(), "App settings not loaded, please check you internet connection.", Toast.LENGTH_LONG).show();
			}*/
		}
	}
	
}
