package com.smalution.y3distributiont1.entities;

import android.os.Parcel;
import android.os.Parcelable;

public class Visit implements Parcelable
{
	private String user;
	private String customer;
	private String depot;
	private String lga;
	private String comment;
	private String visitingTime;
	
	public Visit(){}
	
	public Visit(Parcel in)
 	{
		user = in.readString();
		customer = in.readString();
		depot = in.readString();
		lga = in.readString();
		comment = in.readString();
		visitingTime = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(user);
 		dest.writeString(customer);
 		dest.writeString(depot);
 		dest.writeString(lga);
 		dest.writeString(comment);
 		dest.writeString(visitingTime);
	}
 	public static final Parcelable.Creator<Visit> CREATOR = new Parcelable.Creator<Visit>() 
 	{
 		public Visit createFromParcel(Parcel in) 
 		{
 			return new Visit(in);
 		}
 	
 		public Visit[] newArray (int size) 
 		{
 			return new Visit[size];
 		}
 	};
}
