package com.smalution.y3distributiont1.entities.settings;

import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONObject;

public class CustomerType 
{

	ArrayList<SelectionButtonItem> customerType;
	String[] name; 
	
	public CustomerType(){}
	public CustomerType(JSONObject jsonObject)
	{
		try
		{
			//customerType=new HashMap<String, String>();
			@SuppressWarnings("rawtypes")
			Iterator itr = jsonObject.keys();
			name=new String[jsonObject.length()];
			customerType=new ArrayList<SelectionButtonItem>();
			int i=0;
			while(itr.hasNext())
			{
				String key = (String)itr.next();
				String value = (String) jsonObject.getString(key);				
				SelectionButtonItem itm=new SelectionButtonItem(key, "", value);				
				customerType.add(itm);
				name[i]=value;
				i++;
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getCustomerTypeById(String id)
	{
		for(SelectionButtonItem itm:customerType)
		{
			if(itm.getId().equals(id))
				return itm.getTitle();
		}
		return null;
	}
	public SelectionButtonItem getItem(int position)
	{
		return customerType.get(position);
	}
	

	public String[] getName() {
		return name;
	}
	public void setName(String[] name) {
		this.name = name;
	}
	
}
