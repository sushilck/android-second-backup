package com.smalution.y3distributiont1.entities.settings;

import org.json.JSONObject;

public class ACRegion 
{
	private String id;
	private String title;
	private String email;
	private String phone;
	private String address;
	private String city;
	private String state_id;
	private String lg_area_id;
	private String country_id;
	private String zipcode;
	private String description;
	private String created;
	private String modified;
	
	public ACRegion(){}
	public ACRegion(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			title=jsonObect.isNull("title")?"":jsonObect.getString("title");
			email=jsonObect.isNull("email")?"":jsonObect.getString("email");
			phone=jsonObect.isNull("phone")?"":jsonObect.getString("phone");
			address=jsonObect.isNull("address")?"":jsonObect.getString("address");
			city=jsonObect.isNull("name")?"":jsonObect.getString("name");
			state_id=jsonObect.isNull("state_id")?"":jsonObect.getString("state_id");
			lg_area_id=jsonObect.isNull("lg_area_id")?"":jsonObect.getString("lg_area_id");
			country_id=jsonObect.isNull("country_id")?"":jsonObect.getString("country_id");
			zipcode=jsonObect.isNull("zipcode")?"":jsonObect.getString("zipcode");
			description=jsonObect.isNull("description")?"":jsonObect.getString("description");
			created=jsonObect.isNull("created")?"":jsonObect.getString("created");
			modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState_id() {
		return state_id;
	}
	public void setState_id(String state_id) {
		this.state_id = state_id;
	}
	public String getLg_area_id() {
		return lg_area_id;
	}
	public void setLg_area_id(String lg_area_id) {
		this.lg_area_id = lg_area_id;
	}
	public String getCountry_id() {
		return country_id;
	}
	public void setCountry_id(String country_id) {
		this.country_id = country_id;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	
	
}
