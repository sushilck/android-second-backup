package com.smalution.y3distributiont1.entities.settings;

import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class Customers 
{
	static ArrayList<SelectionButtonItem> customers;
	String[] customerNamesArr;
	public Customers(){}
	public Customers(JSONArray jsonArray)
	{
		try
		{
			customers=new ArrayList<SelectionButtonItem>();
			customers.clear();
			customerNamesArr=new String[jsonArray.length()];
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject = jsonArray.getJSONObject(i); 
				String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
				String value=jsonObject.isNull("value")?"":jsonObject.getString("value");
				String ctype=jsonObject.isNull("ctype")?"":jsonObject.getString("ctype");
				String depotId=jsonObject.isNull("depot_id")?"":jsonObject.getString("depot_id");
				String regionId=jsonObject.isNull("region_id")?"":jsonObject.getString("region_id");
				SelectionButtonItem itm=new SelectionButtonItem(id, ctype, value, depotId, regionId);
				customers.add(itm);
				customerNamesArr[i]=itm.getTitle();
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public SelectionButtonItem getItem(int position)
	{
		System.out.println(customers.toString());
		return customers.get(position);
	}
	public String[] getCustomerNamesArr() 
	{
		return customerNamesArr;
	}
	public void setCustomerNamesArr(String[] customerNamesArr) 
	{
		this.customerNamesArr = customerNamesArr;
	}
}




/*
 package info.androidhive.slidingmenu.entities.settings;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.JSONObject;

public class Customers 
{
	Map<String, String> customers;
	String[] customerNamesArr;
	public Customers(){}
	public Customers(JSONObject jsonObject)
	{
		try
		{
			customers=new HashMap<String, String>();
			Iterator itr = jsonObject.keys();
			customerNamesArr=new String[jsonObject.length()];
			int i=0;
			while(itr.hasNext())
			{
				String key = (String)itr.next();
				String value = (String) jsonObject.getString(key);
				customers.put(value,key);
				customerNamesArr[i]=value;
				i=i+1;
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getId(String name)
	{
		return customers.get(name);
	}
	public Map<String, String> getCustomers() {
		return customers;
	}
	public void setCustomers(Map<String, String> customers) {
		this.customers = customers;
	}
	public String[] getCustomerNamesArr() {
		return customerNamesArr;
	}
	public void setCustomerNamesArr(String[] customerNamesArr) {
		this.customerNamesArr = customerNamesArr;
	}
	
}

 */