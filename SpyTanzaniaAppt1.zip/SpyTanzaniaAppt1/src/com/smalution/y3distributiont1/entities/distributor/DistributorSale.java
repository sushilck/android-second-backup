package com.smalution.y3distributiont1.entities.distributor;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class DistributorSale implements Parcelable
{
	RedistributorSaleItem RedistributorSaleitem;
	RedistributorBrand Brand;
	
	public DistributorSale()
	{
		RedistributorSaleitem=new RedistributorSaleItem();
		Brand=new RedistributorBrand();
	}
	public DistributorSale(JSONObject jsonObject)
	{
		try
		{
			RedistributorSaleitem=jsonObject.isNull("RedistributorSaleitem")?null:new RedistributorSaleItem(jsonObject.getJSONObject("RedistributorSaleitem"));
			Brand=jsonObject.isNull("Brand")?null:new RedistributorBrand(jsonObject.getJSONObject("Brand"));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public DistributorSale(JSONObject jsonObject,String json)
	{
		try
		{
			//Sale=new SOSale(jsonObject);
			RedistributorSaleitem=new RedistributorSaleItem(jsonObject);
			Brand=jsonObject.isNull("Brand")?null:new RedistributorBrand(jsonObject.getJSONObject("Brand"));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public DistributorSale(Parcel in)
 	{
		RedistributorSaleitem=in.readParcelable(RedistributorSaleItem.class.getClassLoader());
		Brand=in.readParcelable(RedistributorBrand.class.getClassLoader());
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable( RedistributorSaleitem,flags);
 		dest.writeParcelable( Brand,flags);
 	}
 	public static final Parcelable.Creator<DistributorSale> CREATOR = new Parcelable.Creator<DistributorSale>() 
 	{
 		public DistributorSale createFromParcel(Parcel in) 
 		{
 			return new DistributorSale(in);
 		}
 	
 		public DistributorSale[] newArray (int size) 
 		{
 			return new DistributorSale[size];
 		}
 	};

	public RedistributorSaleItem getRedistributorSaleitem() {
		return RedistributorSaleitem;
	}
	public void setRedistributorSaleitem(RedistributorSaleItem redistributorSaleitem) {
		RedistributorSaleitem = redistributorSaleitem;
	}
	public RedistributorBrand getBrand() {
		return Brand;
	}
	public void setBrand(RedistributorBrand brand) {
		Brand = brand;
	}
 	
}
