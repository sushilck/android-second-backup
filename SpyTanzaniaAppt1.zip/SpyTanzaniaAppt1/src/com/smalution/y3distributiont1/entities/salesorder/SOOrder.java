package com.smalution.y3distributiont1.entities.salesorder;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.Spanned;

public class SOOrder implements Parcelable
{
	private String total;
	private String id;
	private String created;
	private String status;
	private String items;
	private String user_id;
	private String order_date;
	private String payment;
	private String sale_type;
	private String customer_id;
	private String modified;
    
	public SOOrder(){}
	public SOOrder(JSONObject jsonObect)
	{
		try
		{
			total=jsonObect.isNull("total")?"":jsonObect.getString("total");
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			created=jsonObect.isNull("created")?"":jsonObect.getString("created");
			status=jsonObect.isNull("status")?"":jsonObect.getString("status");
			items=jsonObect.isNull("items")?"":jsonObect.getString("items");
			user_id=jsonObect.isNull("user_id")?"":jsonObect.getString("user_id");
			order_date=jsonObect.isNull("order_date")?"":jsonObect.getString("order_date");
			sale_type=jsonObect.isNull("sale_type")?"":jsonObect.getString("sale_type");
			payment=jsonObect.isNull("payment")?"":jsonObect.getString("payment");
			customer_id=jsonObect.isNull("customer_id")?"":jsonObect.getString("customer_id");
			modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public SOOrder(Parcel in)
 	{
		total = in.readString();
		id = in.readString();
		created = in.readString();
		status = in.readString();
		items = in.readString();
		user_id = in.readString();
		order_date = in.readString();
		sale_type = in.readString();
		payment = in.readString();
		customer_id = in.readString();
		modified = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(total);
 		dest.writeString(id);
 		dest.writeString(created);
 		dest.writeString(status);
 		dest.writeString(items);
 		dest.writeString(user_id);
 		dest.writeString(order_date);
 		dest.writeString(sale_type);
 		dest.writeString(payment);
 		dest.writeString(customer_id);
 		dest.writeString(modified);
 	}
 	public static final Parcelable.Creator<SOOrder> CREATOR = new Parcelable.Creator<SOOrder>() 
 	{
 		public SOOrder createFromParcel(Parcel in) 
 		{
 			return new SOOrder(in);
 		}
 	
 		public SOOrder[] newArray (int size) 
 		{
 			return new SOOrder[size];
 		}
 	};

	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getItems() {
		return items;
	}
	public void setItems(String items) {
		this.items = items;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getOrder_date() {
		return order_date;
	}
	public void setOrder_date(String order_date) {
		this.order_date = order_date;
	}
	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	
	public String getSale_type() {
		return sale_type;
	}
	public void setSale_type(String sale_type) {
		this.sale_type = sale_type;
	}
	
	
}
