/** Automatically generated file. DO NOT MODIFY */
package com.smalution.y3distributiont1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}