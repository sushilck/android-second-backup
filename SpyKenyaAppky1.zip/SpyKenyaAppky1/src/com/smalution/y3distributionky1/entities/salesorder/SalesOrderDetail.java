package com.smalution.y3distributionky1.entities.salesorder;


import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

import com.androidquery.AQuery;
import com.smalution.y3distributionky1.AppManager;
import com.smalution.y3distributionky1.utils.AppConstant;

public class SalesOrderDetail implements Parcelable
{
	SalesOrder order;
	ArrayList<Sales> sales;
	ArrayList<FreeItemSales> freeItems;
	String offlineCustomerJSON;
	public SalesOrderDetail()
	{
		order=new SalesOrder();
		sales=new ArrayList<Sales>();
		freeItems=new ArrayList<FreeItemSales>();
	}
	public SalesOrderDetail(JSONObject jsonObject)
	{
		try
		{
			System.out.println("ONLINE"+jsonObject.toString());
			order=jsonObject.isNull("order")?null:new SalesOrder(jsonObject.getJSONObject("order"));
			sales=jsonObject.isNull("sales")?null:getSalesList(jsonObject.getJSONArray("sales"));
			freeItems=jsonObject.isNull("freeItems")?null:getSalesFreeItemsList(jsonObject.getJSONArray("freeItems"));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public SalesOrderDetail(JSONObject jsonObject,int i,String json)
	{
		try
		{
			System.out.println("OFFLINE"+jsonObject.toString());
			order=new SalesOrder(new JSONObject(json.toString()),1);
			sales=jsonObject.isNull("sales")?null:getSalesList(jsonObject.getJSONArray("sales"),json);//SaleItemsFreeItems
			freeItems=jsonObject.isNull("freeItems")?null:getSalesFreeItemsList(jsonObject.getJSONArray("freeItems"),json);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	private ArrayList<FreeItemSales> getSalesFreeItemsList(JSONArray jsonArray) throws Exception
	{
		ArrayList<FreeItemSales> list = new ArrayList<FreeItemSales>();
		for(int i=0;i<jsonArray.length();i++)
		{
			list.add(new FreeItemSales(jsonArray.getJSONObject(i)));
		}
		return list;
	}
	private ArrayList<FreeItemSales> getSalesFreeItemsList(JSONArray jsonArray,String json) throws Exception
	{
		ArrayList<FreeItemSales> list = new ArrayList<FreeItemSales>();
		for(int i=0;i<jsonArray.length();i++)
		{
			list.add(new FreeItemSales(jsonArray.getJSONObject(i),json));
		}
		return list;
	}
	private ArrayList<Sales> getSalesList(JSONArray jsonArray) throws Exception
	{
		ArrayList<Sales> list=new ArrayList<Sales>();
		for(int i=0;i<jsonArray.length();i++)
		{
			list.add(new Sales(jsonArray.getJSONObject(i)));
		}
		return list;
	}
	private ArrayList<Sales> getSalesList(JSONArray jsonArray,String json) throws Exception
	{
		ArrayList<Sales> list=new ArrayList<Sales>();
		for(int i=0;i<jsonArray.length();i++)
		{
			list.add(new Sales(jsonArray.getJSONObject(i),json));
		}
		return list;
	}
	public SalesOrderDetail(Parcel in)
 	{
		order=in.readParcelable(SOOrder.class.getClassLoader());
		in.readTypedList(sales, Sales.CREATOR);
		in.readTypedList(freeItems, FreeItemSales.CREATOR);
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable(order,flags);
 		dest.writeTypedList(sales);
 		dest.writeTypedList(freeItems);
 	}
 	public static final Parcelable.Creator<SalesOrderDetail> CREATOR = new Parcelable.Creator<SalesOrderDetail>() 
 	{
 		public SalesOrderDetail createFromParcel(Parcel in) 
 		{
 			return new SalesOrderDetail(in);
 		}
 	
 		public SalesOrderDetail[] newArray (int size) 
 		{
 			return new SalesOrderDetail[size];
 		}
 	};
	public SalesOrder getOrder() {
		return order;
	}
	public void setOrder(SalesOrder order) {
		this.order = order;
	}
	public ArrayList<Sales> getSales() {
		return sales;
	}
	public void setSales(ArrayList<Sales> sales) {
		this.sales = sales;
	}
	public ArrayList<FreeItemSales> getFreeItems() {
		return freeItems;
	}
	public void setFreeItems(ArrayList<FreeItemSales> freeItems) {
		this.freeItems = freeItems;
	}
	public String createJson(AQuery aq,boolean isOnlineCustomerSelectionModeOn)
	{
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		String token = prefs.getString("token", null);
		String json="{" +
			"\"token\":\""+token+"\"," +
			"\"created\":\""+AppConstant.getCurrentDateAndTime()+"\"," +
			"\"request_id\":\""+AppConstant.ANDROIDDEVICEID + AppConstant.getRequestId()+"\"," +
			"\"customer_id\":\""+getOrder().getOrder().getCustomer_id()+"\"," +
			"\"customer_name\":\""+getOrder().getCustomer().getFirst_name()+"\"," +
			"\"sale_date\":\""+getOrder().getOrder().getOrder_date()+"\"," +
			"\"grand_total\":\""+getOrder().getOrder().getTotal()+"\",";
			json=json+"\"sales\":[";
			if(getSales()!=null && getSales().size()>0)
			{
				for(Sales sale:getSales())
				{
					json=json+"{\"brand_id\":\""+sale.getSale().getBrand_id()+"\"," +
							"\"unit\":\""+sale.getSale().getUnit()+"\"," +
							"\"unit_price\":\""+sale.getSale().getUnit_price()+"\"," +
							"\"quantity\":\""+sale.getSale().getQuantity()+"\"," +
							"\"amount\":\""+sale.getSale().getAmount()+"\"},";
				}
				json=json.substring(0, json.length()-1);
			}
			json=json+"],";
			json=json+"\"freeItems\":[";
			if(getFreeItems()!=null && getFreeItems().size()>0)
			{
				for(FreeItemSales freeItem:getFreeItems())
				{
					json=json+"{\"brand_id\":\""+freeItem.getFreeItem().getBrand_id()+"\"," +
							"\"unit\":\""+freeItem.getFreeItem().getUnit()+"\"," +
							"\"quantity\":\""+freeItem.getFreeItem().getQuantity()+"\"," +
							"\"compaign_id\":\""+freeItem.getFreeItem().getCompaign_id()+"\"},";
				}
				json=json.substring(0, json.length()-1);
			}
			if(!isOnlineCustomerSelectionModeOn)
			{
				json=json+"],";
				json=json+"\"newCustomer\":" ;
				json=json+getOfflineCustomerJSON();		
				json=json+"}";
			}
			else
			{
				json=json+"]}";
			}
		return json;
	}
	
	
	public String createJson(AQuery aq,boolean isOnlineCustomerSelectionModeOn,int id)
	{
		/*SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		String token = prefs.getString("token", null);*/
		String json=
			"\"request_id\":\""+AppConstant.ANDROIDDEVICEID+AppConstant.getRequestId()+"\"," +	
			"\"created\":\""+AppConstant.getCurrentDateAndTime()+"\"," +	
			"\"customer_id\":\""+getOrder().getOrder().getCustomer_id()+"\"," +	
			"\"customer_name\":\""+getOrder().getCustomer().getFirst_name()+"\"," +
			"\"sale_date\":\""+getOrder().getOrder().getOrder_date()+"\"," +
			"\"grand_total\":\""+getOrder().getOrder().getTotal()+"\",";
			json=json+"\"sales\":[";
			if(getSales()!=null && getSales().size()>0)
			{
				for(Sales sale:getSales())
				{
					json=json+"{\"brand_id\":\""+sale.getSale().getBrand_id()+"\"," +
							"\"unit\":\""+sale.getSale().getUnit()+"\"," +
							"\"unit_price\":\""+sale.getSale().getUnit_price()+"\"," +
							"\"quantity\":\""+sale.getSale().getQuantity()+"\"," +
							"\"amount\":\""+sale.getSale().getAmount()+"\"},";
					
				}
				json=json.substring(0, json.length()-1);
			}
			
			json=json+"],";
			json=json+"\"freeItems\":[";
			if(getFreeItems()!=null && getFreeItems().size()>0)
			{
				for(FreeItemSales freeItem:getFreeItems())
				{
					json=json+"{\"brand_id\":\""+freeItem.getFreeItem().getBrand_id()+"\"," +
							"\"unit\":\""+freeItem.getFreeItem().getUnit()+"\"," +
							"\"quantity\":\""+freeItem.getFreeItem().getQuantity()+"\"," +
							"\"compaign_id\":\""+freeItem.getFreeItem().getCompaign_id()+"\"},";
				}
				json=json.substring(0, json.length()-1);
			}
			if(!isOnlineCustomerSelectionModeOn)
			{
				json=json+"],";
				json=json+"\"newCustomer\":" ;
				json=json+getOfflineCustomerJSON();		
				json=json+"}";
			}
			else
			{
				json=json+"]}";
			}
		return json;
	}
	
	
	
	
	
	
	
	
	
	
	
	public String getOfflineCustomerJSON() {
		return offlineCustomerJSON;
	}
	public void setOfflineCustomerJSON(String offlineCustomerJSON) {
		this.offlineCustomerJSON = offlineCustomerJSON;
	}
}
