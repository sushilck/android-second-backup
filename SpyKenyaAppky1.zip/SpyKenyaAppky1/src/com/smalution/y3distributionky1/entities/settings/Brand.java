package com.smalution.y3distributionky1.entities.settings;

import org.json.JSONObject;

public class Brand 
{
	 private String id="";
     private String name="";
     private String description="";
     private String user_id="";
     private String case_price="";
     private String roll_price="";
     private String pack_price="";
     private String pack2_price="";
     private String case_roll="";
     private String roll_pack="";
     private String pack_sticks="";
     private String pack2_pack="";
     private String status="";
     private String rd_case_price="";
     private String rd_roll_price="";
     private String rd_pack_price="";
     private String rd_2pack_price="";
     private String created="";
     private String modified;
     
     public Brand(){}
	public Brand(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			name=jsonObect.isNull("name")?"":jsonObect.getString("name");
			description=jsonObect.isNull("description")?"":jsonObect.getString("description");
			user_id=jsonObect.isNull("user_id")?"":jsonObect.getString("user_id");
			case_price=jsonObect.isNull("case_price")?"":jsonObect.getString("case_price");
			roll_price=jsonObect.isNull("roll_price")?"":jsonObect.getString("roll_price");
			roll_pack=jsonObect.isNull("roll_pack")?"":jsonObect.getString("roll_pack");
			pack_price=jsonObect.isNull("pack_price")?"":jsonObect.getString("pack_price");
			pack2_price=jsonObect.isNull("2pack_price")?"":jsonObect.getString("2pack_price");
			case_roll=jsonObect.isNull("case_roll")?"":jsonObect.getString("case_roll");
			roll_pack=jsonObect.isNull("roll_pack")?"":jsonObect.getString("roll_pack");
			pack_sticks=jsonObect.isNull("pack_sticks")?"":jsonObect.getString("pack_sticks");
			pack2_pack=jsonObect.isNull("2pack_pack")?"":jsonObect.getString("2pack_pack");
			status=jsonObect.isNull("status")?"":jsonObect.getString("status");
			rd_case_price=jsonObect.isNull("rd_case_price")?"":jsonObect.getString("rd_case_price");
			rd_roll_price=jsonObect.isNull("rd_roll_price")?"":jsonObect.getString("rd_roll_price");
			rd_pack_price=jsonObect.isNull("rd_pack_price")?"":jsonObect.getString("rd_pack_price");
			rd_2pack_price=jsonObect.isNull("rd_2pack_price")?"":jsonObect.getString("rd_2pack_price");
			created=jsonObect.isNull("created")?"":jsonObect.getString("created");
			modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getCase_price() {
		return case_price;
	}
	public void setCase_price(String case_price) {
		this.case_price = case_price;
	}
	public String getRoll_price() {
		return roll_price;
	}
	public void setRoll_price(String roll_price) {
		this.roll_price = roll_price;
	}
	public String getPack_price() {
		return pack_price;
	}
	public void setPack_price(String pack_price) {
		this.pack_price = pack_price;
	}
	public String getPack2_price() {
		return pack2_price;
	}
	public void setPack2_price(String pack2_price) {
		this.pack2_price = pack2_price;
	}
	public String getCase_roll() {
		return case_roll;
	}
	public void setCase_roll(String case_roll) {
		this.case_roll = case_roll;
	}
	public String getRoll_pack() {
		return roll_pack;
	}
	public void setRoll_pack(String roll_pack) {
		this.roll_pack = roll_pack;
	}
	public String getPack_sticks() {
		return pack_sticks;
	}
	public void setPack_sticks(String pack_sticks) {
		this.pack_sticks = pack_sticks;
	}
	public String getPack2_pack() {
		return pack2_pack;
	}
	public void setPack2_pack(String pack2_pack) {
		this.pack2_pack = pack2_pack;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRd_case_price() {
		return rd_case_price;
	}
	public void setRd_case_price(String rd_case_price) {
		this.rd_case_price = rd_case_price;
	}
	public String getRd_roll_price() {
		return rd_roll_price;
	}
	public void setRd_roll_price(String rd_roll_price) {
		this.rd_roll_price = rd_roll_price;
	}
	public String getRd_pack_price() {
		return rd_pack_price;
	}
	public void setRd_pack_price(String rd_pack_price) {
		this.rd_pack_price = rd_pack_price;
	}
	public String getRd_2pack_price() {
		return rd_2pack_price;
	}
	public void setRd_2pack_price(String rd_2pack_price) {
		this.rd_2pack_price = rd_2pack_price;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	
}
