package com.smalution.y3distributionky1.entities.customervisits;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class CustVisitLgArea implements Parcelable
{
	private String id;
	private String name;
	private String state_id;
	public CustVisitLgArea(){}
	public CustVisitLgArea(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			name=jsonObect.isNull("name")?"":jsonObect.getString("name");
			state_id=jsonObect.isNull("state_id")?"":jsonObect.getString("state_id");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public CustVisitLgArea(Parcel in)
 	{
		id = in.readString();
		name = in.readString();
		state_id = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(name);
 		dest.writeString(state_id);
	}
 	public static final Parcelable.Creator<CustVisitLgArea> CREATOR = new Parcelable.Creator<CustVisitLgArea>() 
 	{
 		public CustVisitLgArea createFromParcel(Parcel in) 
 		{
 			return new CustVisitLgArea(in);
 		}
 	
 		public CustVisitLgArea[] newArray (int size) 
 		{
 			return new CustVisitLgArea[size];
 		}
 	};
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getState_id() {
		return state_id;
	}
	public void setState_id(String state_id) {
		this.state_id = state_id;
	}
	
}
