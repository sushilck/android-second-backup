package com.smalution.y3distributionky1.entities.customervisits;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class CustVisitUser implements Parcelable
{
	private String last_name;
	private String first_name;
	public CustVisitUser(){}
	public CustVisitUser(JSONObject jsonObect)
	{
		try
		{
			last_name=jsonObect.isNull("last_name")?"":jsonObect.getString("last_name");
			first_name=jsonObect.isNull("first_name")?"":jsonObect.getString("first_name");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public CustVisitUser(Parcel in)
 	{
		last_name = in.readString();
		first_name = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(last_name);
 		dest.writeString(first_name);
	}
 	public static final Parcelable.Creator<CustVisitUser> CREATOR = new Parcelable.Creator<CustVisitUser>() 
 	{
 		public CustVisitUser createFromParcel(Parcel in) 
 		{
 			return new CustVisitUser(in);
 		}
 	
 		public CustVisitUser[] newArray (int size) 
 		{
 			return new CustVisitUser[size];
 		}
 	};
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	
}
