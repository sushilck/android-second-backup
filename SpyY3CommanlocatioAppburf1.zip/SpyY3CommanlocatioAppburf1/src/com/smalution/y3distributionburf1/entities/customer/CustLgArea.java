package com.smalution.y3distributionburf1.entities.customer;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class CustLgArea implements Parcelable
{
	private String id;
	private String name;
	public CustLgArea(){}
	public CustLgArea(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			name=jsonObect.isNull("name")?"":jsonObect.getString("name");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public CustLgArea(Parcel in)
 	{
		id = in.readString();
		name = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(name);
	}
 	public static final Parcelable.Creator<CustLgArea> CREATOR = new Parcelable.Creator<CustLgArea>() 
 	{
 		public CustLgArea createFromParcel(Parcel in) 
 		{
 			return new CustLgArea(in);
 		}
 	
 		public CustLgArea[] newArray (int size) 
 		{
 			return new CustLgArea[size];
 		}
 	};
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
