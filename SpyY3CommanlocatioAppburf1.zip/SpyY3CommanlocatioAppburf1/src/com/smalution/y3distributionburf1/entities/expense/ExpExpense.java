package com.smalution.y3distributionburf1.entities.expense;


import org.json.JSONObject;

import com.smalution.y3distributionburf1.entities.Expense;

import android.os.Parcel;
import android.os.Parcelable;

public class ExpExpense implements Parcelable
{
	private String id;
    private String title;
    private String created;
    private String description;
    private String depot_id;
    private String region_id;
    private String payment_mode;
    private String brand_id;
    private String exp_type_id;
    private String exp_amount;
    private String user_id;
    private String expense_ref;
    private String exp_date;
    private String modified;
    
	public ExpExpense(){}
	public ExpExpense(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
		    title=jsonObect.isNull("title")?"":jsonObect.getString("title");
		    created=jsonObect.isNull("created")?"":jsonObect.getString("created");
		    description=jsonObect.isNull("description")?"":jsonObect.getString("description");
		    depot_id=jsonObect.isNull("depot_id")?"":jsonObect.getString("depot_id");
		    region_id=jsonObect.isNull("region_id")?"":jsonObect.getString("region_id");
		    payment_mode=jsonObect.isNull("payment_mode")?"":jsonObect.getString("payment_mode");
		    brand_id=jsonObect.isNull("brand_id")?"":jsonObect.getString("brand_id");
		    exp_type_id=jsonObect.isNull("exp_type_id")?"":jsonObect.getString("exp_type_id");
		    exp_amount=jsonObect.isNull("exp_amount")?"":jsonObect.getString("exp_amount");
		    user_id=jsonObect.isNull("user_id")?"":jsonObect.getString("user_id");
		    expense_ref=jsonObect.isNull("expense_ref")?"":jsonObect.getString("expense_ref");
		    exp_date=jsonObect.isNull("exp_date")?"":jsonObect.getString("exp_date");
		    modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public ExpExpense(Parcel in)
 	{
		id = in.readString();
	    title = in.readString();
	    created = in.readString();
	    description = in.readString();
	    depot_id = in.readString();
	    region_id = in.readString();
	    payment_mode = in.readString();
	    brand_id = in.readString();
	    exp_type_id = in.readString();
	    exp_amount = in.readString();
	    user_id = in.readString();
	    expense_ref = in.readString();
	    exp_date = in.readString();
	    modified = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 	    dest.writeString(title);
 	    dest.writeString(created);
 	    dest.writeString(description);
 	    dest.writeString(depot_id);
 	    dest.writeString(region_id);
 	    dest.writeString(payment_mode);
 	    dest.writeString(brand_id);
 	    dest.writeString(exp_type_id);
 	    dest.writeString(exp_amount);
 	    dest.writeString(user_id);
 	    dest.writeString(expense_ref);
 	    dest.writeString(exp_date);
 	    dest.writeString(modified);
 	}
 	public static final Parcelable.Creator<ExpExpense> CREATOR = new Parcelable.Creator<ExpExpense>() 
 	{
 		public ExpExpense createFromParcel(Parcel in) 
 		{
 			return new ExpExpense(in);
 		}
 	
 		public ExpExpense[] newArray (int size) 
 		{
 			return new ExpExpense[size];
 		}
 	};

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDepot_id() {
		return depot_id;
	}
	public void setDepot_id(String depot_id) {
		this.depot_id = depot_id;
	}
	public String getRegion_id() {
		return region_id;
	}
	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}
	public String getPayment_mode() {
		return payment_mode;
	}
	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}
	public String getBrand_id() {
		return brand_id;
	}
	public void setBrand_id(String brand_id) {
		this.brand_id = brand_id;
	}
	public String getExp_type_id() {
		return exp_type_id;
	}
	public void setExp_type_id(String exp_type_id) {
		this.exp_type_id = exp_type_id;
	}
	public String getExp_amount() {
		return exp_amount;
	}
	public void setExp_amount(String exp_amount) {
		this.exp_amount = exp_amount;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getExpense_ref() {
		return expense_ref;
	}
	public void setExpense_ref(String expense_ref) {
		this.expense_ref = expense_ref;
	}
	public String getExp_date() {
		return exp_date;
	}
	public void setExp_date(String exp_date) {
		this.exp_date = exp_date;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	
}
