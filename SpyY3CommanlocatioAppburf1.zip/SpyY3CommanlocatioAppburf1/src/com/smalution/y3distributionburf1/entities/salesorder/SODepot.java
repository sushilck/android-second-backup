package com.smalution.y3distributionburf1.entities.salesorder;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class SODepot implements Parcelable
{
	private String region_id;
	private String id;
	private String title;
	public SODepot(){}
	public SODepot(JSONObject jsonObect)
	{
		try
		{
			region_id=jsonObect.isNull("region_id")?"":jsonObect.getString("region_id");
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			title=jsonObect.isNull("title")?"":jsonObect.getString("title");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public SODepot(Parcel in)
 	{
		region_id = in.readString();
		id = in.readString();
		title = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(region_id);
 		dest.writeString(id);
 		dest.writeString(title);
 	}
 	public static final Parcelable.Creator<SODepot> CREATOR = new Parcelable.Creator<SODepot>() 
 	{
 		public SODepot createFromParcel(Parcel in) 
 		{
 			return new SODepot(in);
 		}
 	
 		public SODepot[] newArray (int size) 
 		{
 			return new SODepot[size];
 		}
 	};
	public String getRegion_id() {
		return region_id;
	}
	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
}
