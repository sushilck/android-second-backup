package com.smalution.y3distributionburf1.fragments.incentive;

import com.smalution.y3distributionburf1.AppManager;
import com.smalution.y3distributionburf1.R;
import com.smalution.y3distributionburf1.Utils;
import com.smalution.y3distributionburf1.database.Y3QueryDataSource;
import com.smalution.y3distributionburf1.entities.customer.SearchCutomer;
import com.smalution.y3distributionburf1.entities.incentive.IncentiveItem;
import com.smalution.y3distributionburf1.entities.settings.Brands;
import com.smalution.y3distributionburf1.entities.settings.Customers;
import com.smalution.y3distributionburf1.entities.settings.Depots;
import com.smalution.y3distributionburf1.entities.settings.SelectionButtonItem;
import com.smalution.y3distributionburf1.fragments.SuperFragment;
import com.smalution.y3distributionburf1.utils.AppConstant;
import com.smalution.y3distributionburf1.utils.DatePickerFragment;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.Toast;

import com.androidquery.AQuery;

public class IncentiveAddFragment extends SuperFragment 
{
	boolean isOnlineCustomerSelectionModeOn=true;
	IncentiveItem incentiveItem;
	View rootView;
	AQuery aq; 
	Hashtable<String, String> offlineCustomers;
	public static final int FLAG_SELECT_CUSTOMER=101;
	public static final int FLAG_SELECT_BRAND=102;
	public static final int FLAG_SELECT_DEPOT=103;
	public static final int FLAG_SELECT_INCENTIVETYPE=104;
	public static final int FLAG_SELECT_UNIT=105;
	UIHandler uiHandler;
	public static  String jsonString;
	public static String brand_id;
	public static  String customer_id;
	public static String depot_id="0";
	public static  String selectedImagePath;
	public static String customer_json;
	private boolean flagIsAddMore;
	public boolean isDraft = false;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		case FLAG_SELECT_CUSTOMER:
        		{
        			
        			if(isOnlineCustomerSelectionModeOn)
        			{
        				
        				SelectionButtonItem itm = (SelectionButtonItem) msg.obj;
        				if(msg.arg2 != 0)
        				{
        					customer_id= Integer.toString(msg.arg2);
        					incentiveItem.getCustomer().setId(itm.getId());
    						incentiveItem.getCustomer().setFname(itm.getTitle());
    						incentiveItem.getCustomer().setLname("");
        				}
        				/*Customers customers= AppManager.getInstance().getCustomers(aq);
        				
        				
        				if(customers!=null)
        				{
        					SelectionButtonItem itm = customers.getItem(msg.arg2);
        					if(itm!=null)
        					{
        						incentiveItem.getCustomer().setId(itm.getId());
        						incentiveItem.getCustomer().setFname(itm.getTitle());
        						incentiveItem.getCustomer().setLname("");
        						
        						
        					}
        				}*/
        				aq.id(R.id.buttonCustomer).text(itm.getTitle());
            			aq.id(R.id.buttonOfflineCustomer).text(getString(R.string.select_offline_customer));
        			}
        			else
        			{
        				String selectedValue=(String)msg.obj;
        				customer_id= Integer.toString(msg.arg2);
        				aq.id(R.id.buttonCustomer).text(getString(R.string.select_customer));
        				aq.id(R.id.buttonOfflineCustomer).text(selectedValue);
        			}
        			break;
				}
        		case FLAG_SELECT_BRAND:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonBrand).text(selectedValue);
        			Brands brands= AppManager.getInstance().getBrands(aq);
        			if(brands!=null)
        			{
        				brand_id=brands.getItem(msg.arg2).getId();
        				incentiveItem.getBrand().setId(brands.getItem(msg.arg2).getId());
        			}
        			break;
        		}
        		case FLAG_SELECT_DEPOT:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonDepot).text(selectedValue);
        			Depots depots= AppManager.getInstance().getDepots(aq);
        			if(depots!=null)
        			{
        				depot_id=depots.getItem(msg.arg2).getId();
        				String id = depots.getItem(msg.arg2).getId();
        				if(id!=null)
        				{
        					incentiveItem.getDepot().setId(id);
        				}
        			}
        			break;
        		}
        		case FLAG_SELECT_INCENTIVETYPE:
	    		{
	    			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonIncentiveType).text(selectedValue);
        			break;
	    		}
        		case FLAG_SELECT_UNIT:
	    		{
	    			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonUnit).text(selectedValue);
        			break;
	    		}
	    	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	incentiveItem = args.getParcelable("PAYMENT");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		incentiveItem = getArguments().getParcelable("PAYMENT");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.incentive_add_fragment, container, false);
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        incentiveItem=new IncentiveItem();
        flagIsAddMore=false;
        initUI();
        ifillfromDraft();
        return rootView;
    }
	
	public void onPause(){
		super.onPause();
		System.out.println("This is OnPause activity");
		iaddDraft();
	}
	
	public void onStop(){
		super.onStop();
		System.out.println("This is onStop activity");
		iaddDraft();
	}
	
	public void onDestroy(){
		super.onDestroy();
		System.out.println("This is onDestroy activity");
		iaddDraft();
	}
	
	private void initUI() 
	{
		
		aq.id(R.id.tableRowDepot).gone();
		aq.id(R.id.buttonCustomer).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				aq.id(R.id.buttonOfflineCustomer).text(getString(R.string.select_offline_customer));
				isOnlineCustomerSelectionModeOn=true;
				SearchCutomer.showAutosearchAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER);
				/*boolean flag=false;
				final Customers customers= AppManager.getInstance().getCustomers(aq);
				if(customers!=null)
				{
					String[] arr=customers.getCustomerNamesArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.customer_required_mess), Toast.LENGTH_SHORT).show();
				}*/
			}
		});
		
		aq.id(R.id.buttonOfflineCustomer).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				isOnlineCustomerSelectionModeOn=false;
				aq.id(R.id.buttonCustomer).text(getString(R.string.select_customer));
				new GetOfflineCustomersAsyncTask(aq).execute();
			}
		});
		aq.id(R.id.editTextDateOfIncentive).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				showDatePicker();
			}
		});
		
		aq.id(R.id.buttonBrand).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				Brands brands = AppManager.getInstance().getBrands(aq);
				boolean flag=false;
				if(brands!=null)
				{
					String[] arr=brands.getBrandsNames();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_BRAND, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.brand_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		aq.id(R.id.buttonDepot).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				Depots depots= AppManager.getInstance().getDepots(aq);
				boolean flag=false;
				if(depots!=null)
				{
					String[] arr=depots.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DEPOT, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.depot_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		aq.id(R.id.buttonIncentiveType).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				String[] arr= AppManager.incetiveTypes;
				if(arr.length>0)
				{
					AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_INCENTIVETYPE, arr);
					flag=true;
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.incentive_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		aq.id(R.id.buttonUnit).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				String[] arr= AppManager.units;
				if(arr.length>0)
				{
					AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_UNIT, arr);
					flag=true;
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.unit_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(validateInput())
				{
					
					
					if(AppManager.isOnline(getActivity()))
					{
						flagIsAddMore=false;
						jsonString = incentiveItem.createJson(aq, false,isOnlineCustomerSelectionModeOn);
						new AddIncentive().execute();
					}
					else
					{
						
					    DateFormat dateFormat = new SimpleDateFormat("HHmmss");
						Date date = new Date();
						System.out.println(dateFormat.format(date));
						/* String  firstLetter = String.valueOf(dateFormat.format(date).toString().charAt(0));
						  if("0".equals(firstLetter)){
							  firstLetter.substring(1);
						  }*/
						String  firstLetter = dateFormat.format(date).toString().replaceFirst("^0+(?!$)", "");
					    incentiveItem.getIncentive().setId(firstLetter);
					    Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
					    datasource.open();
					    incentiveItem.getIncentive().setCreated(AppConstant.getCurrentDateAndTime());
					    incentiveItem.getIncentive().setModified(AppConstant.SYNC_NOT_DONE);
					    datasource.addIncentiveData(incentiveItem, "1",customer_json);
					    showSaveDialog();
					    SharedPreferences iprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
						Editor edt = iprefs.edit();
						edt.putString("idraftJsonString", null);
						edt.commit();
						isDraft = true;
					    //Toast.makeText(getActivity(), "Incentive added successfully.", Toast.LENGTH_SHORT).show();
				    	///getActivity().getSupportFragmentManager().popBackStack();
					
					}
					
					/*Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
				    datasource.open();
				    long result = datasource.addY3Query(Y3QueryDataSource.ACTION_INCENTIVE_ADD, jsonStr, null);
				    datasource.close();
				    if(result!=-1)
				    {
				    	Toast.makeText(getActivity(), "Incentive added successfully.", Toast.LENGTH_SHORT).show();
				    	getActivity().getSupportFragmentManager().popBackStack();
				    }*/
				}
			}
		});
		aq.id(R.id.buttonSaveAddMore).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(validateInput())
				{
					if(AppManager.isOnline(getActivity()))
					{
						flagIsAddMore=true;
						jsonString = incentiveItem.createJson(aq, false,isOnlineCustomerSelectionModeOn);
						new AddIncentive().execute();
					}
					else
					{
						Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
					    datasource.open();
					    DateFormat dateFormat = new SimpleDateFormat("HHmmss");
						Date date = new Date();

						String  firstLetter = dateFormat.format(date).toString().replaceFirst("^0+(?!$)", "");
					    incentiveItem.getIncentive().setId(firstLetter);					  
					    incentiveItem.getIncentive().setCreated(AppConstant.getCurrentDateAndTime());
					    incentiveItem.getIncentive().setModified(AppConstant.SYNC_NOT_DONE);
					    datasource.addIncentiveData(incentiveItem, "1",customer_json);
					    showSaveMoreDialog();
					   // datasource.addIncentiveData(incentiveItem, "1",customer_json);

						
						
						
						
						
						
					   // incentiveItem.getIncentive().setId(firstLetter);					    
					    
					    
					    //Toast.makeText(getActivity(), "Incentive added successfully.", Toast.LENGTH_SHORT).show();
				    	//getActivity().getSupportFragmentManager().popBackStack();
					
					}
				}
			}
		});
	}
	private void initFeilds() 
	{
		aq.id(R.id.buttonCustomer).text(getString(R.string.select_customer));
		aq.id(R.id.buttonOfflineCustomer).text(getString(R.string.select_offline_customer));
		aq.id(R.id.editTextDateOfIncentive).text("");
		aq.id(R.id.buttonBrand).text(getString(R.string.select_brand));
		//aq.id(R.id.buttonDepot).text(getString(R.string.select_depot));
		aq.id(R.id.buttonIncentiveType).text(getString(R.string.select_incentive_type));
		aq.id(R.id.buttonUnit).text(getString(R.string.select_unit));
		aq.id(R.id.editTextQuantity).text("");
		incentiveItem=new IncentiveItem();
	}
	private boolean validateInput()
	{
		if(
		validateCustomerName()&&
		validateDateOfIncentive()&&
		validateBrand()&&
		validateDepot()&&
		validateIncentiveType()&&
		validateUnit()&&
		validateQuantity()
		)
		{
			return true;
		}
		return false;
	}
	private boolean validateCustomerName()
	{
		boolean flag=false;
		if(isOnlineCustomerSelectionModeOn)
		{
			String customerName = aq.id(R.id.buttonCustomer).getText().toString();
			if(incentiveItem.getCustomer()!=null && incentiveItem.getCustomer().getId()!=null)
			{
				flag=true;
			}
		}
		else
		{
			String customerName = aq.id(R.id.buttonOfflineCustomer).getText().toString();
			if(customerName!=null && customerName.length()>0)
			{
				try{
				customer_json = offlineCustomers.get(customerName);
				JSONObject jsonojb=new JSONObject(customer_json);				
				incentiveItem.getCustomer().setFname(jsonojb.getString("first_name"));
				incentiveItem.getCustomer().setLname(jsonojb.getString("last_name"));
				
				}
				catch(Exception e){
					
					e.printStackTrace();
				}
				
				
				incentiveItem.setOfflineCustomerJSON(customer_json);
				return true;
			}
		}
		
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.select_customer), Toast.LENGTH_SHORT).show();
		}
		return flag;
	}
	private boolean validateDateOfIncentive()
	{
		boolean flag=false;
		String DateOfIncentive = aq.id(R.id.editTextDateOfIncentive).getText().toString();
		if(DateOfIncentive!=null && DateOfIncentive.length()>0)
		{
			incentiveItem.getIncentive().setIncentive_date(DateOfIncentive);
			flag=true;
		}
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.select_customer), Toast.LENGTH_SHORT).show();
		}
		return flag;
	}
	private boolean validateBrand()
	{
		boolean flag=false;
		String brandName = aq.id(R.id.buttonBrand).getText().toString();
		if(brandName!=null && brandName.length()>0)
		{
			//incentiveItem.getBrand().getName())
			incentiveItem.getBrand().setName(brandName);
			flag=true;
		}
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.select_brand), Toast.LENGTH_SHORT).show();
		}
		return flag;
	}
	private boolean validateDepot()
	{
		/*boolean flag=false;
		String depotName = aq.id(R.id.buttonDepot).getText().toString();
		if(depotName!=null && depotName.length()>0 && incentiveItem.getDepot().getId()!=null && incentiveItem.getDepot().getId().length()>0)
		{
			flag=true;
			incentiveItem.getDepot().setTitle(depotName);
		}
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.select_depot), Toast.LENGTH_SHORT).show();
		}*/
		return true;
	}
	private boolean validateIncentiveType()
	{
		boolean flag=false;
		String incentiveType = aq.id(R.id.buttonIncentiveType).getText().toString();
		if(incentiveType!=null && incentiveType.length()>0)
		{
			incentiveItem.getIncentive().setIncentive_type(incentiveType);
			flag=true;
		}
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.select_incentive_type), Toast.LENGTH_SHORT).show();
		}
		return flag;
	}
	private boolean validateUnit()
	{
		boolean flag=false;
		String unitName = aq.id(R.id.buttonUnit).getText().toString();
		if(unitName!=null && unitName.length()>0)
		{
			incentiveItem.getIncentive().setUnit(unitName);
			flag=true;
		}
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.select_unit), Toast.LENGTH_SHORT).show();
		}
		return flag;
	}
	private boolean validateQuantity()
	{
		boolean flag=false;
		String quantity = aq.id(R.id.editTextQuantity).getText().toString();
		if(quantity!=null && quantity.length()>0
				&& AppManager.getInstance().isValidNumber(quantity))
		{
			try
			{
				Float.parseFloat(quantity);
				incentiveItem.getIncentive().setQuantity(quantity);
				flag=true;
			}catch(Exception ex){}
		}
		if(!flag)
		{
			Toast.makeText(getActivity(), getString(R.string.valid_qty_mess), Toast.LENGTH_SHORT).show();
		}
		return flag;
	}
	
	private void showDatePicker() 
	{
		  DatePickerFragment date = new DatePickerFragment();
		  Calendar calender = Calendar.getInstance();
		  Bundle args = new Bundle();
		  args.putInt("year", calender.get(Calendar.YEAR));
		  args.putInt("month", calender.get(Calendar.MONTH));
		  args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
		  date.setArguments(args);
		  date.setCallBack(ondate);
		  date.show(getActivity().getSupportFragmentManager(), getString(R.string.date_picker));
	}
	OnDateSetListener ondate = new OnDateSetListener() 
	{
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth) 
		{
			String dateStr=String.valueOf(year) + "-" + String.valueOf(monthOfYear+1)+ "-" + String.valueOf(dayOfMonth);
			aq.id(R.id.editTextDateOfIncentive).text(dateStr);
			incentiveItem.getIncentive().setIncentive_date(dateStr);
		}
	};
	private class GetOfflineCustomersAsyncTask extends AsyncTask<Void, Void,String[]>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		boolean flag=false;
		public GetOfflineCustomersAsyncTask(AQuery aq)
		{
			this.aq=aq;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected String[] doInBackground(Void... params) 
		{
			Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		    datasource.open();
		    SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
			String token = prefs.getString("token", null);
		    offlineCustomers = datasource.getOfflineCustomeData(token);
		    datasource.close();
		    
		    if(offlineCustomers!=null)
			{
		    	Set<String> keys = offlineCustomers.keySet();
			    String[] arr=new String[keys.size()];
			    keys.toArray(arr);
			    return arr;
			}
			return null;
		}
		@Override
		protected void onPostExecute(String[] result) 
		{
			super.onPostExecute(result);
			if(result!=null)
			{
		    	if(result.length>0)
				{
					AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER, result);
					flag=true;
				}
			}
			if(!flag)
			{
				Toast.makeText(getActivity(), getString(R.string.offline_customer_mess), Toast.LENGTH_SHORT).show();
			}
			progressDialog.dismiss();
		}
	}
	
	
	
	
	
	private class AddIncentive extends AsyncTask<Void, Void, String> {


		ProgressDialog progressDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
			progressDialog.setMessage(getString(R.string.wait_progress));
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(true);
			progressDialog.show();
			progressDialog
					.setOnKeyListener(new DialogInterface.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog,
								int keyCode, KeyEvent event) {
							return false;
						}
					});
		}


		protected String doInBackground(Void... params1) {
			if (AppManager.getInstance().isOnline(aq.getContext())) {
				
				Hashtable<String,String> params=new Hashtable<String,String>();
	    		params.put("jsonString",jsonString);	
	    		//String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_INCENTIVE, params, null);
				String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_INCENTIVE, params, null);
				return response;
			}
			return null;
		}

		protected void onPostExecute(String response) {
			
			progressDialog.dismiss();
			
			try {
				if(response!=null){
				int errorCode=new JSONObject(response).getInt("error");
				
				if(errorCode==0){
					System.out.println("Added");
					if(flagIsAddMore){
						showSaveMoreDialog();
						//Toast.makeText(getActivity(), "Incentive added successfully.", Toast.LENGTH_SHORT).show();
						//initFeilds();
						//flagIsAddMore=false;
					    // getActivity().getSupportFragmentManager().popBackStack();
					}else{
						//Toast.makeText(getActivity(), "Incentive added successfully.", Toast.LENGTH_SHORT).show();
					    // getActivity().getSupportFragmentManager().popBackStack();
						showSaveDialog();
						SharedPreferences iprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
						Editor edt = iprefs.edit();
						edt.putString("idraftJsonString", null);
						edt.commit();
						isDraft = true;
					}
					 
				}
				else{
					System.out.println("something wrong");
					
				}
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}

private void showSaveDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(getString(R.string.confirm));
		alertDialogBuilder
				.setMessage(getString(R.string.incentive_added))
				.setCancelable(false)
				.setPositiveButton(
						getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								getActivity().getSupportFragmentManager().popBackStack();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
	
	private void showSaveMoreDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(getString(R.string.confirm));
		alertDialogBuilder
				.setMessage(getString(R.string.incentive_added))
				.setCancelable(false)
				.setPositiveButton(
						getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								//getActivity().getSupportFragmentManager().popBackStack();
								initFeilds();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
	
	public void iaddDraft(){
		if(!isDraft){	
			incentiveItem.getCustomer().setId(customer_id);
			incentiveItem.getIncentive().setCustomer_id(customer_id);
			incentiveItem.getCustomer().setFname(aq.id(R.id.buttonCustomer).getButton().getText().toString());			
			incentiveItem.getIncentive().setIncentive_date(aq.id(R.id.editTextDateOfIncentive).getEditText().getText().toString());
			incentiveItem.getBrand().setId(brand_id);
			incentiveItem.getIncentive().setBrand_id(brand_id);
			incentiveItem.getBrand().setName(aq.id(R.id.buttonBrand).getButton().getText().toString());
			incentiveItem.getDepot().setId(depot_id);
			incentiveItem.getIncentive().setDepot_id(depot_id);
			incentiveItem.getDepot().setTitle(aq.id(R.id.buttonDepot).getButton().getText().toString());
			incentiveItem.getIncentive().setUnit(aq.id(R.id.buttonUnit).getButton().getText().toString());
			incentiveItem.getIncentive().setIncentive_type(aq.id(R.id.buttonIncentiveType).getButton().getText().toString());	
			incentiveItem.getIncentive().setQuantity(aq.id(R.id.editTextQuantity).getEditText().getText().toString());	
			String idraftJsonString = incentiveItem.createJson(aq,true,true);
			SharedPreferences iprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
			Editor edt = iprefs.edit();
			edt.putString("idraftJsonString", idraftJsonString);
			edt.commit();
			isDraft = true;
		}
	}
	
	
	
	public void ifillfromDraft(){
		SharedPreferences iprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		String idraftJsonString = iprefs.getString("idraftJsonString", null);
		//System.out.println("INCENTIVEDATA:"+idraftJsonString);
		if(idraftJsonString != null){
			try {
				JSONObject IncentiveJson = new JSONObject(idraftJsonString);
				
				customer_id = IncentiveJson.isNull("customer_id") ? "" : IncentiveJson.getString("customer_id");
				incentiveItem.getIncentive().setCustomer_id(customer_id);
				String CustomerName = IncentiveJson.isNull("customer_name") ? ""	: IncentiveJson.getString("customer_name");
				aq.id(R.id.buttonCustomer).text(CustomerName);
				

				String IncentiveDate = IncentiveJson.isNull("incentive_date") ? ""	: IncentiveJson.getString("incentive_date");
				aq.id(R.id.editTextDateOfIncentive).text(IncentiveDate);
				
				brand_id = IncentiveJson.isNull("brand_id") ? ""	: IncentiveJson.getString("brand_id");
				Brands brands = AppManager.getInstance().getBrands(aq);
				String BrandName = brands.getDepotNameById(brand_id);
				aq.id(R.id.buttonBrand).text(BrandName);
				
				depot_id = IncentiveJson.isNull("depot_id") ? ""	: IncentiveJson.getString("depot_id");
				Depots depots = AppManager.getInstance().getDepots(aq);
				String DepotName = depots.getDepotNameById(depot_id);
				aq.id(R.id.buttonDepot).text(DepotName);
				
				String Unit = IncentiveJson.isNull("unit") ? ""	: IncentiveJson.getString("unit");
				aq.id(R.id.buttonUnit).text(Unit);
				String IncentiveType = IncentiveJson.isNull("incentive_type") ? ""	: IncentiveJson.getString("incentive_type");
				aq.id(R.id.buttonIncentiveType).text(IncentiveType);
				
				String Quantity = IncentiveJson.isNull("quantity") ? ""	: IncentiveJson.getString("quantity");
				aq.id(R.id.editTextQuantity).text(Quantity);
			
	
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	
}
