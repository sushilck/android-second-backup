package com.smalution.y3distributionburf1.fragments;

import android.content.Intent;
import android.support.v4.app.Fragment;

public class SuperFragment  extends Fragment
{
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
		super.onActivityResult(requestCode, resultCode, data);
	}
}
