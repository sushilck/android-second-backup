package com.smalution.y3distributiongh1.fragments.expenses;

import com.androidquery.AQuery;

import com.smalution.y3distributiongh1.R;
import com.smalution.y3distributiongh1.entities.Customer;
import com.smalution.y3distributiongh1.entities.expense.Expense;
import com.smalution.y3distributiongh1.fragments.SuperFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class ExpensesViewFragment extends SuperFragment 
{
	Expense expense;
	View rootView;
	AQuery aq; 
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	expense = args.getParcelable("EXPENSE");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		expense = getArguments().getParcelable("EXPENSE");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.expenses_view_fragment, container, false);
        aq=new AQuery(rootView);
        initUI();
        return rootView;
    }
	private void initUI() 
	{
		aq.id(R.id.textViewUser).text(expense.getUser().getFirst_name()+" "+expense.getUser().getLast_name());
		aq.id(R.id.textViewExpenseAmount).text(expense.getExpense().getExp_amount());
		aq.id(R.id.textViewExpenseType).text(expense.getExpType().getName());
		aq.id(R.id.textViewExpenseDate).text(expense.getExpense().getExp_date());
		aq.id(R.id.textViewExpenseRef).text(expense.getExpense().getExpense_ref());
		aq.id(R.id.textViewCreatedDate).text(expense.getExpense().getCreated());
		aq.id(R.id.textViewSynchronizationData).text(expense.getExpense().getModified());
	}
}
