package com.smalution.y3distributiongh1.entities.distributor;



import java.util.ArrayList;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class DistributorFreeItem implements Parcelable
{
	RedistributorBrand Brand;
	DistributionRdFreeItem RdFreeItem;
	
	public DistributorFreeItem()
	{
		 Brand=new RedistributorBrand();
		 RdFreeItem=new DistributionRdFreeItem();
		
	}
	public DistributorFreeItem(JSONObject jsonObject)
	{
		try
		{
			 Brand=jsonObject.isNull("Brand")?null:new RedistributorBrand(jsonObject.getJSONObject("Brand"));
			 RdFreeItem=jsonObject.isNull("RdFreeItem")?null:new DistributionRdFreeItem(jsonObject.getJSONObject("RdFreeItem"));
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public DistributorFreeItem(JSONObject jsonObject,String json)
	{
		try
		{
			// Brand=jsonObject.isNull("Brand")?null:new RedistributorBrand(jsonObject.getJSONObject("Brand"));
			 RdFreeItem=new DistributionRdFreeItem(jsonObject);
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public DistributorFreeItem(Parcel in)
 	{
		 Brand=in.readParcelable(RedistributorBrand.class.getClassLoader());
		 RdFreeItem=in.readParcelable(DistributionRdFreeItem.class.getClassLoader());
		
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable( Brand,flags);
 		dest.writeParcelable( RdFreeItem,flags);
 		
	}
 	public static final Parcelable.Creator<DistributorFreeItem> CREATOR = new Parcelable.Creator<DistributorFreeItem>() 
 	{
 		public DistributorFreeItem createFromParcel(Parcel in) 
 		{
 			return new DistributorFreeItem(in);
 		}
 	
 		public DistributorFreeItem[] newArray (int size) 
 		{
 			return new DistributorFreeItem[size];
 		}
 	};

	public RedistributorBrand getBrand() {
		return Brand;
	}
	public void setBrand(RedistributorBrand brand) {
		Brand = brand;
	}
	public DistributionRdFreeItem getRdFreeItem() {
		return RdFreeItem;
	}
	public void setRdFreeItem(DistributionRdFreeItem rdFreeItem) {
		RdFreeItem = rdFreeItem;
	}
 	
	
	
	
//	public String createJson(AQuery aq, boolean isForAddCustomer)
//	{
//		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
//		String token = prefs.getString("token", null);
//		if(isForAddCustomer)
//		{
//			String json="{" +
//					"\"token\":\""+token+"\"," +
//					"\"first_name\":\""+getCustomer().getFirst_name()+"\"," +
//					"\"last_name\":\""+getCustomer().getLast_name()+"\"," +
//					"\"email\":\""+getCustomer().getEmail()+"\"," +
//					"\"address\":\""+getCustomer().getAddress()+"\"," +
//					"\"city\":\""+getCustomer().getCity()+"\"," +
//					"\"state_id\":\""+getCustomer().getState_id()+"\"," +
//					"\"latitude\":\""+getCustomer().getLatitude()+"\"," +
//					"\"longitude\":\""+getCustomer().getLongitude()+"\"," +
//					"\"zipcode\":\""+getCustomer().getZipcode()+"\"," +
//					"\"phone\":\""+getCustomer().getPhone()+"\"," +
//					"\"region_id\":\""+getCustomer().getRegion_id()+"\"," +
//					"\"depot_id\":\""+getCustomer().getDepot_id()+"\"," +
//					"\"lg_area_id\":\""+getCustomer().getLg_area_id()+"\"," +
//					"\"description\":\""+getCustomer().getDescription()+"\"," +
//					"\"view_details\":\""+getCustomer().getView_details()+"\"" +
//					"}";
//			return json;
//		}
//		else
//		{
//			String json="{" +
//					"\"token\":\""+token+"\"," +
//					"\"id\":\""+getCustomer().getId()+"\"," +
//					"\"oldFile_id\":\""+getCustomer().getFile_id()+"\"," +
//					"\"first_name\":\""+getCustomer().getFirst_name()+"\"," +
//					"\"last_name\":\""+getCustomer().getLast_name()+"\"," +
//					"\"email\":\""+getCustomer().getEmail()+"\"," +
//					"\"address\":\""+getCustomer().getAddress()+"\"," +
//					"\"city\":\""+getCustomer().getCity()+"\"," +
//					"\"state_id\":\""+getCustomer().getState_id()+"\"," +
//					"\"latitude\":\""+getCustomer().getLatitude()+"\"," +
//					"\"longitude\":\""+getCustomer().getLongitude()+"\"," +
//					"\"zipcode\":\""+getCustomer().getZipcode()+"\"," +
//					"\"phone\":\""+getCustomer().getPhone()+"\"," +
//					"\"region_id\":\""+getCustomer().getRegion_id()+"\"," +
//					"\"depot_id\":\""+getCustomer().getDepot_id()+"\"," +
//					"\"lg_area_id\":\""+getCustomer().getLg_area_id()+"\"," +
//					"\"description\":\""+getCustomer().getDescription()+"\"," +
//					"\"view_details\":\""+getCustomer().getView_details()+"\"" +
//					"}";
//			return json;
//		}
//		
//		
//	}
 	
 	
}
