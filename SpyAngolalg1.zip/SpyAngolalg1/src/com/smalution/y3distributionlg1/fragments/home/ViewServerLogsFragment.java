package com.smalution.y3distributionlg1.fragments.home;

import com.smalution.y3distributionlg1.R;
import com.smalution.y3distributionlg1.database.ServerLog;
import com.smalution.y3distributionlg1.database.Y3QueryDataSource;
import com.smalution.y3distributionlg1.fragments.SuperFragment;

import java.util.ArrayList;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.androidquery.AQuery;
public class ViewServerLogsFragment extends SuperFragment 
{
	ListView customerList;
	ArrayAdapter<ServerLog> adapter;
	ArrayList<ServerLog> expenseArrayList=new ArrayList<ServerLog>();
	View rootView;
	AQuery aq;
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
//	        	expense= args.getParcelable("EXPENSE");
	        }
	    });
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.view_serverlogs_fragment, container, false);
        aq=new AQuery(rootView);
        expenseArrayList.clear();
        initUI();
        new ServerLogAsyncTask(aq).execute();
        return rootView;
    }
	private void initUI()
	{
		adapter = new ArrayAdapter<ServerLog>(this.getActivity(), R.layout.server_log_listitem, expenseArrayList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.server_log_listitem, parent, false);
	            }
                final ServerLog log = getItem(position);
                AQuery aql = new AQuery(convertView);
                aql.id(R.id.textViewQuery).text(""+log.getAction());
                aql.id(R.id.textViewStatus).text(log.getStatus());
                aql.id(R.id.textViewServerResponse).text(log.getServerlog());
                return convertView;
	        }
		};
		aq.id(R.id.customerList).adapter(adapter);
		aq.id(R.id.customerList).itemClicked(new OnItemClickListener() 
		{
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int position,long arg3) 
			{
				FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
				FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
				Fragment fragment = fragmentManager.findFragmentByTag("ViewServerLogDetailFragment");
				Bundle bundle=new Bundle();
				bundle.putParcelable("LOG", expenseArrayList.get(position));
				if(fragment==null)
				{
					fragment=new ViewServerLogDetailFragment();
					fragment.setArguments(bundle);
					fragmentTransaction.addToBackStack("ViewServerLogDetailFragment");
				}
				else
				{
					((ViewServerLogDetailFragment)fragment).setUIArguments(bundle);
				}
				fragmentTransaction.replace(R.id.frame_container, fragment, "ViewServerLogDetailFragment");
				fragmentTransaction.commit();
			}
		});
	}
	private class ServerLogAsyncTask extends AsyncTask<Void, Void, ArrayList<ServerLog>>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		public ServerLogAsyncTask(AQuery aq)
		{
			this.aq=aq;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected ArrayList<ServerLog> doInBackground(Void... params) 
		{
			Y3QueryDataSource datasource = new Y3QueryDataSource(aq.getContext());
		    datasource.open();
		    ArrayList<ServerLog> result = datasource.getServerLogs();
		    datasource.close();
			return result;
		}
		@Override
		protected void onPostExecute(ArrayList<ServerLog> result) 
		{
			super.onPostExecute(result);
			if(result!=null && adapter!=null)
			{
				if(result.size()>0)
				{
					expenseArrayList.addAll(result);
					adapter.notifyDataSetChanged();
				}
				else
				{
					adapter.notifyDataSetChanged();
				}
			}
			else
			{
				Toast.makeText(aq.getContext(), R.string.no_pquery, Toast.LENGTH_SHORT).show();
			}
			progressDialog.dismiss();
		}
	}
}
