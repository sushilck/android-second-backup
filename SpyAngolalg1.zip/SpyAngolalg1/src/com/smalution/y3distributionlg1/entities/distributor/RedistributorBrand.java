package com.smalution.y3distributionlg1.entities.distributor;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class RedistributorBrand implements Parcelable
{
	private String name;
	
	public RedistributorBrand(){}
	public RedistributorBrand(JSONObject jsonObect)
	{
		try
		{
			name=jsonObect.isNull("name")?"":jsonObect.getString("name");
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public RedistributorBrand(Parcel in)
 	{
		name = in.readString();
		
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(name);
 		
 	}
 	public static final Parcelable.Creator<RedistributorBrand> CREATOR = new Parcelable.Creator<RedistributorBrand>() 
 	{
 		public RedistributorBrand createFromParcel(Parcel in) 
 		{
 			return new RedistributorBrand(in);
 		}
 	
 		public RedistributorBrand[] newArray (int size) 
 		{
 			return new RedistributorBrand[size];
 		}
 	};

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
