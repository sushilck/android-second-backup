package com.smalution.y3distributiondr1.fragments.incentive;

import com.smalution.y3distributiondr1.AppManager;
import com.smalution.y3distributiondr1.R;
import com.smalution.y3distributiondr1.SendDataToServerAsyncTask;
import com.smalution.y3distributiondr1.Utils;
import com.smalution.y3distributiondr1.database.MySQLiteHelper;
import com.smalution.y3distributiondr1.database.Y3Query;
import com.smalution.y3distributiondr1.database.Y3QueryDataSource;
import com.smalution.y3distributiondr1.entities.customer.Customer;
import com.smalution.y3distributiondr1.entities.incentive.IncentiveItem;
import com.smalution.y3distributiondr1.fragments.SuperFragment;
import com.smalution.y3distributiondr1.quickaction.ActionItem;
import com.smalution.y3distributiondr1.quickaction.QuickAction;
import com.smalution.y3distributiondr1.utils.AppConstant;
import com.smalution.y3distributiondr1.entities.settings.ParseListItems;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.androidquery.AQuery;

public class IncentiveDisplayFragment extends SuperFragment 
{
	ListView customerList;
	ArrayAdapter<IncentiveItem> adapter;
	ArrayList<IncentiveItem> paymentArrayList=new ArrayList<IncentiveItem>();
	View rootView;
	AQuery aq; 
	int pageCount=0;
	View foolterLoadMoreView;
	AQuery aqf;
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.incentive_display_fragment, container, false);
        aq=new AQuery(rootView);
        pageCount=0;
        paymentArrayList.clear();
        initUI(true);
        
        initApplication();
        return rootView;
    }
	private void initApplication() {
		if(AppManager.isOnline(getActivity())){
			//new DeletePaymentfromServer().execute();
			new PaymentsListAsyncTask(aq).execute();
			
			
		} else {
		paymentArrayList.clear();
		
		fillLIstView();

	}
		
	}
	private void fillLIstView() {
		Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		datasource.open();
		// pageCount = 1;
		paymentArrayList.clear();
		ArrayList<IncentiveItem> result = datasource.getAllIncentivegQueries();

		if (result.size() > 0) {
			paymentArrayList.addAll(result);

		}
		initUI(false);
		
	}
	private void initUI(boolean addFooter) 
	{
		aq.id(R.id.buttonRefresh).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(AppManager.isOnline(getActivity())){
				pageCount=0;
		        paymentArrayList.clear();
		        initUI(false);
		        new PaymentsListAsyncTask(aq).execute();
				}
			}
		});
		aq.id(R.id.buttonAddNewPayment).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
				FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
				Fragment fragment = fragmentManager.findFragmentByTag("IncentiveAddFragment");
				Bundle bundle=new Bundle();
				if(fragment==null)
				{
					fragment=new IncentiveAddFragment();
					fragment.setArguments(bundle);
					fragmentTransaction.addToBackStack("IncentiveAddFragment");
				}
				else
				{
					((IncentiveAddFragment)fragment).setUIArguments(bundle);
				}
				fragmentTransaction.replace(R.id.frame_container, fragment, "IncentiveAddFragment");
				fragmentTransaction.commit();
			}
		});
		adapter = new ArrayAdapter<IncentiveItem>(this.getActivity(), R.layout.incentive_display_listitem, paymentArrayList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.incentive_display_listitem, parent, false);
	            }
                final IncentiveItem incentive = getItem(position);
                AQuery aql = new AQuery(convertView);
                position=position+1;
                aql.id(R.id.textViewSerialNo).text(""+position);
                aql.id(R.id.textViewCustomer).text(incentive.getCustomer().getFname()+" "+incentive.getCustomer().getLname());
                //aql.id(R.id.textViewUnit).text(incentive.getIncentive().getUnit());
                ParseListItems unitlist = AppManager.getInstance().getParseItems(aq, "unit");    				
    			if(unitlist != null){
    				String unitName = unitlist.getItemNameById(incentive.getIncentive().getUnit());
    				aql.id(R.id.textViewUnit).text(unitName);
    			}
                aql.id(R.id.textViewQuantity).text(incentive.getIncentive().getQuantity());
                final int pos=position;
                aql.id(R.id.quickActionParent1).clicked(new OnClickListener() 
                {
					@Override
					public void onClick(View v) 
					{
						showQuickActionPopup(v, incentive,pos);
					}
				});
	            return convertView;
	        }
		};
		if(pageCount==0 && addFooter)
		{
			foolterLoadMoreView=LayoutInflater.from(getActivity()).inflate(R.layout.load_more_list_footer, null);
			aqf=new AQuery(foolterLoadMoreView);
			aqf.id(R.id.buttonLoadMoreListItems).clicked(new OnClickListener() 
			{
				@Override
				public void onClick(View v) 
				{
					if(AppManager.isOnline(getActivity()))
						
					{
					new PaymentsListAsyncTask(aq).execute();
					}
				}
			});
			aq.id(R.id.customerList).getListView().addFooterView(foolterLoadMoreView, null, true);
		}
		aq.id(R.id.customerList).getListView().setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
		aq.id(R.id.customerList).adapter(adapter);
		adapter.registerDataSetObserver(new DataSetObserver() 
		{
		    @Override
		    public void onChanged() 
		    {
		        super.onChanged();
		        if(pageCount==1)
		        {
		        	aq.id(R.id.customerList).getListView().setSelection(0);
		        }
		        else
		        {
		        	aq.id(R.id.customerList).getListView().setSelection(adapter.getCount() - 1);
		        }    
		    }
		});
	}
	private void showQuickActionPopup(View anchorView, final IncentiveItem incentive,final int position)
	{
		ActionItem viewAction = new ActionItem();
		viewAction.setTitle(getString(R.string.view));
		viewAction.setIcon(getResources().getDrawable(R.drawable.icon_view));
		
		ActionItem addAction = new ActionItem();
		addAction.setTitle(getString(R.string.edit));
		addAction.setIcon(getResources().getDrawable(R.drawable.icon_edit));
		
		// Upload action item
		ActionItem deleteAction = new ActionItem();
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		int grade = prefs.getInt("grade", -1);
		if(grade!=-1 && (grade==1 || grade==3))
		{
		deleteAction.setTitle(getString(R.string.delete));
		deleteAction.setIcon(getResources().getDrawable(R.drawable.icon_delete));
		}

		final QuickAction mQuickAction = new QuickAction(getActivity());

		mQuickAction.addActionItem(viewAction);
		mQuickAction.addActionItem(addAction);
		mQuickAction.addActionItem(deleteAction);
		mQuickAction.setOnActionItemClickListener(new QuickAction.OnActionItemClickListener() 
		{
			public void onItemClick(int pos) 
			{
				if (pos == 0) 
				{ 
					FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
					FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
					Fragment fragment = fragmentManager.findFragmentByTag("IncentiveViewFragment");
					Bundle bundle=new Bundle();
					bundle.putParcelable("PAYMENT", incentive);
					if(fragment==null)
					{
						fragment=new IncentiveViewFragment();
						fragment.setArguments(bundle);
						fragmentTransaction.addToBackStack("IncentiveViewFragment");
					}
					else
					{
						((IncentiveViewFragment)fragment).setUIArguments(bundle);
					}
					fragmentTransaction.replace(R.id.frame_container, fragment, "IncentiveViewFragment");
					fragmentTransaction.commit();
				} 
				else if (pos == 1) 
				{ 
					FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
					FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
					Fragment fragment = fragmentManager.findFragmentByTag("IncentiveEditFragment");
					Bundle bundle=new Bundle();
					bundle.putParcelable("PAYMENT", incentive);
					if(fragment==null)
					{
						fragment=new IncentiveEditFragment();
						fragment.setArguments(bundle);
						fragmentTransaction.addToBackStack("IncentiveEditFragment");
					}
					else
					{
						((IncentiveEditFragment)fragment).setUIArguments(bundle);
					}
					fragmentTransaction.replace(R.id.frame_container, fragment, "IncentiveEditFragment");
					fragmentTransaction.commit();
				} 
				else if (pos == 2) 
				{ 
					SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
					String token = prefs.getString("token", null);
				   final String jsonString="{\"token\":\""+token+"\",\"incentive_id\":\""+incentive.getIncentive().getId()+"\"}";
				    
				    //AppConstant.JSONGSTRING=jsonString;
				    AppConstant.DELETE_ID=incentive.getIncentive().getId();
				    AppConstant.OPTION_MODE="INCENTIVE";
				    
				    if (AppManager.isOnline(getActivity())) {
				    	
				    	SendDataToServerAsyncTask<IncentiveItem> deletor = new SendDataToServerAsyncTask<IncentiveItem>(
					    		getActivity(), 
					    		jsonString,
					    		null, 
					    		AppManager.getInstance().URL_DELETE_INCENTIVE,
					    		getString(R.string.incentive_deleted),
					    		false,
					    		adapter,
					    		paymentArrayList,
					    		position,"");//.execute();
					    AppManager.getInstance().showDeleteConfDialog(getActivity(),deletor);
				    }
				    else{
				    	AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
								getActivity());
						alertDialogBuilder.setTitle(getString(R.string.warning));
						alertDialogBuilder
								.setMessage(getString(R.string.incentive_deleted))
								.setCancelable(false)
								.setPositiveButton(
										getString(R.string.yes),
										new DialogInterface.OnClickListener() {
											public void onClick(
													DialogInterface dialog,
													int id) {
												Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
												datasource.open();
												
												long result = datasource.addY3Query(Y3QueryDataSource.ACTION_INCENTIVE_DELETE,jsonString,null);									 
												if (result != -1) {
													if (datasource.deleteIncentiveSingleRow(incentive.getIncentive().getId()))
													{
														
														Toast.makeText(getActivity(),getString(R.string.incentive_deleted),Toast.LENGTH_SHORT).show();														
														paymentArrayList.clear();
														fillLIstView();
													}
												}					
												
												datasource.close();

											}
										})
								.setNegativeButton(
										getString(R.string.no),
										new DialogInterface.OnClickListener() {
											public void onClick(
													DialogInterface dialog,
													int id) {
												dialog.cancel();
											}
										});
						AlertDialog alertDialog = alertDialogBuilder
								.create();
						alertDialog.show(); 	
				    	
				    }
				    
				   
				    
				} 
			}
		});
		mQuickAction.show(anchorView);
		mQuickAction.setAnimStyle(QuickAction.ANIM_GROW_FROM_CENTER);
	}
	private class PaymentsListAsyncTask extends AsyncTask<Void, Void, ArrayList<IncentiveItem>>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		public PaymentsListAsyncTask(AQuery aq)
		{
			this.aq=aq;
			pageCount=pageCount+1;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			if(getActivity()==null){
				progressDialog = new ProgressDialog(aq.getContext());
			}
			else{
				progressDialog = new ProgressDialog(getActivity());
			}
			progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected ArrayList<IncentiveItem> doInBackground(Void... params) 
		{
			if(AppManager.getInstance().isOnline(aq.getContext()))
			{
				return AppManager.getInstance().getIncentiveList(aq, pageCount);
			}
			return null;
		}
		@Override
		protected void onPostExecute(ArrayList<IncentiveItem> result) 
		{
			super.onPostExecute(result);
			if(result!=null && adapter!=null)
			{
				if(result.size()>0)
				{
					paymentArrayList.addAll(result);
					adapter.notifyDataSetChanged();
					aqf.id(R.id.buttonLoadMoreListItems).visible();
					if(result.size()<20)
					{
						aqf.id(R.id.buttonLoadMoreListItems).invisible();
					}
				}
				else
				{
					if(pageCount==1)
					{
						Toast.makeText(getActivity(), getString(R.string.no_data), Toast.LENGTH_SHORT).show();
					}
					adapter.notifyDataSetChanged();
					aqf.id(R.id.buttonLoadMoreListItems).invisible();
				}
			}
			else
			{
				Toast.makeText(aq.getContext(), getString(R.string.no_data), Toast.LENGTH_SHORT).show();
			}
			
			progressDialog.dismiss();
		}
	}
	
	private class DeletePaymentfromServer extends	AsyncTask<Void, Void, ArrayList<Customer>> {

		ProgressDialog progressDialog;
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			if(getActivity()==null){
				progressDialog = new ProgressDialog(aq.getContext());
			}
			else{
				progressDialog = new ProgressDialog(getActivity());
			}
			progressDialog.setMessage(getString(R.string.wait_progress));
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(true);
			progressDialog.show();
			progressDialog
					.setOnKeyListener(new DialogInterface.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog,
								int keyCode, KeyEvent event) {
							return false;
						}
					});
		}

		@Override
		protected ArrayList<Customer> doInBackground(Void... params1) {
			
		// this is for add incentive to server.......................
			
			
			
			

			return null;
		}

		@Override
		protected void onPostExecute(ArrayList<Customer> result) {

			progressDialog.dismiss();
			
		}
		}
}
