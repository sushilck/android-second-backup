package com.smalution.y3distributiondr1.entities.distributor;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class DistCustomer implements Parcelable
{
	private String last_name;
	private String id;
	private String first_name;
	public DistCustomer(){}
	public DistCustomer(JSONObject jsonObect)
	{
		try
		{
			last_name=jsonObect.isNull("last_name")?"":jsonObect.getString("last_name");
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			first_name=jsonObect.isNull("first_name")?"":jsonObect.getString("first_name");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public DistCustomer(Parcel in)
 	{
		last_name = in.readString();
		id = in.readString();
		first_name = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(last_name);
 		dest.writeString(id);
 		dest.writeString(first_name);
 	}
 	public static final Parcelable.Creator<DistCustomer> CREATOR = new Parcelable.Creator<DistCustomer>() 
 	{
 		public DistCustomer createFromParcel(Parcel in) 
 		{
 			return new DistCustomer(in);
 		}
 	
 		public DistCustomer[] newArray (int size) 
 		{
 			return new DistCustomer[size];
 		}
 	};
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
 	
}
