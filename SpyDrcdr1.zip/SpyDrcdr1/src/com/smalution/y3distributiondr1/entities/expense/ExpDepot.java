package com.smalution.y3distributiondr1.entities.expense;


import org.json.JSONObject;

import com.smalution.y3distributiondr1.entities.Expense;

import android.os.Parcel;
import android.os.Parcelable;

public class ExpDepot implements Parcelable
{
	private String id;
	private String title;
	public ExpDepot(){}
	public ExpDepot(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			title=jsonObect.isNull("title")?"":jsonObect.getString("title");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public ExpDepot(Parcel in)
 	{
		id = in.readString();
		title = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(title);
	}
 	public static final Parcelable.Creator<ExpDepot> CREATOR = new Parcelable.Creator<ExpDepot>() 
 	{
 		public ExpDepot createFromParcel(Parcel in) 
 		{
 			return new ExpDepot(in);
 		}
 	
 		public ExpDepot[] newArray (int size) 
 		{
 			return new ExpDepot[size];
 		}
 	};
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
}
