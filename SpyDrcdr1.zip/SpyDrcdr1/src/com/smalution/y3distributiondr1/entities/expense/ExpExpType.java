package com.smalution.y3distributiondr1.entities.expense;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class ExpExpType implements Parcelable
{
	private String id;
    private String category_id;
    private String name;
    
    public ExpExpType(){}
	public ExpExpType(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
		    category_id=jsonObect.isNull("category_id")?"":jsonObect.getString("category_id");
		    name=jsonObect.isNull("name")?"":jsonObect.getString("name");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public ExpExpType(Parcel in)
 	{
	    id = in.readString();
	    category_id = in.readString();
	    name = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 	    dest.writeString(category_id);
 	    dest.writeString(name);
 	}
 	public static final Parcelable.Creator<ExpExpType> CREATOR = new Parcelable.Creator<ExpExpType>() 
 	{
 		public ExpExpType createFromParcel(Parcel in) 
 		{
 			return new ExpExpType(in);
 		}
 	
 		public ExpExpType[] newArray (int size) 
 		{
 			return new ExpExpType[size];
 		}
 	};

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCategory_id() {
		return category_id;
	}
	public void setCategory_id(String category_id) {
		this.category_id = category_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
