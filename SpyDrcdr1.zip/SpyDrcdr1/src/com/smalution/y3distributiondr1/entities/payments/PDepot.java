package com.smalution.y3distributiondr1.entities.payments;


import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class PDepot implements Parcelable
{
	private String id;
	private String title;
	public PDepot(){}
	public PDepot(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			title=jsonObect.isNull("title")?"":jsonObect.getString("title");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public PDepot(Parcel in)
 	{
		id = in.readString();
		title = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(title);
	}
 	public static final Parcelable.Creator<PDepot> CREATOR = new Parcelable.Creator<PDepot>() 
 	{
 		public PDepot createFromParcel(Parcel in) 
 		{
 			return new PDepot(in);
 		}
 	
 		public PDepot[] newArray (int size) 
 		{
 			return new PDepot[size];
 		}
 	};
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
}
