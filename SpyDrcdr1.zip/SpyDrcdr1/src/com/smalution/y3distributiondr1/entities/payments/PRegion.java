package com.smalution.y3distributiondr1.entities.payments;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class PRegion implements Parcelable
{
	private String id;
	private String title;
	public PRegion(){}
	public PRegion(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			title=jsonObect.isNull("title")?"":jsonObect.getString("title");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public PRegion(Parcel in)
 	{
		id = in.readString();
		title = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(title);
	}
 	public static final Parcelable.Creator<PRegion> CREATOR = new Parcelable.Creator<PRegion>() 
 	{
 		public PRegion createFromParcel(Parcel in) 
 		{
 			return new PRegion(in);
 		}
 	
 		public PRegion[] newArray (int size) 
 		{
 			return new PRegion[size];
 		}
 	};
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
}
