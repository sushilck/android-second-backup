package com.smalution.y3distributiondr1.entities.incentive;


import org.json.JSONObject;

import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

import com.androidquery.AQuery;
import com.smalution.y3distributiondr1.AppManager;
import com.smalution.y3distributiondr1.utils.AppConstant;

public class IncentiveItem  implements Parcelable
{
	IncIncentive Incentive;
	IncUser User;
	IncBrand Brand;
	IncDepot Depot;
	IncCustomer Customer;
	String offlineCustomerJSON;
	int sno;
	public IncentiveItem()
	{
		Incentive=new IncIncentive();
		User=new IncUser();
		Brand=new IncBrand();
		Depot=new IncDepot();
		Customer=new IncCustomer();
		
	}
	public IncentiveItem(JSONObject jsonObject)
	{
		try
		{
			Incentive=jsonObject.isNull("Incentive")?null:new IncIncentive(jsonObject.getJSONObject("Incentive"));
			User=jsonObject.isNull("User")?null:new IncUser(jsonObject.getJSONObject("User"));
			Brand=jsonObject.isNull("Brand")?null:new IncBrand(jsonObject.getJSONObject("Brand"));
			Depot=jsonObject.isNull("Depot")?null:new IncDepot(jsonObject.getJSONObject("Depot"));
			Customer=jsonObject.isNull("Customer")?null:new IncCustomer(jsonObject.getJSONObject("Customer"));
			sno=jsonObject.isNull("sno")?0:jsonObject.getInt("sno");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public IncentiveItem(Parcel in)
 	{
		Incentive=in.readParcelable(IncIncentive.class.getClassLoader());
		User=in.readParcelable(IncUser.class.getClassLoader());
		Brand=in.readParcelable(IncBrand.class.getClassLoader());
		Depot=in.readParcelable(IncDepot.class.getClassLoader());
		Customer=in.readParcelable(IncCustomer.class.getClassLoader());
		sno=in.readInt();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable(Incentive,flags);
 		dest.writeParcelable(User,flags);
 		dest.writeParcelable(Brand,flags);
 		dest.writeParcelable(Depot,flags);
 		dest.writeParcelable(Customer,flags);
 		dest.writeInt(sno);
	}
 	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public static final Parcelable.Creator<IncentiveItem> CREATOR = new Parcelable.Creator<IncentiveItem>() 
 	{
 		public IncentiveItem createFromParcel(Parcel in) 
 		{
 			return new IncentiveItem(in);
 		}
 	
 		public IncentiveItem[] newArray (int size) 
 		{
 			return new IncentiveItem[size];
 		}
 	};

	public IncIncentive getIncentive() {
		return Incentive;
	}
	public void setIncentive(IncIncentive incentive) {
		Incentive = incentive;
	}
	public IncUser getUser() {
		return User;
	}
	public void setUser(IncUser user) {
		User = user;
	}
	public IncBrand getBrand() {
		return Brand;
	}
	public void setBrand(IncBrand brand) {
		Brand = brand;
	}
	public IncDepot getDepot() {
		return Depot;
	}
	public void setDepot(IncDepot depot) {
		Depot = depot;
	}
	public IncCustomer getCustomer() {
		return Customer;
	}
	public void setCustomer(IncCustomer customer) {
		Customer = customer;
	}

	public String createJson(AQuery aq, boolean isForEditCustomer,boolean isOnline)
	{
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		String token = prefs.getString("token", null);
		String json="{" +
			"\"token\":\""+token+"\",";
		if(isForEditCustomer)
		{
			json=json+"\"incentive_id\":\""+getIncentive().getId()+"\",";
		}
		else
		{
			json=json+"\"request_id\":\""+AppConstant.ANDROIDDEVICEID + AppConstant.getRequestId()+"\"," + "\"created\":\""+AppConstant.getCurrentDateAndTime()+"\"," ;
		}
			
		json=json+"\"customer_id\":\""+getCustomer().getId()+"\"," +
			"\"customer_name\":\""+getCustomer().getFname()+"\"," +
			"\"incentive_date\":\""+getIncentive().getIncentive_date()+"\"," +				
			"\"brand_id\":\""+getBrand().getId()+"\"," +
			"\"depot_id\":\""+getDepot().getId()+"\"," +
			"\"incentive_type\":\""+getIncentive().getIncentive_type()+"\"," +
			"\"unit\":\""+getIncentive().getUnit()+"\"," +
			"\"quantity\":\""+getIncentive().getQuantity()+"\"";
		if(!isOnline)
		{
			json=json+",";
			json=json+"\"newCustomer\":" ;
			json=json+getOfflineCustomerJSON();		
			json=json+"}";
		}
		else
		{
			json=json+"}";
		}
		return json;
	}
	public String getOfflineCustomerJSON() {
		return offlineCustomerJSON;
	}
	public void setOfflineCustomerJSON(String offlineCustomerJSON) {
		this.offlineCustomerJSON = offlineCustomerJSON;
	}
 	
 	
}