package com.smalution.y3distributiong1.fragments.customervisit;
import com.smalution.y3distributiong1.AppManager;
import com.smalution.y3distributiong1.R;
import com.smalution.y3distributiong1.SendDataToServerAsyncTask;
import com.smalution.y3distributiong1.Utils;
import com.smalution.y3distributiong1.database.MySQLiteHelper;
import com.smalution.y3distributiong1.database.Y3Query;
import com.smalution.y3distributiong1.database.Y3QueryDataSource;
import com.smalution.y3distributiong1.entities.customer.Customer;
import com.smalution.y3distributiong1.entities.customervisits.CustomerVisit;
import com.smalution.y3distributiong1.fragments.SuperFragment;
import com.smalution.y3distributiong1.quickaction.ActionItem;
import com.smalution.y3distributiong1.quickaction.QuickAction;
import com.smalution.y3distributiong1.utils.AppConstant;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.androidquery.AQuery;

public class CustomerVisitDisplayFragment extends SuperFragment 
{
	
	ListView customerList;
	ArrayAdapter<CustomerVisit> adapter;
	ArrayList<CustomerVisit> customerArrayList=new ArrayList<CustomerVisit>();
	View rootView;
	AQuery aq; 
	int pageCount=0;
	View foolterLoadMoreView;
	AQuery aqf;
	public static String jsonString;
	
	
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.customer_visit_display_fragment, container, false);
        aq=new AQuery(rootView);
        
        pageCount=0;        
        customerArrayList.clear();
        initUI(true);        
        initApplication();
        return rootView;
    }
	
	
	private void initApplication() {
		AppConstant. JSONGSTRING=null;
		AppConstant.DELETE_ID=null;
		AppConstant. LOADFILLLISTVIEW=false;		
		AppConstant. OPTION_MODE=null;
		if (AppManager.isOnline(getActivity())) {
			// this is for online operation...... in application.
			//new DeleteCustomerfromServer().execute();
			new CustomersVisitsListAsyncTask(aq).execute();
			//new ShowCustomerDataFromDatabase().execute();			

		} else {
			customerArrayList.clear();			
			fillLIstView();

		}
		
	}
private void fillLIstView() {
		
		Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		datasource.open();
		// pageCount = 1;
		customerArrayList.clear();
		ArrayList<CustomerVisit> result = datasource.getAllCustomerVisitingQueries();

		if (result.size() > 0) {
			customerArrayList.addAll(result);

		}
		datasource.close();
		initUI(false);
		
	}


	private void initUI(boolean addFooter) 
	{
		aq.id(R.id.buttonRefresh).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				
				if(AppManager.isOnline(getActivity()))
				{
					aq=new AQuery(rootView);
			        pageCount=0;
			        customerArrayList.clear();
			        initUI(false);
			        new CustomersVisitsListAsyncTask(aq).execute();
				}
				
				
				
			}
		});
		aq.id(R.id.buttonAddNewCustomerVisit).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
				FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
				Fragment fragment = fragmentManager.findFragmentByTag("CustomerVisitAddFragment");
				Bundle bundle=new Bundle();
				//bundle.putParcelable("CUSTOMER", customerVisit);
				if(fragment==null)
				{
					fragment=new CustomerVisitAddFragment();
					fragment.setArguments(bundle);
					fragmentTransaction.addToBackStack("CustomerVisitAddFragment");
				}
				else
				{
					((CustomerVisitAddFragment)fragment).setUIArguments(bundle);
				}
				fragmentTransaction.replace(R.id.frame_container, fragment, "CustomerVisitAddFragment");
				fragmentTransaction.commit();
			}
		});
		adapter = new ArrayAdapter<CustomerVisit>(this.getActivity(), R.layout.customer_visit_display_listitem, customerArrayList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.customer_visit_display_listitem, parent, false);
	            }
                final CustomerVisit customerVisit = getItem(position);
                AQuery aql = new AQuery(convertView);
                position =position+1;
                aql.id(R.id.textViewSerialNo).text(""+position);
                aql.id(R.id.textViewUser).text(customerVisit.getUser().getFirst_name()+" "+customerVisit.getUser().getLast_name());
                aql.id(R.id.textViewCustomer).text(customerVisit.getCustomer().getFirst_name()+" "+customerVisit.getCustomer().getLast_name());
                aql.id(R.id.textViewVisitingTime).text(customerVisit.getCustomerVisit().getVisiting_date());
                final int pos=position;
                aql.id(R.id.quickActionParentLayout).clicked(new OnClickListener() 
                {
					@Override
					public void onClick(View v) 
					{
						showQuickActionPopup(v, customerVisit,pos);
					}
				});
	            return convertView;
	        }
		};
		if(pageCount==0 && addFooter)
		{
			foolterLoadMoreView=LayoutInflater.from(getActivity()).inflate(R.layout.load_more_list_footer, null);
			aqf=new AQuery(foolterLoadMoreView);
			aqf.id(R.id.buttonLoadMoreListItems).clicked(new OnClickListener() 
			{
				@Override
				public void onClick(View v) 
				{
					if(AppManager.isOnline(getActivity()))
					{
					//customerArrayList.clear();
					new CustomersVisitsListAsyncTask(aq).execute();
					}
				}
			});
			aq.id(R.id.customerList).getListView().addFooterView(foolterLoadMoreView, null, true);
		}
		aq.id(R.id.customerList).getListView().setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
		aq.id(R.id.customerList).adapter(adapter);
		adapter.registerDataSetObserver(new DataSetObserver() 
		{
		    @Override
		    public void onChanged() 
		    {
		        super.onChanged();
		        if(pageCount==1)
		        {
		        	aq.id(R.id.customerList).getListView().setSelection(0);
		        }
		        else
		        {
		        	aq.id(R.id.customerList).getListView().setSelection(adapter.getCount() - 1);
		        }   
		    }
		});
	}
	private void showQuickActionPopup(View anchorView, final CustomerVisit customerVisit, final int position)
	{
		ActionItem viewAction = new ActionItem();
		viewAction.setTitle(getString(R.string.view));
		viewAction.setIcon(getResources().getDrawable(R.drawable.icon_view));
		
		ActionItem editAction = new ActionItem();
		editAction.setTitle(getString(R.string.edit));
		editAction.setIcon(getResources().getDrawable(R.drawable.icon_edit));

		// Upload action item
		ActionItem deleteAction = new ActionItem();
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		int grade = prefs.getInt("grade", -1);
		if(grade!=-1 && (grade==1 || grade==3))
		{
		deleteAction.setTitle(getString(R.string.delete));
		deleteAction.setIcon(getResources().getDrawable(R.drawable.icon_delete));
		}

		final QuickAction mQuickAction = new QuickAction(getActivity());

		mQuickAction.addActionItem(viewAction);
		mQuickAction.addActionItem(editAction);
		mQuickAction.addActionItem(deleteAction);
		mQuickAction.setOnActionItemClickListener(new QuickAction.OnActionItemClickListener() 
		{
			public void onItemClick(int pos) 
			{
				if (pos == 0) 
				{ 
					FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
					FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
					Fragment fragment = fragmentManager.findFragmentByTag("CustomerVisitViewFragment");
					Bundle bundle=new Bundle();
					bundle.putParcelable("CUSTOMERVISIT", customerVisit);
					if(fragment==null)
					{
						fragment=new CustomerVisitViewFragment();
						fragment.setArguments(bundle);
						fragmentTransaction.addToBackStack("CustomerVisitViewFragment");
					}
					else
					{
						((CustomerVisitViewFragment)fragment).setUIArguments(bundle);
					}
					fragmentTransaction.replace(R.id.frame_container, fragment, "CustomerVisitViewFragment");
					fragmentTransaction.commit();
				}
				else if (pos == 1) 
				{ 
					FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
					FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
					Fragment fragment = fragmentManager.findFragmentByTag("CustomerVisitEditFragment");
					Bundle bundle=new Bundle();
					bundle.putParcelable("CUSTOMER", customerVisit);
					if(fragment==null)
					{
						fragment=new CustomerVisitEditFragment();
						fragment.setArguments(bundle);
						fragmentTransaction.addToBackStack("CustomerVisitEditFragment");
					}
					else
					{
						((CustomerVisitEditFragment)fragment).setUIArguments(bundle);
					}
					fragmentTransaction.replace(R.id.frame_container, fragment, "CustomerVisitEditFragment");
					fragmentTransaction.commit();
				} 
				else if (pos == 2) 
				{ 
					SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
					String token = prefs.getString("token", null);
				     jsonString="{\"token\":\""+token+"\",\"visit_id\":\""+customerVisit.getCustomerVisit().getId()+"\"}";
				    
				   // AppConstant.JSONGSTRING=jsonString;
				    AppConstant.DELETE_ID=customerVisit.getCustomerVisit().getId();
				    AppConstant.OPTION_MODE="CUSTOMERVISIT";
				    
				    if(AppManager.isOnline(getActivity())){
				    	  SendDataToServerAsyncTask<CustomerVisit> deletor = new SendDataToServerAsyncTask<CustomerVisit>(
									getActivity(), 
									jsonString,
									null, 
									AppManager.getInstance().URL_DELETE_CUSTOMERVISITS,
									getString(R.string.customer_visit_deleted),
									false,
									adapter,
									customerArrayList,
									position,"");//.execute();
							AppManager.getInstance().showDeleteConfDialog(getActivity(),deletor);
				    	
				    }
				    else{
				    	
				    	AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
								getActivity());
						alertDialogBuilder.setTitle(getString(R.string.warning));
						alertDialogBuilder
								.setMessage(getString(R.string.confirm_delete))
								.setCancelable(false)
								.setPositiveButton(
										getString(R.string.yes),
										new DialogInterface.OnClickListener() {
											public void onClick(
													DialogInterface dialog,
													int id) {
												Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
												datasource.open();												
												long result = datasource.addY3Query(Y3QueryDataSource.ACTION_CUSTOMER_VISITING_DELETE,jsonString,null);									 
												if (result != -1) {
													if (datasource.deleteCustomerVisitingData(customerVisit.getCustomerVisit().getId()))
													{
														AppConstant.LOADFILLLISTVIEW=true;
														Toast.makeText(getActivity(),getString(R.string.customer_visit_deleted),Toast.LENGTH_SHORT).show();														
														customerArrayList.clear();
														fillLIstView();
													}
												}					
												
												datasource.close();

											}
										})
								.setNegativeButton(
										getString(R.string.no),
										new DialogInterface.OnClickListener() {
											public void onClick(
													DialogInterface dialog,
													int id) {
												dialog.cancel();
											}
										});
						AlertDialog alertDialog = alertDialogBuilder
								.create();
						alertDialog.show(); 
				    }
				    
				  
					
					
				} 
			}
		});
		mQuickAction.show(anchorView);
		mQuickAction.setAnimStyle(QuickAction.ANIM_GROW_FROM_CENTER);
	}
	private class CustomersVisitsListAsyncTask extends AsyncTask<Void, Void, ArrayList<CustomerVisit>>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		public CustomersVisitsListAsyncTask(AQuery aq)
		{
			this.aq=aq;
			pageCount=pageCount+1;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			
			if(getActivity()==null){
				progressDialog = new ProgressDialog(aq.getContext());
			}
			else{
				progressDialog = new ProgressDialog(getActivity());
			}
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected ArrayList<CustomerVisit> doInBackground(Void... params) 
		{
			if(AppManager.getInstance().isOnline(aq.getContext()))
			{
				return AppManager.getInstance().getCustomerVisitList(aq,pageCount);
			}
			return null;
		}
		@Override
		protected void onPostExecute(ArrayList<CustomerVisit> result) 
		{
			super.onPostExecute(result);
			if(result!=null && adapter!=null)
			{
				if(result.size()>0)
				{
					customerArrayList.addAll(result);
					adapter.notifyDataSetChanged();
					aqf.id(R.id.buttonLoadMoreListItems).visible();
					if(result.size()<20)
					{
						aqf.id(R.id.buttonLoadMoreListItems).invisible();
					}
				}
				else
				{
					if(pageCount==1)
					{
						Toast.makeText(getActivity(), getString(R.string.no_data), Toast.LENGTH_SHORT).show();
					}
					adapter.notifyDataSetChanged();
					aqf.id(R.id.buttonLoadMoreListItems).invisible();
				}
			}
			else
			{
				Toast.makeText(aq.getContext(), getString(R.string.customer_visit_empty), Toast.LENGTH_SHORT).show();
			}
			
			progressDialog.dismiss();
		}
	}
	
private class DeleteCustomerfromServer extends	AsyncTask<Void, Void, ArrayList<Customer>> {

ProgressDialog progressDialog;
@Override
protected void onPreExecute() {
	super.onPreExecute();
	progressDialog = new ProgressDialog(getActivity());
	progressDialog.setMessage(getString(R.string.wait_progress));
	progressDialog.setCancelable(false);
	progressDialog.setIndeterminate(true);
	progressDialog.show();
	progressDialog
			.setOnKeyListener(new DialogInterface.OnKeyListener() {
				@Override
				public boolean onKey(DialogInterface dialog,
						int keyCode, KeyEvent event) {
					return false;
				}
			});
}

@Override
protected ArrayList<Customer> doInBackground(Void... params) {
	// this is for add customer in server...
	
	try{
		
		//System.out.println(getActivity().getApplicationContext());
		
		Y3QueryDataSource datasourcedelete ; //= new Y3QueryDataSource(getActivity());
		
		if(getActivity()==null){
			datasourcedelete = new Y3QueryDataSource(aq.getContext());
		}
		else{
			datasourcedelete = new Y3QueryDataSource(getActivity());
		}
		datasourcedelete.open();
		Cursor cursor=datasourcedelete.getCustomerVisitData();
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {					
			if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEADDED)))){				
				SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
				String token = prefs.getString("token", null);
				
				String json="{" +
						"\"token\":\""+token+"\",";
				
				if(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))==null)
				{
					json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))+"\"," +
							"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_LGAREAID))+"\"," +
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_DEPOTID))+"\"," +
							"\"visiting_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_VISITING_DATE))+"\"," +
							"\"comment\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_COMMENT))+"\"";
					json=json+",";
					json=json+"\"newCustomer\":" ;
					json=json+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMER_JSON));		
					json=json+"}";
				}
				else{
					
					json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))+"\"," +
							"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_LGAREAID))+"\"," +
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_DEPOTID))+"\"," +
							"\"visiting_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_VISITING_DATE))+"\"," +
							"\"comment\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_COMMENT))+"\"";
					json=json+"}";
					
				}
				
				Hashtable<String,String> params1=new Hashtable<String,String>();
	    		params1.put("jsonString",json);	
	    		//String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_INCENTIVE, params, null);
				String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_CUSTOMERVISITS, params1, null);
				System.out.println("The Response is now find "+response);
				
				
				
				
				
			}
			cursor.moveToNext();
		}
		datasourcedelete.close();
	}
	catch(Exception e){
		e.printStackTrace();
	}
	
	
// this is for delete data from server.......	
	Y3QueryDataSource datasource ;// = new Y3QueryDataSource(getActivity());
	if(getActivity()==null){
		datasource = new Y3QueryDataSource(aq.getContext());
	}
	else{
		datasource = new Y3QueryDataSource(getActivity());
	}
	datasource.open();
	List<Y3Query> result = datasource.getAllY3Queries();
	for (int i = 0; i < result.size(); i++) {
		Y3Query y3q = result.get(i);
		if (y3q.getAction().equals(
				Y3QueryDataSource.ACTION_CUSTOMER_VISITING_DELETE)) {
			Hashtable<String,String> parameters=new Hashtable<String,String>();
			parameters.put("jsonString", y3q.getJson());
			Hashtable<String,File> fileParams=null;
			String imagePath=null;
    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
    		{
    			fileParams=new Hashtable<String,File>();
	    		fileParams.put("image", new File(imagePath));
    		}
		    String response = Utils.post(getActivity(), AppManager.getInstance().URL_DELETE_CUSTOMERVISITS, parameters, fileParams);

			try {
				if (response != null
						&& new JSONObject(response).getInt("error") == 0) {
					boolean isQueryDeleted = datasource
							.deleteY3Query(y3q.get_id());
					Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		}

	}
	datasource.close();
	// this is for edit.........................................URL_UPDATE_CUSTOMERVISITS
	try{
		Y3QueryDataSource datasourceedit ;//= new Y3QueryDataSource(getActivity());
		if(getActivity()==null){
			datasourceedit = new Y3QueryDataSource(aq.getContext());
		}
		else{
			datasourceedit = new Y3QueryDataSource(getActivity());
		}
		datasourceedit.open();
		Cursor cursor=datasourceedit.getCustomerVisitData();
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {					
			if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEEDITED)))){				
				SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
				String token = prefs.getString("token", null);
				String json="{" +"\"token\":\""+token+"\",";
				if(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))!=null)
				{
					json=json+"\"visit_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ID))+"\",";
				
				json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))+"\"," +
						"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_LGAREAID))+"\"," +
						"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_DEPOTID))+"\"," +
						"\"visiting_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_VISITING_DATE))+"\"," +
						"\"comment\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_COMMENT))+"\"";
				json=json+"}";
				}
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", json);				
			    String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_CUSTOMERVISITS, parameters, null);
			    System.out.println("This is for edit "+response);
				
			}
			cursor.moveToNext();	
			}
			
		datasourceedit.close();
		}
	
	catch(Exception e){
		e.printStackTrace();
	}
	

	

	return null;
}

@Override
protected void onPostExecute(ArrayList<Customer> result) {

	progressDialog.dismiss();
	new CustomersVisitsListAsyncTask(aq).execute();
}
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
