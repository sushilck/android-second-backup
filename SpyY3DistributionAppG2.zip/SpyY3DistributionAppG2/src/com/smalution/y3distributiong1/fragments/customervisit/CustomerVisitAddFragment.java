package com.smalution.y3distributiong1.fragments.customervisit;
import com.smalution.y3distributiong1.AppManager;
import com.smalution.y3distributiong1.R;
import com.smalution.y3distributiong1.Utils;
import com.smalution.y3distributiong1.database.Y3QueryDataSource;
import com.smalution.y3distributiong1.entities.User;
import com.smalution.y3distributiong1.entities.customer.SearchCutomer;
import com.smalution.y3distributiong1.entities.customervisits.CustomerVisit;
import com.smalution.y3distributiong1.entities.settings.Customers;
import com.smalution.y3distributiong1.entities.settings.Depots;
import com.smalution.y3distributiong1.entities.settings.Lgas;
import com.smalution.y3distributiong1.entities.settings.SelectionButtonItem;
import com.smalution.y3distributiong1.entities.settings.States;
import com.smalution.y3distributiong1.fragments.SuperFragment;
import com.smalution.y3distributiong1.geolocatorservice.GPSTracker;
import com.smalution.y3distributiong1.utils.AppConstant;
import com.smalution.y3distributiong1.utils.DateTimePickerCallbackInterface;
import com.smalution.y3distributiong1.utils.DateTimePickerFragment;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Toast;

import com.androidquery.AQuery;

public class CustomerVisitAddFragment extends SuperFragment 
{
	boolean isOnlineCustomerSelectionModeOn=true;
	Hashtable<String, String> offlineCustomers;
	CustomerVisit customerVisit;
	View rootView;
	AQuery aq; 
	public static final int FLAG_SELECT_CUSTOMER=101;
	public static final int FLAG_SELECT_LGA=102;
	public static final int FLAG_SELECT_DEPOT=103;
	public static final int FLAG_SELECT_STATE=104;
	UIHandler uiHandler;
	public static String customer_json;
	public static String jsonString;
	private  String states_id;
	public  String customer_id;
	public boolean isDraft = false;
	
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		case FLAG_SELECT_CUSTOMER:
        		{
        			
        			if(isOnlineCustomerSelectionModeOn)
        			{
        				
            			//Customers customers = AppManager.getInstance().getCustomers(aq);
        				SelectionButtonItem itm = (SelectionButtonItem) msg.obj;
        				aq.id(R.id.buttonCustomer).text(itm.getTitle());
        				if(itm!=null)
        				{
        					customer_id= Integer.toString(msg.arg2);
        					customerVisit.getCustomerVisit().setCustomer_id(itm.getId());
        					customerVisit.getCustomer().setFirst_name(itm.getTitle());
        					customerVisit.getCustomer().setLast_name("");
        				}
            			/*if(customers!=null)
            			{
            				SelectionButtonItem itm = customers.getItem(msg.arg2);
            				if(itm!=null)
            				{
            					customerVisit.getCustomerVisit().setCustomer_id(itm.getId());
            					customerVisit.getCustomer().setFirst_name(itm.getTitle());
            					customerVisit.getCustomer().setLast_name("");
            				}
                		}*/
        			}
        			else
        			{
        				String selectedValue=(String)msg.obj;
        				aq.id(R.id.buttonOfflineCustomer).text(selectedValue);
        			    String jsonString = offlineCustomers.get(selectedValue);
        			    customerVisit.setOfflineCustomerJSON(jsonString);
        				customer_json=offlineCustomers.get(selectedValue);
        			  
						JSONObject jsonojb;
						try {
							jsonojb = new JSONObject(customer_json);
							customerVisit.setOfflineCustomerJSON(jsonString);
							customerVisit.getCustomer().setFirst_name(jsonojb.getString("first_name"));
	    					customerVisit.getCustomer().setLast_name(jsonojb.getString("last_name"));
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
        			}
        			break;
        		}
        		
        		case FLAG_SELECT_LGA:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonLGA).text(selectedValue);
        			Lgas lgas = AppManager.getInstance().getLgas(aq);
        			if(lgas!=null)
        			{
        				customerVisit.getCustomerVisit().setLg_area_id(lgas.getItem(msg.arg2).getId());
        				
        			}
        			break;
        		}
        		case FLAG_SELECT_STATE:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonState).text(selectedValue);
        			States states = AppManager.getInstance().getStates(aq);
        			if(states!=null)
        			{
        				
        				states_id=states.getItem(msg.arg2).getId();
        				customerVisit.getCustomerVisit().setState_id(states_id);
        				aq.id(R.id.buttonLGA).text("AllLGA");
        				//System.out.println("DEMO");
        			}
        			break;
				}

        		case FLAG_SELECT_DEPOT:
	    		{
	    			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonDepot).text(selectedValue);
        			Depots depots=AppManager.getInstance().getDepots(aq);
        			if(depots!=null)
        			{
        				customerVisit.getCustomerVisit().setDepot_id(depots.getItem(msg.arg2).getId());
        			}
	    			break;
	    		}
	    		
        	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
        	customerVisit = args.getParcelable("CUSTOMER");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		customerVisit = getArguments().getParcelable("CUSTOMER");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.customer_visit_add_fragment, container, false);
        customerVisit=new CustomerVisit();
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        initUI();
        cvfillfromDraft();
        return rootView;
    }
	
	public void onPause(){
		super.onPause();
		System.out.println("This is OnPause activity");
		cvaddDraft();
	}
	
	public void onStop(){
		super.onStop();
		System.out.println("This is onStop activity");
		cvaddDraft();
	}
	
	public void onDestroy(){
		super.onDestroy();
		System.out.println("This is onDestroy activity");
		cvaddDraft();
	}
	
	
	private void initUI() 
	{
		
		
		aq.id(R.id.tableRowVisitingDate).invisible();
		Calendar calender = Calendar.getInstance();
		String dateStr= calender.get(Calendar.YEAR)+"-"+(calender.get(Calendar.MONTH)+1)+"-"+calender.get(Calendar.DAY_OF_MONTH) + " "
		+calender.get(Calendar.HOUR_OF_DAY)+":"+calender.get(Calendar.MINUTE)+":"+calender.get(Calendar.SECOND);
		aq.id(R.id.editTextVisitingDate).text(dateStr);
		if(dateStr!=null && dateStr.length()>0){
			customerVisit.getCustomerVisit().setVisiting_date(dateStr);
		}
		
		aq.id(R.id.buttonCustomer).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				aq.id(R.id.buttonOfflineCustomer).text("Select Offline Customer");
				isOnlineCustomerSelectionModeOn=true;
				//boolean flag=false;
				
				SearchCutomer.showAutosearchAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER);
				
				/*Customers customers = AppManager.getInstance().getCustomers(aq);
				if(customers!=null)
				{
					String[] arr=customers.getCustomerNamesArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER,arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.customer_required_mess), Toast.LENGTH_SHORT).show();
				}*/
			}
		});
		
		aq.id(R.id.buttonOfflineCustomer).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				isOnlineCustomerSelectionModeOn=false;
				aq.id(R.id.buttonCustomer).text(getString(R.string.select_customer));
				new GetOfflineCustomersAsyncTask(aq).execute();
			}
		});
		/*aq.id(R.id.buttonState).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				States states = AppManager.getInstance().getStates(aq);
				if(states!=null)
				{
					String[] arr=states.getStatesNameArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_STATE, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.state_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		aq.id(R.id.buttonLGA).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Lgas lgas = AppManager.getInstance().getLgas(aq,states_id);
				if(lgas!=null)
				{
					String[] arr=lgas.getLgaNamesArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_LGA, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), "LGA is required, please contact administrator.", Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonDepot).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Depots depots=AppManager.getInstance().getDepots(aq);
				if(depots!=null)
				{
					String[] arr=depots.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DEPOT, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), "Depots are required field, please contact administrator.", Toast.LENGTH_SHORT).show();
				}
			}
		});*/
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				updateCustomer();
			}
		});
		aq.id(R.id.editTextVisitingDate).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				showDatePicker();
			}
		});
	}
	private void showDatePicker() 
	{
		  DateTimePickerFragment date=new DateTimePickerFragment();
		  date.setCallBack(dateTimePickerCallbackInterface);
		  date.show(getActivity().getSupportFragmentManager(), "Date Picker" );
	}
	DateTimePickerCallbackInterface dateTimePickerCallbackInterface = new DateTimePickerCallbackInterface() 
	{
		@Override
		public void onDateTimeSet(int year, int month, int day, int hours,int mins) 
		{
			String dateStr=String.valueOf(year) + "-" + String.valueOf(month+1)+ "-" + String.valueOf(day)+" "+hours+":"+mins;
			
			aq.id(R.id.editTextVisitingDate).text(dateStr);
			if(dateStr!=null && dateStr.length()>0){
				customerVisit.getCustomerVisit().setVisiting_date(dateStr);
			}
		}
	};
	private boolean isValidated()
	{
		if((aq.id(R.id.buttonCustomer).getButton().getText().toString().length()>0 &&!aq.id(R.id.buttonCustomer).getButton().getText().toString().startsWith("Select")) || 	(aq.id(R.id.buttonOfflineCustomer).getButton().getText().toString().length()>0 &&!aq.id(R.id.buttonOfflineCustomer).getButton().getText().toString().startsWith("Select")))
		{
			
			final SharedPreferences prefs=getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
			String str = prefs.getString("user_object", "");
			final String token = prefs.getString("token", null);
			if(str!="")
			{
				try
				{
					JSONObject userJSONObject = new JSONObject(str);
					final User user=new User(userJSONObject);
					customerVisit.getUser().setFirst_name(user.getFirst_name());
					customerVisit.getUser().setLast_name(user.getLast_name());
				}
				catch(Exception e){
					
				}
			}
			/*if(aq.id(R.id.buttonState).getButton().getText().toString().length()>0 &&!aq.id(R.id.buttonState).getButton().getText().toString().startsWith("Select"))
			{*/
			/*
			if(aq.id(R.id.buttonLGA).getButton().getText().toString().length()>0 &&	!aq.id(R.id.buttonLGA).getButton().getText().toString().startsWith("Select"))
			{ 
				String lganame = aq.id(R.id.buttonLGA).getText().toString();
				if(lganame!=null && lganame.length()>0)
				{
					//customerVisit.getLgArea().getName()
					customerVisit.getLgArea().setName(lganame);
				}
				
				if(aq.id(R.id.buttonDepot).getButton().getText().toString().length()>0 &&!aq.id(R.id.buttonDepot).getButton().getText().toString().startsWith("Select"))
				{
					String depotName=aq.id(R.id.buttonDepot).getText().toString();
					
					if(depotName!=null && depotName.length()>0){
						customerVisit.getDepot().setTitle(depotName);
					}
					*/
					if(aq.id(R.id.editTextDescription).getEditText().getText().toString().length()>0)
					{
						String description=aq.id(R.id.editTextDescription).getText().toString();
						if(description!=null && description.length()>0){
							customerVisit.getCustomerVisit().setComment(description);
						}
						
						return true;
					}
					else
					{
						Toast.makeText(getActivity(), getString(R.string.enter_description), Toast.LENGTH_SHORT).show();
					}
				/*	}
				else
				{
					Toast.makeText(getActivity(), "Please select depot.", Toast.LENGTH_SHORT).show();
				}
			}
			else
			{
				Toast.makeText(getActivity(), "Please select lga.", Toast.LENGTH_SHORT).show();
			} */
			/*}
			else{
				Toast.makeText(getActivity(), getString(R.string.pls_select_state), Toast.LENGTH_SHORT).show();
			}*/
		}	
		else
		{
			Toast.makeText(getActivity(), getString(R.string.select_customer), Toast.LENGTH_SHORT).show();
		}
		return false;
	}
	private void updateCustomer()
	{
		if(!isValidated())
		{
			return;
		}
		
		GPSTracker gpsTracker = new GPSTracker(aq.getContext());
		customerVisit.getCustomerVisit().setLatitude( String.valueOf( gpsTracker.getLatitude() ) );
		customerVisit.getCustomerVisit().setLongitude( String.valueOf( gpsTracker.getLongitude()) ) ;
		if(AppManager.isOnline(getActivity())){
			 jsonString = customerVisit.createJson(aq, true, isOnlineCustomerSelectionModeOn);
			 System.out.println(jsonString);
			 new AddIncentive().execute();
			
		}
		else{
			
			
		    DateFormat dateFormat = new SimpleDateFormat("HHmmss");
			Date date = new Date();
			System.out.println(dateFormat.format(date));
			 /*String  firstLetter = String.valueOf(dateFormat.format(date).toString().charAt(0));
			  if("0".equals(firstLetter)){
				  firstLetter.substring(1);
			  }*/
			String  firstLetter = dateFormat.format(date).toString().replaceFirst("^0+(?!$)", "");	
		    customerVisit.getCustomerVisit().setId(firstLetter);
		    customerVisit.getCustomerVisit().setCreated(AppConstant.getCurrentDateAndTime());
		    customerVisit.getCustomerVisit().setModified(AppConstant.SYNC_NOT_DONE);
		    Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		    
		    datasource.open();
		    datasource.addCustomerVisitingData(customerVisit,"1",customer_json);
		    showSaveDialog();
		    SharedPreferences cvprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
			Editor edt = cvprefs.edit();
			edt.putString("cvdraftJsonString", null);
			edt.commit();
			isDraft = true;
		    
		    
		    //datasource.close();
		    //Toast.makeText(getActivity(), "CustomerVisit added successfully.", Toast.LENGTH_SHORT).show();
	    	//getActivity().getSupportFragmentManager().popBackStack();
			
		}
		
		/*customerVisit.getCustomerVisit().setVisiting_date(aq.id(R.id.editTextVisitingDate).getTextView().getText().toString());
		customerVisit.getCustomerVisit().setComment(aq.id(R.id.editTextDescription).getTextView().getText().toString());
		String jsonString = customerVisit.createJson(aq, true, isOnlineCustomerSelectionModeOn);
		Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
	    datasource.open();
	    long result = datasource.addY3Query(Y3QueryDataSource.ACTION_CUSTOMERVISIT_ADD, jsonString, null);
	    datasource.close();
	    if(result!=-1)
	    {
	    	Toast.makeText(getActivity(), "CustomerVisit added successfully.", Toast.LENGTH_SHORT).show();
	    	getActivity().getSupportFragmentManager().popBackStack();
	    }*/
	}
	private class AddIncentive extends AsyncTask<Void, Void, String> {


		ProgressDialog progressDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
			progressDialog.setMessage(getString(R.string.wait_progress));
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(true);
			progressDialog.show();
			progressDialog
					.setOnKeyListener(new DialogInterface.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog,
								int keyCode, KeyEvent event) {
							return false;
						}
					});
		}


		protected String doInBackground(Void... params1) {
			if (AppManager.getInstance().isOnline(aq.getContext())) {
				
				Hashtable<String,String> params=new Hashtable<String,String>();
	    		params.put("jsonString",jsonString);	
	    		//String response = Utils.post(GPSTrackerService.this, AppManager.getInstance().URL_UPDATE_INCENTIVE, params, null);
				String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_CUSTOMERVISITS, params, null);
				return response;
			}
			return null;
		}

		protected void onPostExecute(String response) {
			
			progressDialog.dismiss();
			
			try {
				if(response!=null){
				int errorCode=new JSONObject(response).getInt("error");
				
				if(errorCode==0){
					System.out.println("Added");
					 //Toast.makeText(getActivity(), "Incentive added successfully.", Toast.LENGTH_SHORT).show();
				     //getActivity().getSupportFragmentManager().popBackStack();
					showSaveDialog();
					SharedPreferences cvprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
					Editor edt = cvprefs.edit();
					edt.putString("cvdraftJsonString", null);
					edt.commit();
					isDraft = true;
				}
				else{
					System.out.println("something wrong");
					
				}
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
	private class GetOfflineCustomersAsyncTask extends AsyncTask<Void, Void,String[]>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		boolean flag=false;
		public GetOfflineCustomersAsyncTask(AQuery aq)
		{
			this.aq=aq;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected String[] doInBackground(Void... params) 
		{
			Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		    datasource.open();
		    SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
			String token = prefs.getString("token", null);
		    offlineCustomers = datasource.getOfflineCustomeData(token);
		    datasource.close();
		    
		    if(offlineCustomers!=null)
			{
		    	Set<String> keys = offlineCustomers.keySet();
			    String[] arr=new String[keys.size()];
			    keys.toArray(arr);
			    return arr;
			}
			return null;
		}
		@Override
		protected void onPostExecute(String[] result) 
		{
			super.onPostExecute(result);
			if(result!=null)
			{
		    	if(result.length>0)
				{
					AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER, result);
					flag=true;
				}
			}
			if(!flag)
			{
				Toast.makeText(getActivity(), getString(R.string.offline_customer_mess), Toast.LENGTH_SHORT).show();
				
			}
			progressDialog.dismiss();
		}
	}
	private void showSaveDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle("Confirm");
		alertDialogBuilder
				.setMessage(getString(R.string.customer_visit_added))
				.setCancelable(false)
				.setPositiveButton(
						getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								getActivity().getSupportFragmentManager().popBackStack();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
	
	
	public void cvaddDraft(){
		if(!isDraft){
			
			customerVisit=new CustomerVisit();
			customerVisit.getCustomerVisit().setId(customer_id);
			customerVisit.getCustomerVisit().setCustomer_id(customer_id);
			customerVisit.getCustomer().setFirst_name(aq.id(R.id.buttonCustomer).getButton().getText().toString());	
			
			
			customerVisit.getCustomerVisit().setComment(aq.id(R.id.editTextDescription).getEditText().getText().toString());
			customerVisit.getCustomerVisit().setVisiting_date(aq.id(R.id.editTextVisitingDate).getEditText().getText().toString());
			String cvdraftJsonString = customerVisit.createJson(aq,true,true);
			SharedPreferences cvprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
			Editor edt = cvprefs.edit();
			edt.putString("cvdraftJsonString", cvdraftJsonString);
			edt.commit();
			isDraft = true;
		}
	}
	
	
	
	public void cvfillfromDraft(){
		SharedPreferences cvprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		String cvdraftJsonString = cvprefs.getString("cvdraftJsonString", null);
		//System.out.println("CUSTOMERVISIT:"+cvdraftJsonString);
		if(cvdraftJsonString != null){
			try {
				JSONObject customervisitJson = new JSONObject(cvdraftJsonString);
				
				
				  
				customer_id = customervisitJson.isNull("customer_id") ? ""	: customervisitJson.getString("customer_id");
			    customerVisit.getCustomerVisit().setCustomer_id(customer_id);
				String CustomerName = customervisitJson.isNull("customer_name") ? ""	: customervisitJson.getString("customer_name");
				aq.id(R.id.buttonCustomer).text(CustomerName);
				
				
				String Description = customervisitJson.isNull("comment") ? ""	: customervisitJson.getString("comment");
				aq.id(R.id.editTextDescription).text(Description);
				String VisitingDate = customervisitJson.isNull("visiting_date") ? ""	: customervisitJson.getString("visiting_date");
				aq.id(R.id.editTextVisitingDate).text(VisitingDate);
				
				
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
}
