package com.smalution.y3distributiong1.fragments.home;

import com.smalution.y3distributiong1.AppManager;
import com.smalution.y3distributiong1.R;
import com.smalution.y3distributiong1.Utils;
import com.smalution.y3distributiong1.database.MySQLiteHelper;
import com.smalution.y3distributiong1.database.Y3Query;
import com.smalution.y3distributiong1.database.Y3QueryDataSource;
import com.smalution.y3distributiong1.entities.User;
import com.smalution.y3distributiong1.entities.settings.ActiveCompaignManager;
import com.smalution.y3distributiong1.entities.settings.ActiveCompaigns;
import com.smalution.y3distributiong1.fragments.SuperFragment;
import com.smalution.y3distributiong1.utils.AppConstant;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.androidquery.AQuery;



public class HomeDisplayFragment extends SuperFragment 
{
	AQuery aq;
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        View rootView = inflater.inflate(R.layout.home_display_fragment, container, false);
        aq=new AQuery(rootView);
        showUserDetail();
        AppConstant.isLogin=true;
        Bundle b = getActivity().getIntent().getExtras();
        String notify =  b.getString("notify","0");
        if("1".equals(notify)){
			show_notifiction();
			getActivity().getIntent().putExtra("notify", "0");
	 	}
        return rootView;
    }
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
	    if (keyCode == KeyEvent.KEYCODE_BACK)
	    {
	        if (getFragmentManager().getBackStackEntryCount() == 0)
	        {
	           // this.finish();
	            return false;
	        }
	        else
	        {
	          //  getFragmentManager().popBackStack();
	           // removeCurrentFragment();

	            return false;
	        }



	    }
	    return true;

	    //return super.onKeyDown(keyCode, event);
	}
	private class SyncDataAsyncTask extends AsyncTask<Void, Void, String> {


		ProgressDialog progressDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
			progressDialog.setMessage(getString(R.string.wait_progress));
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(true);
			progressDialog.show();
			progressDialog
					.setOnKeyListener(new DialogInterface.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog,
								int keyCode, KeyEvent event) {
							return false;
						}
					});
		}


		protected String doInBackground(Void... params) {
			if (AppManager.getInstance().isOnline(aq.getContext())) 
			{
				//
				//sendY3Queries();
				//1
				CustomerQueryies();				
				//this is for app setting...
				getSetting();				
				//2
				customerVisitQuery();			
				//3 
				salesQuery();				
				//
				distributorSalesQuery();				
				//5
				incentivesQuery();				
				//6
				paymentQuery();				
				//7
				expensesQuery();
				
			}
			return null;
		}

		protected void onPostExecute(String response) {
			
			progressDialog.dismiss();
			
		
		}
		}
	private class GetActiveCompaignAsyncTask extends AsyncTask<Void, Void,ArrayList<ActiveCompaigns>>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		public GetActiveCompaignAsyncTask(AQuery aq)
		{
			this.aq=aq;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected ArrayList<ActiveCompaigns> doInBackground(Void... params) 
		{
			try
			{
				ActiveCompaignManager activeCompaignManager=AppManager.getInstance().getActiveCompaign(aq);
				return activeCompaignManager.getCompaignList();
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			
			return null;
		}
		@Override
		protected void onPostExecute(final ArrayList<ActiveCompaigns> result) 
		{
			super.onPostExecute(result);
			if(result!=null && result.size()>0)
			{
				showCompaignDialog(aq.getContext(), result);
			}
			else
			{
				Toast.makeText(aq.getContext(), getString(R.string.campaign_not_available), Toast.LENGTH_SHORT).show();
			}
			progressDialog.dismiss();
		}
	}
	private void showCompaignDialog(Context context, ArrayList<ActiveCompaigns> compaignArrayList)
	{
	    final Dialog dialog = new Dialog(aq.getContext());
	    dialog.setTitle(getString(R.string.Active_Campaigns));
	    View view = LayoutInflater.from(aq.getContext()).inflate(R.layout.compaign_dialog_main, null);
	    ListView lv = (ListView) view.findViewById(R.id.compaignList);
	    ArrayAdapter<ActiveCompaigns> compaignListaAdapter= new ArrayAdapter<ActiveCompaigns>(aq.getContext(), R.layout.compaign_dialog_listitem, compaignArrayList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.compaign_dialog_listitem, parent, false);
	            }
	            final AQuery aql=new AQuery(convertView);
	            ActiveCompaigns activeCompaigns=getItem(position);
	            aql.id(R.id.textViewCompaignTitle).text(activeCompaigns.getCompaign().getTitle());
	            aql.id(R.id.textViewCompaignDescription).text(getString(R.string.get)+" "+activeCompaigns.getCompaign().getFree_qty()+" "+activeCompaigns.getCompaign().getFree_unit()+" "+getString(R.string.of)+" \""+activeCompaigns.getBrand().getName()+"\" "+getString(R.string.on_purchase_of)+" "+activeCompaigns.getCompaign().getRequired_qty()+" "+activeCompaigns.getCompaign().getRequired_unit()+" "+activeCompaigns.getBrand().getName());
	            return convertView;
	        }
		};
	    lv.setAdapter(compaignListaAdapter);
	    dialog.setContentView(view);
	    dialog.setCancelable(true);
	    dialog.show();
	}
	private void showUserDetail() 
	{
		
		aq.id(R.id.Button_ShowActiveCompaign).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				new GetActiveCompaignAsyncTask(aq).execute();
			}
		});
		
		aq.id(R.id.Button_ShowOfflineQueriesStatus).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
				FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
				Fragment fragment = fragmentManager.findFragmentByTag("ViewServerLogsFragment");
				Bundle bundle=new Bundle();
//				bundle.putParcelable("EXPENSE", expense);
				if(fragment==null)
				{
					fragment=new ViewServerLogsFragment();
					fragment.setArguments(bundle);
					fragmentTransaction.addToBackStack("ViewServerLogsFragment");
				}
				else
				{
//					((ViewServerLogsFragment)fragment).setUIArguments(bundle);
				}
				fragmentTransaction.replace(R.id.frame_container, fragment, "ViewServerLogsFragment");
				fragmentTransaction.commit();
			}
		});
		aq.id(R.id.button_shownotifcation).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				show_notifiction();
			}
		});
		aq.id(R.id.Button_Refresh).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				//new GetActiveCompaignAsyncTask(aq).execute();
				if(AppManager.isOnline(getActivity()))
				{
				new SyncDataAsyncTask().execute();
				}
			}
		});
		
		final SharedPreferences prefs=getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		String str = prefs.getString("user_object", "");
		final String token = prefs.getString("token", null);
		if(str!="")
		{
			try
			{
				JSONObject userJSONObject = new JSONObject(str);
				final User user=new User(userJSONObject);
				aq.id(R.id.profilePicture).progress(R.id.profilePictureProgress).image(user.getImage_url());
				aq.id(R.id.TextView_username).text(user.getFirst_name()+" "+user.getLast_name());
				aq.id(R.id.TextView_dob).text(user.getBirthdate());
				aq.id(R.id.TextView_address).text(user.getAddress());
				aq.id(R.id.TextView_email).text(user.getEmail());
				aq.id(R.id.TextView_mobile).text(user.getMobile());
				aq.id(R.id.TextView_phone).text(user.getPhone());
				aq.id(R.id.TextView_fax).text(user.getFax());
				aq.id(R.id.Button_logout).clicked(new OnClickListener() 
				{
					@Override
					public void onClick(View v) 
					{
						showlogoutDialog();
/*						Editor edt = prefs.edit();
			    		edt.putBoolean("isRunService", false);
			    		edt.putLong("LAST_SERVE_TIME", 0l);
			    		edt.commit();			    		
			    		
			    		Y3QueryDataSource datasource ;//=new Y3QueryDataSource(getActivity());
			    		if(getActivity()==null){
			    			datasource=new Y3QueryDataSource(aq.getContext());
			    		}
			    		else{
			    			datasource=new Y3QueryDataSource(getActivity());
			    		}
			    		datasource.open();
			    		datasource.deleteAllCustomerRecordFromDB();
			    		datasource.deleteAllCustomerVisitingRecordFromDB();
			    		datasource.deleteAllExpenceRecordFromDB();
			    		datasource.deleteAllIncentiveRecordFromDB();
			    		datasource.deleteAllPaymentRecordFromDB();
			    		//datasource.deleteAllRecordFromDB();
			    		datasource.deleteAllRedistributorsRecordFromDB();
			    		datasource.deleteAllSalesRecordFromDB();
			    		datasource.deleteAllQueries();
			    		datasource.close();*/
						
			    		
			    		//Intent intent=new Intent(getActivity(), LoginActivity.class);
			    		//startActivity(intent);
			    		
			    		
					}
				});
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}
	}
	private void showlogoutDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(R.string.Logout);
		alertDialogBuilder.setMessage(R.string.confirm_logout)
				.setCancelable(false)
				.setPositiveButton(
						R.string.yes,
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {								
								AppConstant.isLogin=false;
					    		getActivity().finish();
					    		dialog.cancel();
							}
						})
							.setNegativeButton(
												R.string.no,
												new DialogInterface.OnClickListener() {
													public void onClick(
															DialogInterface dialog,
															int id) {
														dialog.cancel();
													}
												});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
	private void CustomerQueryies(){
		try{	
			
		// this is for add customer to server.......	
		Y3QueryDataSource datasource1;			
		datasource1 = new Y3QueryDataSource(getActivity());		 
		datasource1.open();
		Cursor cursor=datasource1.getCustomerData();
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {					
			if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ISOFFLINEADDED))))
			{				
				SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
				String token = prefs.getString("token", null);
				boolean isViewDetails;
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.VIEW_DETAILS)))){
					isViewDetails=true;
				}else{
					isViewDetails=false;
				}
				String json="{" +
						"\"token\":\""+token+"\","+"\"request_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REQUEST_ID))+"\"," ;
				json=json+"\"first_name\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.FIRST_NAME))+"\"," +
						"\"last_name\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LAST_NAME))+"\"," +
						"\"email\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EMAIL_ID))+"\"," +
						"\"address\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ADDRESS))+"\"," +
						"\"city\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CITY))+"\"," +
						"\"state_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.STATE_ID))+"\"," +
						"\"latitude\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LATITUDE))+"\"," +
						"\"longitude\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LONGITUDE))+"\"," +
						"\"zipcode\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ZIPCODE))+"\"," +
						"\"created\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CREATED_DATE))+"\"," +
						"\"phone\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PHONE))+"\"," +
						"\"route_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ROUTE_ID))+"\"," +
						"\"region_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REGION_ID))+"\"," +
						"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DEPOT_ID))+"\"," +
						"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LGAREA_ID))+"\"," +
						"\"description\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DESCRIPTION))+"\"," +
						"\"view_details\":\""+isViewDetails+"\"" ;								
						json=json+",\"assignToOption\":"+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ASSIGNTO));
				json=json+"}";
				
				
				 	Hashtable<String,String> paramforAddcustomer=new Hashtable<String,String>();
				 	paramforAddcustomer.put("jsonString", json);
				 	
					Hashtable<String,File> fileParams=null;
					String imagePath=cursor.getString(cursor.getColumnIndex(MySQLiteHelper.IMAGE_PATH));
		    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
		    		{
		    			fileParams=new Hashtable<String,File>();
			    		fileParams.put("image", new File(imagePath));
		    		}
		    		//Utils.post(context, url, parameters, fileParams);
				    String response = Utils.post(getActivity(),AppManager.getInstance().URL_UPDATE_CUSTOMER, paramforAddcustomer, fileParams);
				    System.out.println("This is Addcustomer Server response"+response);
				    if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasource1.updateISAdded(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_ID)));
			
					}
				    }
			}
			
			cursor.moveToNext();
			}
		datasource1.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
		//this portion for DeleteData From Server.....
		//------------------------------------------------------
		
		Y3QueryDataSource datasource ;//;= new Y3QueryDataSource(getActivity());		
			datasource = new Y3QueryDataSource(getActivity());
		
		datasource.open();
		
		try{
		
		List<Y3Query> result = datasource.getAllY3Queries();
		for (int i = 0; i < result.size(); i++) {
			Y3Query y3q = result.get(i);
			if (y3q.getAction().equals(Y3QueryDataSource.ACTION_CUSTOMER_DELETE)) {
				Hashtable<String, String> params1 = new Hashtable<String, String>();
				params1.put("jsonString", y3q.getJson());
				String response = Utils.post(getActivity(),AppManager.getInstance().URL_DELETE_CUSTOMER,params1, null);
				Log.d("MTK", "server response: " + response);
				System.out.println("This is DeleteCustomer Server response"+response);

				try {
					if (response != null
							&& new JSONObject(response).getInt("error") == 0) {
						boolean isQueryDeleted = datasource.deleteY3Query(y3q.get_id());
						Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}
			}

		}
		}catch(Exception e){
			e.printStackTrace();
		}
		datasource.close();
		
		//-------------------------------------------------------------------------------------------------------------
		// this is for edit data is......
		
		try {
			
				Y3QueryDataSource datasource1;			
				datasource1 = new Y3QueryDataSource(getActivity());			
				datasource1.open();
				Cursor cursor=datasource1.getCustomerData();
				cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ISOFFLINEEDITED))))
				{				
					SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
					String token = prefs.getString("token", null);
					boolean isViewDetails=true;
					
					String json="{" +"\"token\":\""+token+"\",";	
					if(!false)
					{
						json=json+"\"id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_ID))+"\"," +
						"\"oldFile_id\":\""+0+"\",";
					}
				
					json=json+"\"first_name\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.FIRST_NAME))+"\"," +
							"\"last_name\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LAST_NAME))+"\"," +
							"\"email\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EMAIL_ID))+"\"," +
							"\"address\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ADDRESS))+"\"," +
							"\"city\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CITY))+"\"," +
							"\"state_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.STATE_ID))+"\"," +
							"\"latitude\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LATITUDE))+"\"," +
							"\"longitude\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LONGITUDE))+"\"," +
							"\"zipcode\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ZIPCODE))+"\"," +
							"\"phone\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PHONE))+"\"," +
							"\"route_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ROUTE_ID))+"\"," +
							"\"region_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REGION_ID))+"\"," +
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DEPOT_ID))+"\"," +
							"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LGAREA_ID))+"\"," +
							"\"description\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DESCRIPTION))+"\"," +
							"\"view_details\":\""+isViewDetails+"\"" ;								
					json=json+"}";		
					System.out.println("edit json add"+json);
					 Hashtable<String,String> parametersforEdit=new Hashtable<String,String>();
					 parametersforEdit.put("jsonString", json);
						Hashtable<String,File> fileParams=null;
						String imagePath=cursor.getString(cursor.getColumnIndex(MySQLiteHelper.IMAGE_PATH));
			    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
			    		{
			    			fileParams=new Hashtable<String,File>();
				    		fileParams.put("image", new File(imagePath));
			    		}
			    		//Utils.post(context, url, parameters, fileParams);
					    String response = Utils.post(getActivity(),AppManager.getInstance().URL_UPDATE_CUSTOMER, parametersforEdit, fileParams);
					    System.out.println("This is EditCustomer Server response"+response);
					    if(response!=null){
					    int error = new JSONObject(response).getInt("error");
					    if (error == 0) 
						{
						System.out.println("All is welll");
						datasource1.updateISUpdated(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_ID)));
						}
					    }
					    Log.d("MTK", "ISUPDATE:" + response);   
	
					}
				

			
			cursor.moveToNext();
			}
		datasource.close();
		}
		catch(Exception e){
			System.out.println("Error In Edit Customer");
			e.printStackTrace();
		}
			
	}
	
	public void expensesQuery(){
		Y3QueryDataSource datasource1 = null;
		try{	
			datasource1 = new Y3QueryDataSource(getActivity());			
			datasource1.open();			
			Cursor cursor=datasource1.getExpenceData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) 
			{					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENCE_OFFLINE_ADD))))
				{				
					SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
					String token = prefs.getString("token", null);
					String json="{" +"\"token\":\""+token+"\","+
							"\"request_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REQUEST_ID))+"\","+
							"\"created\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CREATED_DATE))+"\"," ;
					json=json+
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_DEPOT_ID))+"\"," +
							"\"region_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_REGION_ID))+"\"," +
							"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_BRAND_ID))+"\"," +
							"\"exp_amount\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_EXP_AMOUNT))+"\"," +
							"\"exp_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_EXP_DATA))+"\"," +
//							"\"payment_mode\":\""+getExpense().getPayment_mode()+"\"," +
							"\"expense_ref\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_REF))+"\"," +
							"\"description\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_DESCRIPTION))+"\"," +
							"\"exp_type_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_TYPE_ID))+"\"" +
							"}";						
					Hashtable<String,String> params=new Hashtable<String,String>();
		    		params.put("jsonString", json);
		    		String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_EXPENSE, params, null);
		    		System.out.println("Check expence is add or not "+response);
		    		if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISADDED:" + response);
					System.out.println(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_ID)));
					datasource1.expenseupdateISAdded(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_ID)));
			
					}
				    }
				}
			 cursor.moveToNext();
			}
			datasource1.close();
		}
		catch(Exception sqException){
			datasource1.close();
			System.out.println("Exception In Add Expenses Data");
			sqException.printStackTrace();
		}

		// this is for delete data from server,,,,,,,,,,

		Y3QueryDataSource datasource ;//;= new Y3QueryDataSource(getActivity());
		
		
			datasource = new Y3QueryDataSource(getActivity());
		
		datasource.open();
		List<Y3Query> result = datasource.getAllY3Queries();
		for (int i = 0; i < result.size(); i++) {
			Y3Query y3q = result.get(i);
			if (y3q.getAction().equals(
					Y3QueryDataSource.ACTION_EXPENCE_DELETE)) {
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", y3q.getJson());
				Hashtable<String,File> fileParams=null;
				String imagePath=null;
	    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
	    		{
	    			fileParams=new Hashtable<String,File>();
		    		fileParams.put("image", new File(imagePath));
	    		}
			    String response = Utils.post(getActivity(), AppManager.getInstance().URL_DELETE_EXPENSE, parameters, fileParams);

				try {
					if (response != null
							&& new JSONObject(response).getInt("error") == 0) {
						boolean isQueryDeleted = datasource
								.deleteY3Query(y3q.get_id());
						Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}
			}

		}
		datasource.close();
		
		
		
		// this is for edit expence from server....................................................
		try{
				Y3QueryDataSource datasourceedit;
			
				datasourceedit = new Y3QueryDataSource(getActivity());
			
			datasourceedit.open();
			Cursor cursor=datasourceedit.getExpenceData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENCE_OFFLINE_EDIT)))){				
					SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
					String token = prefs.getString("token", null);
					String json="{" +"\"token\":\""+token+"\","
					+"\"id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_ID))+"\",";
					json=json+
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_DEPOT_ID))+"\"," +
							"\"region_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_REGION_ID))+"\"," +
							"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_BRAND_ID))+"\"," +
							"\"exp_amount\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_EXP_AMOUNT))+"\"," +
							"\"exp_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_EXP_DATA))+"\"," +
//							"\"payment_mode\":\""+getExpense().getPayment_mode()+"\"," +
							"\"expense_ref\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_REF))+"\"," +
							"\"description\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_DESCRIPTION))+"\"," +
							"\"exp_type_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_EXPTYPE_ID))+"\"" +
							"}";	
					System.out.println(json);
					Hashtable<String,String> params=new Hashtable<String,String>();
		    		params.put("jsonString", json);
		    		Hashtable<String,File> fileParams=null;
		    		String imagePath=null;
		    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
		    		{
		    			fileParams=new Hashtable<String,File>();
			    		fileParams.put("image", new File(imagePath));
		    		}
		    		String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_EXPENSE, params, fileParams);
		    		System.out.println("Check expence is add or not "+response);
		    		if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasource1.expenseupdateIsEdited(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_ID)));			
					}
				    }
				}
			 cursor.moveToNext();
			}
			datasourceedit.close();
		}
		catch(Exception sqException){
			sqException.printStackTrace();
		}
	}

	public void paymentQuery(){
		try{
			Y3QueryDataSource datasource1; //= new Y3QueryDataSource(getActivity());
		
				 datasource1 = new Y3QueryDataSource(getActivity());
			
			datasource1.open();
			Cursor cursor=datasource1.getPaymentData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_ISOFFLINEADDED)))){	
					SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
					String token = prefs.getString("token", null);
					String json="{" +
						"\"token\":\""+token+"\","+
								"\"request_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REQUEST_ID))+"\","
								+"\"created\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_CREATED))+"\"," ;
				
					json=json+
						"\"payment_mode\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_MODE))+"\"," +
						"\"bank_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_BANK_ID))+"\"," +
						"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_DEPOT_ID))+"\"," +
						"\"region_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_REGION_ID))+"\"," +
						"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_BRAND_ID))+"\"," +
						"\"distributor_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_DISTRIBUTOR_ID))+"\"," +
						"\"amount\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_AMOUNT))+"\"," +
						"\"payment_ref\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_REF))+"\"," +
						"\"transaction_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_TRANSACTION_ID))+"\"," +
						"\"payment_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_DATE))+"\"," +
						"\"notes\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_NOTES))+"\"" +
						"}";
					
					Hashtable<String,String> params1=new Hashtable<String,String>();
					params1.put("jsonString", json);			
					String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_PAYMENTS, params1, null);
					System.out.println("Response"+response);
					if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasource1.paymentupdateISAdded(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_ID)));			
					}
				    }
			}
			cursor.moveToNext();
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		

		Y3QueryDataSource datasource ; //= new Y3QueryDataSource(getActivity());
		
			 datasource = new Y3QueryDataSource(getActivity());
		
		datasource.open();
		List<Y3Query> result = datasource.getAllY3Queries();
		for (int i = 0; i < result.size(); i++) {
			Y3Query y3q = result.get(i);
			if (y3q.getAction().equals(
					Y3QueryDataSource.ACTION_PAYMENT_DELETE)) {
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", y3q.getJson());
				Hashtable<String,File> fileParams=null;
				String imagePath=null;
	    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
	    		{
	    			fileParams=new Hashtable<String,File>();
		    		fileParams.put("image", new File(imagePath));
	    		}
			    String response = Utils.post(getActivity(), AppManager.getInstance().URL_DELETE_PAYMENTS, parameters, fileParams);

				try {
					if (response != null
							&& new JSONObject(response).getInt("error") == 0) {
						boolean isQueryDeleted = datasource
								.deleteY3Query(y3q.get_id());
						Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}
			}

		}
		// this is for edit.....
		
		try{
			
				Y3QueryDataSource datasource1 ;// = new Y3QueryDataSource(getActivity());				
			    datasource1 = new Y3QueryDataSource(getActivity());				
				datasource1.open();
				Cursor cursor=datasource1.getPaymentData();
				cursor.moveToFirst();
				while (!cursor.isAfterLast()) {					
					if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_ISOFFLINEEDITED)))){				
						SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
						String token = prefs.getString("token", null);
						String json="{" +
							"\"token\":\""+token+"\",";						
							json=json+"\"id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_ID))+"\",";					
							
						json=json+
							"\"payment_mode\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_MODE))+"\"," +
							"\"bank_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_BANK_ID))+"\"," +							
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_DEPOT_ID))+"\"," +
							"\"region_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_REGION_ID))+"\"," +
							"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_BRAND_ID))+"\"," +
							"\"distributor_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_DISTRIBUTOR_ID))+"\"," +
							"\"amount\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_AMOUNT))+"\"," +
							"\"payment_ref\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_REF))+"\"," +
							"\"transaction_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_TRANSACTION_ID))+"\"," +
							"\"payment_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_DATE))+"\"," +
							"\"notes\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_NOTES))+"\"" +
							"}";
						
						Hashtable<String,String> parameters=new Hashtable<String,String>();
						parameters.put("jsonString", json);
						Hashtable<String,File> fileParams=null;
						String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_PAYMENTS, parameters, null);	
						if(response!=null)
					    {
					    int error = new JSONObject(response).getInt("error");
					    if (error == 0) 
						{
						System.out.println("All is welll");
						Log.d("MTK", "ISUPDATE:" + response); 					
						datasource1.paymentupdateISEdit(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_ID)));			
						}
					    }
					}
					cursor.moveToNext();
				}
		   
		   }
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private void customerVisitQuery(){
		try{
			
			//System.out.println(getActivity().getApplicationContext());
			
			Y3QueryDataSource datasourcedelete ; //= new Y3QueryDataSource(getActivity());
			
			
			datasourcedelete = new Y3QueryDataSource(getActivity());		
			datasourcedelete.open();
			Cursor cursor=datasourcedelete.getCustomerVisitData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEADDED)))){				
					SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
					String token = prefs.getString("token", null);
					
					String json="{" +
							"\"token\":\""+token+"\","+"\"request_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REQUEST_ID))+"\","+
							"\"created\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CREATED_DATE))+"\",";
					
					
					if(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))==null)
					{
						json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))+"\"," +
								"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_LGAREAID))+"\"," +
								"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_DEPOTID))+"\"," +
								"\"visiting_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_VISITING_DATE))+"\"," +
								"\"comment\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_COMMENT))+"\"";
						json=json+",";
						json=json+"\"newCustomer\":" ;
						json=json+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMER_JSON));		
						json=json+"}";
					}
					else{
						
						json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))+"\"," +
								"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_LGAREAID))+"\"," +
								"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_DEPOTID))+"\"," +
								"\"visiting_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_VISITING_DATE))+"\"," +
								"\"comment\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_COMMENT))+"\"";
						json=json+"}";
						
					}
					
					Hashtable<String,String> params1=new Hashtable<String,String>();
		    		params1.put("jsonString",json);	
		    		//String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_INCENTIVE, params, null);
					String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_CUSTOMERVISITS, params1, null);
					System.out.println("The Response is now find "+response);
					
					if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasourcedelete.customerVisitupdateISAdded(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ID)));			
					}
				    }
					
					
					
					
					
				}
				cursor.moveToNext();
			}
			datasourcedelete.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		
	// this is for delete data from server.......	
		Y3QueryDataSource datasource ;// = new Y3QueryDataSource(getActivity());
	
			datasource = new Y3QueryDataSource(getActivity());
		
		datasource.open();
		List<Y3Query> result = datasource.getAllY3Queries();
		for (int i = 0; i < result.size(); i++) {
			Y3Query y3q = result.get(i);
			if (y3q.getAction().equals(
					Y3QueryDataSource.ACTION_CUSTOMER_VISITING_DELETE)) {
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", y3q.getJson());
				Hashtable<String,File> fileParams=null;
				String imagePath=null;
	    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
	    		{
	    			fileParams=new Hashtable<String,File>();
		    		fileParams.put("image", new File(imagePath));
	    		}
			    String response = Utils.post(getActivity(), AppManager.getInstance().URL_DELETE_CUSTOMERVISITS, parameters, fileParams);

				try {
					if (response != null
							&& new JSONObject(response).getInt("error") == 0) {
						boolean isQueryDeleted = datasource
								.deleteY3Query(y3q.get_id());
						Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}
			}

		}
		datasource.close();
		// this is for edit.........................................URL_UPDATE_CUSTOMERVISITS
		try{
			Y3QueryDataSource datasourceedit ;//= new Y3QueryDataSource(getActivity());
			
				datasourceedit = new Y3QueryDataSource(getActivity());
			
			datasourceedit.open();
			Cursor cursor=datasourceedit.getCustomerVisitData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEEDITED)))){				
					SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
					String token = prefs.getString("token", null);
					String json="{" +"\"token\":\""+token+"\",";
					if(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))!=null)
					{
						json=json+"\"visit_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ID))+"\",";
					
					json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))+"\"," +
							"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_LGAREAID))+"\"," +
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_DEPOTID))+"\"," +
							"\"visiting_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_VISITING_DATE))+"\"," +
							"\"comment\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_COMMENT))+"\"";
					json=json+"}";
					}
					Hashtable<String,String> parameters=new Hashtable<String,String>();
					parameters.put("jsonString", json);				
				    String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_CUSTOMERVISITS, parameters, null);
				    System.out.println("This is for edit "+response);
				    
				    if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasourceedit.customerVisitupdateISEdit(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ID)));			
					}
				    }
					
				}
				cursor.moveToNext();	
				}
				
			datasourceedit.close();
			}
		
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private void incentivesQuery(){
		try{
			
			Y3QueryDataSource datasource1;
			
			
				datasource1 = new Y3QueryDataSource(getActivity());
			
			datasource1.open();
			Cursor cursor=datasource1.getIncentiveData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_ISOFFLINEADDED)))){				
					SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
					String token = prefs.getString("token", null);
					String json="{" +
							"\"token\":\""+token+"\","+
							"\"request_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REQUEST_ID))+"\","
							+"\"created\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CREATED_DATE))+"\"," ;
					
					if(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVECUSTOMER_ID))==null)
					{							
						json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVECUSTOMER_ID))+"\"," +
								"\"incentive_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_DATE))+"\"," +
								"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_BRAND_BRAND_ID))+"\"," +
								"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_DEPOTID))+"\"," +
								"\"incentive_type\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_TYPE))+"\"," +
								"\"unit\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_UNIT))+"\"," +
								"\"quantity\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_QUANTITY))+"\"";
						json=json+",";
						json=json+"\"newCustomer\":" ;
						json=json+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_CUSTOMER_JSON));		
						json=json+"}";
						
					}
					else{
						json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVECUSTOMER_ID))+"\"," +
								"\"incentive_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_DATE))+"\"," +
								"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_BRAND_BRAND_ID))+"\"," +
								"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_DEPOTID))+"\"," +
								"\"incentive_type\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_TYPE))+"\"," +
								"\"unit\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_UNIT))+"\"," +
								"\"quantity\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_QUANTITY))+"\"";
						json=json+"}";
					}
					Hashtable<String,String> params=new Hashtable<String,String>();
		    		params.put("jsonString",json);	
		    		//String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_INCENTIVE, params, null);
					String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_INCENTIVE, params, null);
					System.out.println("The Response is now find "+response);
					
					
				    if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasource1.incentiveupdateISAdded(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_ID)));
			
					}
				    }
					}
			cursor.moveToNext();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
//this is for delete from server................
		Y3QueryDataSource datasource;
		
		
		datasource = new Y3QueryDataSource(getActivity());
	
		datasource.open();
		List<Y3Query> result = datasource.getAllY3Queries();
		for (int i = 0; i < result.size(); i++) {
			Y3Query y3q = result.get(i);
			if (y3q.getAction().equals(
					Y3QueryDataSource.ACTION_INCENTIVE_DELETE)) {
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", y3q.getJson());
				Hashtable<String,File> fileParams=null;
				String imagePath=null;
	    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
	    		{
	    			fileParams=new Hashtable<String,File>();
		    		fileParams.put("image", new File(imagePath));
	    		}
			    String response = Utils.post(getActivity(), AppManager.getInstance().URL_DELETE_INCENTIVE, parameters, fileParams);
			    System.out.println("Delete Response in INcentive"+response);

				try {
					if (response != null
							&& new JSONObject(response).getInt("error") == 0) {
						boolean isQueryDeleted = datasource
								.deleteY3Query(y3q.get_id());
						Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}
			}

		}
		
//this is for edit data from server.....
		
		try{
			Y3QueryDataSource datasource1;
			
			
				datasource1 = new Y3QueryDataSource(getActivity());
			
		datasource1.open();
		Cursor cursor=datasource1.getIncentiveData();
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {					
			if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_ISOFFLINEEDITED)))){				
				SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
				String token = prefs.getString("token", null);
				String json="{" +"\"token\":\""+token+"\",";
				
				if(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVECUSTOMER_ID))!=null)
				{							
					json=json+"\"customer_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVECUSTOMER_ID))+"\"," +
							"\"incentive_date\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_DATE))+"\"," +
							"\"brand_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_BRAND_BRAND_ID))+"\"," +
							"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_DEPOTID))+"\"," +
							"\"incentive_type\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_TYPE))+"\"," +
							"\"unit\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_UNIT))+"\"," +
							"\"quantity\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_QUANTITY))+"\"";
					json=json+"}";
					
				}
		
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", json);				
			    String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_INCENTIVE, parameters, null);
			    System.out.println("This is for edit "+response);
			    System.out.println("This is Addcustomer Server response"+response);
			    if(response!=null)
			    {
			    int error = new JSONObject(response).getInt("error");
			    if (error == 0) 
				{
				System.out.println("All is welll");
				Log.d("MTK", "ISUPDATE:" + response); 					
				datasource1.incentiveupdateISUpdated(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_ID)));
		
				}
			    }
			}
		cursor.moveToNext();
		}
		
		}
	catch(Exception e){
		System.out.println("Exception in edit");
		e.printStackTrace();
	}
		
	}
	
	public void salesQuery(){
		try{
			Y3QueryDataSource datasource1 ;
			
				 datasource1 = new Y3QueryDataSource(getActivity());
			
		
			datasource1.open();
			Cursor cursor=datasource1.getSalesData();
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {					
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SALES_ISOFFLINEADDED)))){	
					SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
					String token = prefs.getString("token", null);
					String json="{" +
						"\"token\":\""+token+"\",";
					
					json=json+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SALES_OFFLINE_ADDEDJON));
					Hashtable<String,String> params1=new Hashtable<String,String>();
		    		params1.put("jsonString", json);
		    		String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_SALESORDER, params1, null);
		    		Log.d("MTK", "server response: "+response);
		    		 if(response!=null)
					    {
					    int error = new JSONObject(response).getInt("error");
					    if (error == 0) 
						{
						System.out.println("All is welll");
						Log.d("MTK", "ISUPDATE:" + response); 					
						datasource1.salesUpdateAdd(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ID)));
				
						}
					    }
		    		
					
				}
				cursor.moveToNext();
			}
			datasource1.close();
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("The Exception in add sales order");
		}
		
		//---------------------------------------------------------------
		// this is for add delete operation.........
		Y3QueryDataSource datasource ;//= new Y3QueryDataSource(getActivity());
		
		datasource = new Y3QueryDataSource(getActivity());
		
		datasource.open();
		List<Y3Query> result = datasource.getAllY3Queries();
		for (int i = 0; i < result.size(); i++) {
			Y3Query y3q = result.get(i);
			if (y3q.getAction().equals(
					Y3QueryDataSource.ACTION_SALES_DELETE)) {
				Hashtable<String,String> parameters=new Hashtable<String,String>();
				parameters.put("jsonString", y3q.getJson());
				String imagePath=y3q.getImage();
				Hashtable<String,File> fileParams=null;
	    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
	    		{
	    			fileParams=new Hashtable<String,File>();
		    		fileParams.put("image", new File(imagePath));
	    		}
	    		
			    String response = Utils.post(getActivity(), AppManager.getInstance().URL_DELETE_SALESORDER, parameters, fileParams);

				try {
					if (response != null
							&& new JSONObject(response).getInt("error") == 0) {
						boolean isQueryDeleted = datasource
								.deleteY3Query(y3q.get_id());
						Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
						
					}
				} catch (JSONException e) {
					e.printStackTrace();

				}}}
		
	}

private void distributorSalesQuery(){
	try{
		Y3QueryDataSource datasource1 ;//= new Y3QueryDataSource(getActivity());
		
	   datasource1 = new Y3QueryDataSource(getActivity());
	
		datasource1.open();
		Cursor cursor=datasource1.getRedistibutorSalesdata();
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {					
			if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REDISTRIBUTORJSON_ISOFFLINEADDED)))){	
				SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
				String token = prefs.getString("token", null);
				String json="{" +
					"\"token\":\""+token+"\",";
				
				json=json+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REDISTRIBUTORJSON_OFFLINE_ASSEDJSON));
				System.out.println("Add Distributor Json"+json);
				Hashtable<String,String> params1=new Hashtable<String,String>();
	    		params1.put("jsonString", json);
	    		String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_DISTRIBUTOR_SALESORDER, params1, null);
	    		Log.d("MTK", "server response: "+response);
	    		
	    		 if(response!=null)
				    {
				    int error = new JSONObject(response).getInt("error");
				    if (error == 0) 
					{
					System.out.println("All is welll");
					Log.d("MTK", "ISUPDATE:" + response); 					
					datasource1.distributorUpdateAdd(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ID)));
			
					}
				    }
	    		
				
			}
			cursor.moveToNext();
		}
		datasource1.close();
	}
	catch(Exception e){
		e.printStackTrace();
		System.out.println("The Exception in Distributor sales order");
	}
	

		 Y3QueryDataSource datasource ;//= new Y3QueryDataSource(getActivity());		
	
		 datasource = new Y3QueryDataSource(getActivity());
	
	datasource.open();
	List<Y3Query> result = datasource.getAllY3Queries();
	for (int i = 0; i < result.size(); i++) {
		Y3Query y3q = result.get(i);
		if (y3q.getAction().equals(
				Y3QueryDataSource.ACTION_DISTRIBUTOR_SALES_DELETE)) {
			Hashtable<String,String> parameters=new Hashtable<String,String>();
			parameters.put("jsonString", y3q.getJson());
			String imagePath=y3q.getImage();
			Hashtable<String,File> fileParams=null;
    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
    		{
    			fileParams=new Hashtable<String,File>();
	    		fileParams.put("image", new File(imagePath));
    		}
    		
		    String response = Utils.post(getActivity(), AppManager.getInstance().URL_DELETE_DISTRIBUTOR_SALESORDER, parameters, fileParams);

			try {
				if (response != null
						&& new JSONObject(response).getInt("error") == 0) {
					boolean isQueryDeleted = datasource
							.deleteY3Query(y3q.get_id());
					Log.d("MTK", "isQueryDeleted:" + isQueryDeleted);
					
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		}

	}
}
public void getSetting(){
	 AppManager.getInstance().getAppSettingData(aq);
}
public void show_notifiction(){
	final Dialog dialog = new Dialog(aq.getContext());
    dialog.setTitle("Notifications");
    
    View view = LayoutInflater.from(aq.getContext()).inflate(R.layout.compaign_dialog_main, null);
    ListView lv = (ListView) view.findViewById(R.id.compaignList);
	
    Y3QueryDataSource dbSource;
    dbSource = new Y3QueryDataSource(getActivity());
    dbSource.open();
    Cursor notification = dbSource.getNotificationData();
    
    if(notification.getCount() > 0){
    	notification.moveToFirst();
	    ArrayList<String> notifyList = new ArrayList<String>();
	    
    	try { 		   
	    	JSONObject notifyObj = null;
		    while(!notification.isAfterLast()){
		    	String notifyID = notification.getString(notification.getColumnIndex(MySQLiteHelper.ID));
				String notify_mess = notification.getString(notification.getColumnIndex(MySQLiteHelper.NOTIFY_MESSAGE));
				String notify_time = notification.getString(notification.getColumnIndex(MySQLiteHelper.NOTIFY_TIME));
				
				notifyObj = new JSONObject();
				notifyObj.put("id", notifyID);
				notifyObj.put("notify_mess", notify_mess);
				notifyObj.put("notify_time", notify_time);					
				notifyList.add(notifyObj.toString());
		    	notification.moveToNext();
		    }
		    
		    notification.close();  
	    
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   
   
	    ArrayAdapter<String> notifyAdapter= new ArrayAdapter<String>(aq.getContext(), R.layout.notify_dialog_listitem, notifyList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.notify_dialog_listitem, parent, false);
	            }
	            final AQuery aql=new AQuery(convertView);
	            String notifyItem = getItem(position);
	            JSONObject notifyItemObj;
	            try {
					notifyItemObj =  new JSONObject(notifyItem);
					String notifyTime = notifyItemObj.isNull("notify_time")?"":notifyItemObj.getString("notify_time");
					if(! "".equals(notifyTime)){
						
						SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						
						Date newDate;
						try {
							newDate = format.parse(notifyTime);
							format = new SimpleDateFormat("MMM dd,yyyy hh:mm a");
							String formatedDate = format.format(newDate);							
							aql.id(R.id.textViewCompaignTitle).text(formatedDate);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						
						//TextView tv0 = new TextView(R.id.textViewCompaignTitle));
						//aql.id(R.id.textViewCompaignTitle)
					}
					
					String noticeMess = notifyItemObj.isNull("notify_mess")?"":notifyItemObj.getString("notify_mess");
					aql.id(R.id.textViewCompaignDescription).text(noticeMess);
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
	         
	            return convertView;
	        }
	        
		};
		
	   lv.setAdapter(notifyAdapter);
	   dialog.setContentView(view);
	   dialog.setCancelable(true);
	   dialog.show();
    }else{
    	Toast toast = Toast.makeText(aq.getContext(), R.string.no_data, Toast.LENGTH_SHORT);
		toast.setGravity(Gravity.CENTER, 0, 0);
		toast.show();
    }
	}
}
