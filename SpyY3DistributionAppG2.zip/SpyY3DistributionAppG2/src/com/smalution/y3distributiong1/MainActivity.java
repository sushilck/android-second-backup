package com.smalution.y3distributiong1;
import java.util.ArrayList;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentManager.BackStackEntry;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import com.androidquery.AQuery;
import com.smalution.y3distributiong1.R;
import com.smalution.y3distributiong1.adapter.NavDrawerListAdapter;
import com.smalution.y3distributiong1.fragments.customer.CustomerDisplayFragment;
import com.smalution.y3distributiong1.fragments.customervisit.CustomerVisitDisplayFragment;
import com.smalution.y3distributiong1.fragments.distributorsalesorder.DistributorSalesOrderDisplayFragment;
import com.smalution.y3distributiong1.fragments.expenses.ExpensesDisplayFragment;
import com.smalution.y3distributiong1.fragments.home.HomeDisplayFragment;
import com.smalution.y3distributiong1.fragments.incentive.IncentiveDisplayFragment;
import com.smalution.y3distributiong1.fragments.payments.PaymentsDisplayFragment;
import com.smalution.y3distributiong1.fragments.salesorder.SalesOrderDisplayFragment;
import com.smalution.y3distributiong1.model.NavDrawerItem;

public class MainActivity extends ActionBarActivity {
	private DrawerLayout mDrawerLayout;
	private ListView mDrawerList;
	private ActionBarDrawerToggle mDrawerToggle;

	// nav drawer title
	private CharSequence mDrawerTitle;

	// used to store app title
	private CharSequence mTitle;

	// slide menu items
	private String[] navMenuTitles;
	//private TypedArray navMenuIcons;

	private ArrayList<NavDrawerItem> navDrawerItems;
	private NavDrawerListAdapter adapter;
	AQuery aq;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_main);
		aq=new AQuery(this);
		
				
		mTitle = mDrawerTitle = getTitle();
		navMenuTitles = getResources().getStringArray(R.array.nav_drawer_items);

		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		mDrawerList = (ListView) findViewById(R.id.list_slidermenu);

		navDrawerItems = new ArrayList<NavDrawerItem>();

		NavDrawerItem homeDrawer = new NavDrawerItem();
		homeDrawer.setTitle(navMenuTitles[0]);
		navDrawerItems.add(homeDrawer);

		NavDrawerItem customerDrawer = new NavDrawerItem();
		customerDrawer.setTitle(navMenuTitles[1]);
		navDrawerItems.add(customerDrawer);
		
		NavDrawerItem customerVisitDrawer = new NavDrawerItem();
		customerVisitDrawer.setTitle(navMenuTitles[2]);
		navDrawerItems.add(customerVisitDrawer);
		
		NavDrawerItem salesOrderDrawer = new NavDrawerItem();
		salesOrderDrawer.setTitle(navMenuTitles[3]);
		navDrawerItems.add(salesOrderDrawer);
		
		NavDrawerItem distributorSalesOrderDrawer = new NavDrawerItem();
		distributorSalesOrderDrawer.setTitle(navMenuTitles[4]);
		navDrawerItems.add(distributorSalesOrderDrawer);
		
		//Incentive
		NavDrawerItem incentiveDrawer = new NavDrawerItem();
		incentiveDrawer.setTitle(navMenuTitles[5]);
		navDrawerItems.add(incentiveDrawer);
				
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		int grade = prefs.getInt("grade", -1);
		if(grade!=-1 && (grade==1 || grade==2 || grade==4 || grade==5 || grade==6))
		{
			NavDrawerItem paymentsDrawer = new NavDrawerItem();
			paymentsDrawer.setTitle(navMenuTitles[6]);
			navDrawerItems.add(paymentsDrawer);
			// Home
			NavDrawerItem expensesDrawer = new NavDrawerItem();
			expensesDrawer.setTitle(navMenuTitles[7]);
			navDrawerItems.add(expensesDrawer);
		}
		
			
		// Recycle the typed array
		//navMenuIcons.recycle();

		mDrawerList.setOnItemClickListener(new SlideMenuClickListener());

		// setting the nav drawer list adapter
		adapter = new NavDrawerListAdapter(getApplicationContext(),
				navDrawerItems);
		mDrawerList.setAdapter(adapter);

		// enabling action bar app icon and behaving it as toggle button
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);

		mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
				R.drawable.ic_drawer, //nav menu toggle icon
				R.string.app_name, // nav drawer open - description for accessibility
				R.string.app_name // nav drawer close - description for accessibility
		) {
			public void onDrawerClosed(View view) {
				getSupportActionBar().setTitle(mTitle);
				// calling onPrepareOptionsMenu() to show action bar icons
				supportInvalidateOptionsMenu();
			}

			public void onDrawerOpened(View drawerView) {
				getSupportActionBar().setTitle(mDrawerTitle);
				// calling onPrepareOptionsMenu() to hide action bar icons
				supportInvalidateOptionsMenu();
			}
		};
		mDrawerLayout.setDrawerListener(mDrawerToggle);

		if (savedInstanceState == null) {
			// on first time display view for first nav item
			displayView(0);
		}
	}
	
	protected void onDestroy(){
		super.onDestroy();		
	}
	
	/**
	 * Slide menu item click listener
	 * */
	private class SlideMenuClickListener implements
			ListView.OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			// display view for selected nav drawer item
			displayView(position);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		//getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// toggle nav drawer on selecting action bar app icon/title
		if (mDrawerToggle.onOptionsItemSelected(item)) {
			return true;
		}
		return super.onOptionsItemSelected(item);
//		// Handle action bar actions click
//		switch (item.getItemId()) {
//		case R.id.action_settings:
//			return true;
//		default:
//			return super.onOptionsItemSelected(item);
//		}
	}

	/* *
	 * Called when invalidateOptionsMenu() is triggered
	 */
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		// if nav drawer is opened, hide the action items
		//boolean drawerOpen = mDrawerLayout.isDrawerOpen(mDrawerList);
		//menu.findItem(R.id.action_settings).setVisible(!drawerOpen);
		return super.onPrepareOptionsMenu(menu);
	}
	private void removeAllBackStackFragments()
	{
		for (int i = 0; i < getSupportFragmentManager().getBackStackEntryCount(); i++) 
		{
			//FragmentManager.BackStackEntry backEntry = (BackStackEntry) getSupportFragmentManager().getBackStackEntryAt(i);
			//String str = backEntry.getName();
			//if (!str.equalsIgnoreCase("HomeDisplayFragment"))
			//{
			//	getSupportFragmentManager().popBackStack();
			//} 
			int backStackId = getSupportFragmentManager().getBackStackEntryAt(i).getId();
			getSupportFragmentManager().popBackStack(backStackId, FragmentManager.POP_BACK_STACK_INCLUSIVE);
		}
		
//		FragmentManager fm = getSupportFragmentManager();
//		for(int i = 0; i < fm.getBackStackEntryCount(); ++i) 
//		{    
//			fm.popBackStack();
//		}
	}
	/**
	 * Diplaying fragment view for selected nav drawer list item
	 * */
	private void displayView(int position) 
	{
		FragmentManager fragmentManager = getSupportFragmentManager();
		removeAllBackStackFragments();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		Fragment fragment = null;
		switch (position) {
		case 0:
			fragment=fragmentManager.findFragmentByTag("HomeDisplayFragment");
			if(fragment==null)
				fragment = new HomeDisplayFragment();
			//fragmentTransaction.addToBackStack("HomeDisplayFragment");
			fragmentTransaction.replace(R.id.frame_container, fragment, "HomeDisplayFragment");
			break;
		case 1:
			fragment=fragmentManager.findFragmentByTag("CustomerDisplayFragment");
			if(fragment==null)
				fragment = new CustomerDisplayFragment();
			//fragmentTransaction.addToBackStack("CustomerDisplayFragment");
			fragmentTransaction.replace(R.id.frame_container, fragment, "CustomerDisplayFragment");
			break;
		case 2:
			fragment=fragmentManager.findFragmentByTag("CustomerVisitDisplayFragment");
			if(fragment==null)
				fragment = new CustomerVisitDisplayFragment();
			//fragmentTransaction.addToBackStack("CustomerVisitDisplayFragment");
			fragmentTransaction.replace(R.id.frame_container, fragment, "CustomerVisitDisplayFragment");
			break;	
		case 3:
			fragment=fragmentManager.findFragmentByTag("SalesOrderDisplayFragment");
			if(fragment==null)
				fragment = new SalesOrderDisplayFragment();
			//fragmentTransaction.addToBackStack("SalesOrderDisplayFragment");
			fragmentTransaction.replace(R.id.frame_container, fragment, "SalesOrderDisplayFragment");
			break;
		case 4:
			fragment=fragmentManager.findFragmentByTag("DistributorSalesOrderDisplayFragment");
			if(fragment==null)
				fragment = new DistributorSalesOrderDisplayFragment();
			//fragmentTransaction.addToBackStack("DistributorSalesOrderDisplayFragment");
			fragmentTransaction.replace(R.id.frame_container, fragment, "DistributorSalesOrderDisplayFragment");
			break;	
		case 5:
			fragment=fragmentManager.findFragmentByTag("IncentiveDisplayFragment");
			if(fragment==null)
				fragment = new IncentiveDisplayFragment();
			//fragmentTransaction.addToBackStack("DistributorSalesOrderDisplayFragment");
			fragmentTransaction.replace(R.id.frame_container, fragment, "IncentiveDisplayFragment");
			break;		
		case 6:
			fragment=fragmentManager.findFragmentByTag("PaymentsDisplayFragment");
			if(fragment==null)
				fragment = new PaymentsDisplayFragment();
			//fragmentTransaction.addToBackStack("PaymentsDisplayFragment");
			fragmentTransaction.replace(R.id.frame_container, fragment, "PaymentsDisplayFragment");
			break;
		case 7:
			fragment=fragmentManager.findFragmentByTag("ExpensesDisplayFragment");
			if(fragment==null)
				fragment = new ExpensesDisplayFragment();
			//fragmentTransaction.addToBackStack("ExpensesDisplayFragment");
			fragmentTransaction.replace(R.id.frame_container, fragment, "ExpensesDisplayFragment");
			break;
		
		
		
		default:
			break;
		}
		fragmentTransaction.commit();
		mDrawerList.setItemChecked(position, true);
		mDrawerList.setSelection(position);
		setTitle(navMenuTitles[position]);
		mDrawerLayout.closeDrawer(mDrawerList);
	}

	@Override
	public void setTitle(CharSequence title) {
		mTitle = title;
		getSupportActionBar().setTitle(mTitle);
	}

	/**
	 * When using the ActionBarDrawerToggle, you must call it during
	 * onPostCreate() and onConfigurationChanged()...
	 */

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		// Sync the toggle state after onRestoreInstanceState has occurred.
		mDrawerToggle.syncState();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		// Pass any configuration change to the drawer toggls
		mDrawerToggle.onConfigurationChanged(newConfig);
	}
	@Override
	protected void onActivityResult(int arg0, int arg1, Intent arg2) 
	{
		super.onActivityResult(arg0, arg1, arg2);
		Log.d("MTK", "MAIN: onActivityResult");
	}
}

