package com.smalution.y3distributionzb1.utils;

public interface DateTimePickerCallbackInterface 
{
	public void onDateTimeSet(int year, int month,int day, int hours, int mins);
}
