package com.smalution.y3distributionzb1.entities.distributor;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class DistRedistributorSale implements Parcelable
{
	private String total;
    private String id;
    private String created;
    private String status;
    private String items;
    private String redistributor_id;
    private String user_id;
    private String sale_date;
    private String customer_id;
    private String modified;
    
	public DistRedistributorSale(){}
	public DistRedistributorSale(JSONObject jsonObect)
	{
		try
		{
			total=jsonObect.isNull("total")?"":jsonObect.getString("total");
		    id=jsonObect.isNull("id")?"":jsonObect.getString("id");
		    created=jsonObect.isNull("created")?"":jsonObect.getString("created");
		    status=jsonObect.isNull("status")?"":jsonObect.getString("status");
		    items=jsonObect.isNull("items")?"":jsonObect.getString("items");
		    redistributor_id=jsonObect.isNull("title")?"":jsonObect.getString("title");
		    user_id=jsonObect.isNull("user_id")?"":jsonObect.getString("user_id");
		    sale_date=jsonObect.isNull("sale_date")?"":jsonObect.getString("sale_date");
		    customer_id=jsonObect.isNull("customer_id")?"":jsonObect.getString("customer_id");
		    modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public DistRedistributorSale(Parcel in)
 	{
		total = in.readString();
	    id = in.readString();
	    created = in.readString();
	    status = in.readString();
	    items = in.readString();
	    redistributor_id = in.readString();
	    user_id = in.readString();
	    sale_date = in.readString();
	    customer_id = in.readString();
	    modified = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(total);
 	    dest.writeString(id);
 	    dest.writeString(created);
 	    dest.writeString(status);
 	    dest.writeString(items);
 	    dest.writeString(redistributor_id);
 	    dest.writeString(user_id);
 	    dest.writeString(sale_date);
 	    dest.writeString(customer_id);
 	    dest.writeString(modified);
 	}
 	public static final Parcelable.Creator<DistRedistributorSale> CREATOR = new Parcelable.Creator<DistRedistributorSale>() 
 	{
 		public DistRedistributorSale createFromParcel(Parcel in) 
 		{
 			return new DistRedistributorSale(in);
 		}
 	
 		public DistRedistributorSale[] newArray (int size) 
 		{
 			return new DistRedistributorSale[size];
 		}
 	};

	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getItems() {
		return items;
	}
	public void setItems(String items) {
		this.items = items;
	}
	public String getRedistributor_id() {
		return redistributor_id;
	}
	public void setRedistributor_id(String redistributor_id) {
		this.redistributor_id = redistributor_id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getSale_date() {
		return sale_date;
	}
	public void setSale_date(String sale_date) {
		this.sale_date = sale_date;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	
}
