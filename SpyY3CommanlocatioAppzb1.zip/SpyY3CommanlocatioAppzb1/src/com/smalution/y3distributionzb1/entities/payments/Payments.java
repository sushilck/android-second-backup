package com.smalution.y3distributionzb1.entities.payments;


import org.json.JSONObject;

import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

import com.androidquery.AQuery;
import com.smalution.y3distributionzb1.AppManager;
import com.smalution.y3distributionzb1.utils.AppConstant;

public class Payments implements Parcelable
{
	PUser User;
	PPayment Payment;
	PBank Bank;
	int sno;
	public Payments()
	{
		User=new PUser();
		Payment=new PPayment();
		Bank=new PBank();
		
	}
	public Payments(JSONObject jsonObject)
	{
		try
		{
			User=jsonObject.isNull("User")?null:new PUser(jsonObject.getJSONObject("User"));
			Payment=jsonObject.isNull("Payment")?null:new PPayment(jsonObject.getJSONObject("Payment"));
			Bank=jsonObject.isNull("Bank")?null:new PBank(jsonObject.getJSONObject("Bank"));
			sno=jsonObject.isNull("sno")?0:jsonObject.getInt("sno");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public Payments(Parcel in)
 	{
		User=in.readParcelable(PUser.class.getClassLoader());
		Payment=in.readParcelable(PPayment.class.getClassLoader());
		Bank=in.readParcelable(PBank.class.getClassLoader());
		sno=in.readInt();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable(User,flags);
 		dest.writeParcelable(Payment,flags);
 		dest.writeParcelable(Bank,flags);
 		dest.writeInt(sno);
 	}
 	public static final Parcelable.Creator<Payments> CREATOR = new Parcelable.Creator<Payments>() 
 	{
 		public Payments createFromParcel(Parcel in) 
 		{
 			return new Payments(in);
 		}
 	
 		public Payments[] newArray (int size) 
 		{
 			return new Payments[size];
 		}
 	};

	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public PUser getUser() {
		return User;
	}
	public void setUser(PUser user) {
		User = user;
	}
	public PPayment getPayment() {
		return Payment;
	}
	public void setPayment(PPayment payment) {
		Payment = payment;
	}
	public PBank getBank() {
		return Bank;
	}
	public void setBank(PBank bank) {
		Bank = bank;
	}
	
	public String createJson(AQuery aq, boolean isForEditCustomer)
	{
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		String token = prefs.getString("token", null);
		String json="{" +
			"\"token\":\""+token+"\",";
		if(isForEditCustomer)
		{
			json=json+"\"id\":\""+getPayment().getId()+"\",";
		}else{

			json=json+"\"created\":\""+AppConstant.getCurrentDateAndTime()+"\",";	
		}
			
		json=json+
			"\"request_id\":\""+AppConstant.ANDROIDDEVICEID+AppConstant.getRequestId()+"\","+
			"\"payment_mode\":\""+getPayment().getPayment_mode()+"\"," +
			"\"bank_id\":\""+getPayment().getBank_id()+"\"," +
			"\"depot_id\":\""+getPayment().getDepot_id()+"\"," +
			"\"region_id\":\""+getPayment().getRegion_id()+"\"," +
			"\"brand_id\":\""+getPayment().getBrand_id()+"\"," +
			"\"distributor_id\":\""+getPayment().getDistributor_id()+"\"," +
			"\"amount\":\""+getPayment().getAmount()+"\"," +
			"\"payment_ref\":\""+getPayment().getPayment_ref()+"\"," +
			"\"transaction_id\":\""+getPayment().getTransaction_id()+"\"," +
			"\"payment_date\":\""+getPayment().getPayment_date()+"\"," +
			"\"notes\":\""+getPayment().getNotes()+"\"" +
			"}";
		return json;
	}
}
