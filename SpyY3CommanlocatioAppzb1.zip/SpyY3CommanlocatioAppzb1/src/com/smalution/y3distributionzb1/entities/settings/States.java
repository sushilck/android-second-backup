package com.smalution.y3distributionzb1.entities.settings;

import java.util.ArrayList;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

public class States 
{
	ArrayList<SelectionButtonItem> states;
	String[] statesNameArr; 
	public States(){}
	public States(JSONArray jsonArray)
	{
		try
		{
			states=new ArrayList<SelectionButtonItem>();
			statesNameArr=new String[jsonArray.length()];
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject = jsonArray.getJSONObject(i); 
				String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
				String value=jsonObject.isNull("value")?"":jsonObject.getString("value");
				SelectionButtonItem itm=new SelectionButtonItem(id, "", value);
				states.add(itm);
				statesNameArr[i]=itm.getTitle();
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getDepotNameById(String id)
	{
		for(SelectionButtonItem itm:states)
		{
			if(itm.getId().equals(id))
				return itm.getTitle();
		}
		return null;
	}
	public SelectionButtonItem getItem(int position)
	{
		return states.get(position);
	}
	public String[] getStatesNameArr() {
		return statesNameArr;
	}
	public void setStatesNameArr(String[] statesNameArr) {
		this.statesNameArr = statesNameArr;
	}
}
