/**
 * 
 */
package com.smalution.y3distributionlb2;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;

/**
 * @author Chand Miyan
 *
 */
public class DeviceAdmin extends DeviceAdminReceiver 
{
	SharedPreferences mPrefs;
	AppManager appManager;
	Context context;
		
//	implement onEnabled(), onDisabled(),
	@Override
	public void onReceive(Context context, Intent intent) {
		super.onReceive(context, intent);
	}
	
	public void onEnabled(Context context, Intent intent) {		
		System.out.println("On enabled option");
		new postSecurityAlert(context).execute(1);
	};
	
	public void onDisabled(Context context, Intent intent) {
		System.out.println("On disabled option");
		
		mPrefs = context.getSharedPreferences("BGGeoCollector", Context.MODE_PRIVATE);
		
		String allowUninstallApp = mPrefs.getString("allow_uninstall_app", "0");
		System.out.println("allowUninstallApp="+allowUninstallApp);
		//wiped data
		ComponentName mAdminName = new ComponentName(context, DeviceAdmin.class);
		if ( allowUninstallApp.equals("1") ){
			System.out.println("allowUninstallApp="+allowUninstallApp);
			DevicePolicyManager mDPM = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
			if(mDPM.isAdminActive(mAdminName)){	
				System.out.println("Wipped data now");
				mDPM.wipeData(0);
				///Intent intent2 = new Intent(Intent.ACTION_DELETE);
				//intent.setData(Uri.parse("package:com.smalution.y3distribution"));
				//context.startActivity(intent2);
			}
		}else{		
			new postSecurityAlert(context).execute(0);
		}
	};
	
	private class postSecurityAlert extends AsyncTask<Integer, Void, Void> {
		Context context;
		public postSecurityAlert(Context context) {
			// TODO Auto-generated constructor stub
			this.context = context;
		}

		protected Void doInBackground(Integer... status) {
				
			mPrefs = context.getSharedPreferences("BGGeoCollector", Context.MODE_PRIVATE);
			String token = mPrefs.getString("token", null);
			String userId = mPrefs.getString("user_id", "");
						
			TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
			String deviceId = telephonyManager.getDeviceId();
			
			JSONObject postJson = new JSONObject();
			try {
				postJson.putOpt("token", token);
				postJson.putOpt("status", status[0] );
				postJson.putOpt("deviceId", deviceId);
				postJson.putOpt("userId", userId);
			} catch (JSONException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(AppManager.isOnline(context) && token != null){			
				try
				{
					HttpClient httpclient = new DefaultHttpClient();
					HttpContext httpContext = new BasicHttpContext();
					HttpPost httppost = new HttpPost(AppManager.getInstance().URL_SCUIRITY_ALERT);
					httppost.setHeader("jsonString", postJson.toString());
					httppost.getParams().setParameter("jsonString", postJson);
					
					StringEntity se = new StringEntity("jsonString="+ postJson.toString());
					httppost.addHeader("content-type",	"application/x-www-form-urlencoded");
					httppost.setEntity(se);
					System.out.println("Post JSON data String: " + postJson.toString());
					
					HttpResponse response = httpclient.execute(httppost,httpContext);
					
					if (response.getStatusLine().getStatusCode() == 200) {
						HttpEntity entity = response.getEntity();
						String json = EntityUtils.toString(entity);
						System.out.println("Response JSON data String: " + json);
					}
				
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
				} catch (IOException e) {
					// // TODO Auto-generated catch block
				}
			}
			
			return null;			
		}
		
		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
		}
	}
}