package com.smalution.y3distributionlb2.entities.incentive;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class IncIncentive implements Parcelable
{
	private String id;
	private String brand_id;
	private String user_id;
	private String customer_id;
	private String depot_id;
	private String incentive_date;
	private String incentive_type;
	private String unit;
	private String cal_qty;
	private String quantity;
	private String created;
	private String modified;
			
    public IncIncentive(){}
	public IncIncentive(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			brand_id=jsonObect.isNull("brand_id")?"":jsonObect.getString("brand_id");
			user_id=jsonObect.isNull("user_id")?"":jsonObect.getString("user_id");
			customer_id=jsonObect.isNull("customer_id")?"":jsonObect.getString("customer_id");
			depot_id=jsonObect.isNull("depot_id")?"":jsonObect.getString("depot_id");
			incentive_date=jsonObect.isNull("incentive_date")?"":jsonObect.getString("incentive_date");
			incentive_type=jsonObect.isNull("incentive_type")?"":jsonObect.getString("incentive_type");
			unit=jsonObect.isNull("unit")?"":jsonObect.getString("unit");
			cal_qty=jsonObect.isNull("cal_qty")?"":jsonObect.getString("cal_qty");
			quantity=jsonObect.isNull("quantity")?"":jsonObect.getString("quantity");
			created=jsonObect.isNull("created")?"":jsonObect.getString("created");
			modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public IncIncentive(Parcel in)
 	{
		id = in.readString();
		brand_id = in.readString();
		user_id = in.readString();
		customer_id = in.readString();
		depot_id = in.readString();
		incentive_date = in.readString();
		incentive_type = in.readString();
		unit = in.readString();
		cal_qty = in.readString();
		quantity = in.readString();
		created = in.readString();
		modified = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(brand_id);
 		dest.writeString(user_id);
 		dest.writeString(customer_id);
 		dest.writeString(depot_id);
 		dest.writeString(incentive_date);
 		dest.writeString(incentive_type);
 		dest.writeString(unit);
 		dest.writeString(cal_qty);
 		dest.writeString(quantity);
 		dest.writeString(created);
 		dest.writeString(modified);
 	}
 	public static final Parcelable.Creator<IncIncentive> CREATOR = new Parcelable.Creator<IncIncentive>() 
 	{
 		public IncIncentive createFromParcel(Parcel in) 
 		{
 			return new IncIncentive(in);
 		}
 	
 		public IncIncentive[] newArray (int size) 
 		{
 			return new IncIncentive[size];
 		}
 	};

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBrand_id() {
		return brand_id;
	}
	public void setBrand_id(String brand_id) {
		this.brand_id = brand_id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getDepot_id() {
		return depot_id;
	}
	public void setDepot_id(String depot_id) {
		this.depot_id = depot_id;
	}
	public String getIncentive_date() {
		return incentive_date;
	}
	public void setIncentive_date(String incentive_date) {
		this.incentive_date = incentive_date;
	}
	public String getIncentive_type() {
		return incentive_type;
	}
	public void setIncentive_type(String incentive_type) {
		this.incentive_type = incentive_type;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getCal_qty() {
		return cal_qty;
	}
	public void setCal_qty(String cal_qty) {
		this.cal_qty = cal_qty;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}

}
