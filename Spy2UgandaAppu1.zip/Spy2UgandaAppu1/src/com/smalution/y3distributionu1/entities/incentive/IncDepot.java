package com.smalution.y3distributionu1.entities.incentive;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class IncDepot implements Parcelable
{
	private String id;
    private String title;
    private String region_id;
    
    public IncDepot(){}
	public IncDepot(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			title=jsonObect.isNull("title")?"":jsonObect.getString("title");
			region_id=jsonObect.isNull("region_id")?"":jsonObect.getString("region_id");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public IncDepot(Parcel in)
 	{
	    id = in.readString();
	    title = in.readString();
	    region_id = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 	    dest.writeString(title);
 	    dest.writeString(region_id);
 	}
 	public static final Parcelable.Creator<IncDepot> CREATOR = new Parcelable.Creator<IncDepot>() 
 	{
 		public IncDepot createFromParcel(Parcel in) 
 		{
 			return new IncDepot(in);
 		}
 	
 		public IncDepot[] newArray (int size) 
 		{
 			return new IncDepot[size];
 		}
 	};

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getRegion_id() {
		return region_id;
	}
	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}

}
