/**
 * 
 */
package com.smalution.y3distributionu1;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;

/**
 * @author Chand Miyan
 *
 */
public class DeviceAdmin extends DeviceAdminReceiver 
{
	SharedPreferences mPrefs;
	AppManager appManager;
	Context context;
		
//	implement onEnabled(), onDisabled(),
	@Override
	public void onReceive(Context context, Intent intent) {
		super.onReceive(context, intent);
	}
	
	public void onEnabled(Context context, Intent intent) {		
		System.out.println("On enabled option");
	};
	
	public void onDisabled(Context context, Intent intent) {
		System.out.println("On disabled option");		
		new postSecurityAlert(context).execute();
	};
	
	private class postSecurityAlert extends AsyncTask<Void, Void, Void> {
		Context context;
		public postSecurityAlert(Context context) {
			// TODO Auto-generated constructor stub
			this.context = context;
		}

		protected Void doInBackground(Void... params) {
				
			mPrefs = context.getSharedPreferences("BGGeoCollector", Context.MODE_PRIVATE);
			String token = mPrefs.getString("token", null);
			JSONObject postJson = new JSONObject();
			try {
				postJson.putOpt("token", token);
			} catch (JSONException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(AppManager.isOnline(context) && token != null){			
				try
				{
					HttpClient httpclient = new DefaultHttpClient();
					HttpContext httpContext = new BasicHttpContext();
					HttpPost httppost = new HttpPost(AppManager.getInstance().URL_SCUIRITY_ALERT);
					httppost.setHeader("jsonString", postJson.toString());
					httppost.getParams().setParameter("jsonString", postJson);
					
					StringEntity se = new StringEntity("jsonString="+ postJson.toString());
					httppost.addHeader("content-type",	"application/x-www-form-urlencoded");
					httppost.setEntity(se);
					System.out.println("Post JSON data String: " + postJson.toString());
					
					HttpResponse response = httpclient.execute(httppost,httpContext);
					
					if (response.getStatusLine().getStatusCode() == 200) {
						HttpEntity entity = response.getEntity();
						String json = EntityUtils.toString(entity);
						System.out.println("Response JSON data String: " + json);
					}
				
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
				} catch (IOException e) {
					// // TODO Auto-generated catch block
				}
			}
			
			return null;			
		}
		
		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
		}
	}
}
