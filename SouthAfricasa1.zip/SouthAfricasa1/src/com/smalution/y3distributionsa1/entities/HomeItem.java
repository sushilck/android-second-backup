package com.smalution.y3distributionsa1.entities;

import android.os.Parcel;
import android.os.Parcelable;

public class HomeItem implements Parcelable
{
	private String serialNo;
	private String photo;
	private String userName;
	private String firstName;
	private String lastName;
	private String email;
	private String role;
	private String state;
	private String region;
	private String depot;
	
	public HomeItem(){}
	
	public HomeItem(Parcel in)
 	{
		serialNo = in.readString();
		photo = in.readString();
		userName = in.readString();
		firstName = in.readString();
		lastName = in.readString();
		email = in.readString();
		role = in.readString();
		state = in.readString();
		region = in.readString();
		depot = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(serialNo);
 		dest.writeString(photo);
 		dest.writeString(userName);
 		dest.writeString(firstName);
 		dest.writeString(lastName);
 		dest.writeString(email);
 		dest.writeString(role);
 		dest.writeString(state);
 		dest.writeString(region);
 		dest.writeString(depot);
	}
 	public static final Parcelable.Creator<HomeItem> CREATOR = new Parcelable.Creator<HomeItem>() 
 	{
 		public HomeItem createFromParcel(Parcel in) 
 		{
 			return new HomeItem(in);
 		}
 	
 		public HomeItem[] newArray (int size) 
 		{
 			return new HomeItem[size];
 		}
 	};
}
