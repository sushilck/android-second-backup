package com.smalution.y3distributionsa1.entities.settings;

public class SelectionButtonItem implements Comparable<SelectionButtonItem>
{
	String id;
	String objectId;
	String title;
	
	String depot_id;
	String region_id;
	String category;
	String subcategory;
	String paymentterm;
	
	public SelectionButtonItem(String id, String objectId, String title)
	{
		this.id=id;
		this.objectId=objectId;
		this.title=title;
	}
	public SelectionButtonItem(String id, String objectId, String title, String depot_id, String region_id, String category, String subcategory, String paymentterm)
	{
		this.id=id;
		this.objectId=objectId;
		this.title=title;
		this.depot_id=depot_id;
		this.region_id=region_id;
		this.category=category;
		this.subcategory=subcategory;
		this.paymentterm=paymentterm;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getObjectId() {
		return objectId;
	}
	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public int compareTo(SelectionButtonItem otherItem) 
	{
		int res = String.CASE_INSENSITIVE_ORDER.compare(this.title, otherItem.title);
		return (res != 0) ? res : this.title.compareTo(otherItem.title);
	}
	
	public String getDepot_id() {
		return depot_id;
	}
	public void setDepot_id(String depot_id) {
		this.depot_id = depot_id;
	}
	
	public String getRegion_id() {
		return region_id;
	}
	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	public String getSubcategory() {
		return subcategory;
	}
	public void setSubcategory(String subcategory) {
		this.subcategory = subcategory;
	}
	
	public String getPaymentterm() {
		return paymentterm;
	}
	public void setPaymentterm(String paymentterm) {
		this.paymentterm = paymentterm;
	}
}
