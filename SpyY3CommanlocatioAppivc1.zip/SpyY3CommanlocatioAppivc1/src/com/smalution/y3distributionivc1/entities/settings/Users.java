package com.smalution.y3distributionivc1.entities.settings;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

public class Users 
{
	ArrayList<SelectionButtonItem> users;
	String namesArr[];
	public Users(){}
	public Users(JSONArray jsonArray)
	{
		try
		{
			users=new ArrayList<SelectionButtonItem>();
			namesArr=new String[jsonArray.length()];
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject = jsonArray.getJSONObject(i); 
				String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
				String value=jsonObject.isNull("value")?"":jsonObject.getString("value");
				SelectionButtonItem itm=new SelectionButtonItem(id, "", value);
				users.add(itm);
				namesArr[i]=itm.getTitle();
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getUserNameById(String id)
	{
		for(SelectionButtonItem itm:users)
		{
			if(itm.getId().equals(id))
				return itm.getTitle();
		}
		return null;
	}
	public String getUserIdByName(String name)
	{
		for(SelectionButtonItem itm:users)
		{
			if(itm.getTitle().equals(name))
				return itm.getId();
		}
		return null;
	}
	public SelectionButtonItem getItem(int position)
	{
		return users.get(position);
	}
	public String[] getNamesArr() {
		return namesArr;
	}
	public void setNamesArr(String[] namesArr) {
		this.namesArr = namesArr;
	}
}
