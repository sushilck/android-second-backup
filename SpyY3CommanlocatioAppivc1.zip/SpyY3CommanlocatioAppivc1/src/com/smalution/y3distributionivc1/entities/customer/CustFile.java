package com.smalution.y3distributionivc1.entities.customer;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class CustFile implements Parcelable
{
	private String id;
	private String name;
	public CustFile(){}
	public CustFile(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			name=jsonObect.isNull("name")?"":jsonObect.getString("name");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public CustFile(Parcel in)
 	{
		id = in.readString();
		name = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(name);
	}
 	public static final Parcelable.Creator<CustFile> CREATOR = new Parcelable.Creator<CustFile>() 
 	{
 		public CustFile createFromParcel(Parcel in) 
 		{
 			return new CustFile(in);
 		}
 	
 		public CustFile[] newArray (int size) 
 		{
 			return new CustFile[size];
 		}
 	};
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
