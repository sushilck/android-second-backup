package com.smalution.y3distributionivc1.entities.customervisits;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class CustVisitCustomer implements Parcelable
{
	private String last_name;
	private String first_name;
	public CustVisitCustomer(){}
	public CustVisitCustomer(JSONObject jsonObect)
	{
		try
		{
			last_name=jsonObect.isNull("last_name")?"":jsonObect.getString("last_name");
			first_name=jsonObect.isNull("first_name")?"":jsonObect.getString("first_name");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public CustVisitCustomer(Parcel in)
 	{
		last_name = in.readString();
		first_name = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(last_name);
 		dest.writeString(first_name);
	}
 	public static final Parcelable.Creator<CustVisitCustomer> CREATOR = new Parcelable.Creator<CustVisitCustomer>() 
 	{
 		public CustVisitCustomer createFromParcel(Parcel in) 
 		{
 			return new CustVisitCustomer(in);
 		}
 	
 		public CustVisitCustomer[] newArray (int size) 
 		{
 			return new CustVisitCustomer[size];
 		}
 	};
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
}
