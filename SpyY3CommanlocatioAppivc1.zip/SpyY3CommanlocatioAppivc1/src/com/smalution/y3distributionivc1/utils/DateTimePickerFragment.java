package com.smalution.y3distributionivc1.utils;

import java.util.Date;

import com.smalution.y3distributionivc1.R;
import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;

public class DateTimePickerFragment extends DialogFragment {
	DateTimePickerCallbackInterface dateTimePickerCallbackInterface;

 public DateTimePickerFragment() {
 }

 public void setCallBack(DateTimePickerCallbackInterface dateTimePickerCallbackInterface) {
  this.dateTimePickerCallbackInterface = dateTimePickerCallbackInterface;
 }
 @Override
 public Dialog onCreateDialog(Bundle savedInstanceState) 
 {
	 final Dialog dialog = new Dialog(getActivity());
	 dialog.setContentView(R.layout.date_time_picker_dialog);
	 dialog.setTitle("Select Date Time");
	 
	 final DatePicker dp = (DatePicker)dialog.findViewById(R.id.datePicker1);
	 dp.setMaxDate(new Date().getTime());
	 final TimePicker tp = (TimePicker)dialog.findViewById(R.id.timePicker1);
	 tp.setIs24HourView(true);
	 Button buttonOK = (Button)dialog.findViewById(R.id.buttonOK);
	 Button buttonCancel = (Button)dialog.findViewById(R.id.buttonCancel);
	 buttonCancel.setOnClickListener(new OnClickListener() 
	 {
		@Override
		public void onClick(View v) 
		{
			dialog.dismiss();
		}
	});
	 buttonOK.setOnClickListener(new OnClickListener() 
	 {
		@Override
		public void onClick(View v) 
		{
			dateTimePickerCallbackInterface.onDateTimeSet(dp.getYear(), dp.getMonth(), dp.getDayOfMonth(), tp.getCurrentHour(),tp.getCurrentMinute());
			dialog.dismiss();
		}
	});
  return dialog;
 }
}  
