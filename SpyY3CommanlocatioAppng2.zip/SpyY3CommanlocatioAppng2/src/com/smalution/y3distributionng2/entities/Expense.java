package com.smalution.y3distributionng2.entities;

import android.os.Parcel;
import android.os.Parcelable;

public class Expense implements Parcelable
{
	private String expenseDetail;
	private String expenseType;
	private String depot;
	private String brand;
	private String expenseRefInvoiceNo;
	private String expenseAmount;
	private String date;
	
	public Expense(){}
	
	public Expense(Parcel in)
 	{
		expenseDetail = in.readString();
		expenseType = in.readString();
		depot = in.readString();
		brand = in.readString();
		expenseRefInvoiceNo = in.readString();
		expenseAmount = in.readString();
		date = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(expenseDetail);
 		dest.writeString(expenseType);
 		dest.writeString(depot);
 		dest.writeString(brand);
 		dest.writeString(expenseRefInvoiceNo);
 		dest.writeString(expenseAmount);
 		dest.writeString(date);
	}
 	public static final Parcelable.Creator<Expense> CREATOR = new Parcelable.Creator<Expense>() 
 	{
 		public Expense createFromParcel(Parcel in) 
 		{
 			return new Expense(in);
 		}
 	
 		public Expense[] newArray (int size) 
 		{
 			return new Expense[size];
 		}
 	};
}
