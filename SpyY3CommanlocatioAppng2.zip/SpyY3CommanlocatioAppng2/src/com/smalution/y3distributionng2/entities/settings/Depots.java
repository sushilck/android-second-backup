package com.smalution.y3distributionng2.entities.settings;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;

public class Depots 
{
	private ArrayList<SelectionButtonItem> depots;
	String titleArr[];
	public Depots(){}
	public Depots(JSONArray jsonArray)
	{
		try
		{
			depots=new ArrayList<SelectionButtonItem>();
			titleArr=new String[jsonArray.length()];
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject = jsonArray.getJSONObject(i).getJSONObject("Depot"); 
				String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
				String title=jsonObject.isNull("title")?"":jsonObject.getString("title");
				String region_id=jsonObject.isNull("region_id")?"":jsonObject.getString("region_id");
				SelectionButtonItem itm=new SelectionButtonItem(id, region_id, title);
				
				depots.add(itm);
				titleArr[i]=itm.getTitle();
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getDepotNameById(String id)
	{
		for(SelectionButtonItem itm:depots)
		{
			if(itm.getId().equals(id))
				return itm.getTitle();
		}
		return null;
	}
	public SelectionButtonItem getItem(int position)
	{
		return depots.get(position);
	}
	public String[] getTitleArr() {
		return titleArr;
	}
	public void setTitleArr(String[] titleArr) {
		this.titleArr = titleArr;
	}
	public ArrayList<SelectionButtonItem> getDepots() {
		return depots;
	}
	public void setDepots(ArrayList<SelectionButtonItem> depots) {
		this.depots = depots;
	}
	
}
